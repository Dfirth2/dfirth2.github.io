# Dayne Firth II
# Raspberry Pi thermostat client with backend integration and local fallback safety.

# ---------------------------------------------------------------------------
# Imports
# ---------------------------------------------------------------------------

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from zoneinfo import ZoneInfo
from math import floor
import os
from threading import Event, Thread
from time import monotonic, sleep
from typing import Any, Mapping

import requests

# These hardware imports are required on a Raspberry Pi with the real circuit.
# In development/test environments they may be unavailable, so we fail gracefully.
HARDWARE_IMPORT_ERROR: str | None = None
try:
    import board
    import adafruit_ahtx0
    import digitalio
    import adafruit_character_lcd.character_lcd as characterlcd
    from gpiozero import Button, PWMLED
except Exception as hardware_exc:  # pragma: no cover - hardware-dependent path
    HARDWARE_IMPORT_ERROR = str(hardware_exc)
    board = None  # type: ignore[assignment]
    adafruit_ahtx0 = None  # type: ignore[assignment]
    digitalio = None  # type: ignore[assignment]
    characterlcd = None  # type: ignore[assignment]
    Button = None  # type: ignore[assignment]
    PWMLED = None  # type: ignore[assignment]

# Serial support is optional.
try:
    import serial
except Exception:  # pragma: no cover - depends on host packages
    serial = None  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# Enable debug prints for local troubleshooting.
DEBUG = True

# Use Central Time (America/Chicago) for all timestamps
CENTRAL_TZ = ZoneInfo("America/Chicago")

# Valid mode values for all safety checks.
VALID_MODES = {"off", "heat", "cool"}

# Safe thermostat bounds.
MIN_TARGET_TEMPERATURE = 45.0
MAX_TARGET_TEMPERATURE = 90.0


def _get_env_int(environ: Mapping[str, str], key: str, default: int) -> int:
    """Parse integer environment values with a safe fallback."""

    raw = environ.get(key)
    if raw is None or raw.strip() == "":
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _get_env_float(environ: Mapping[str, str], key: str, default: float) -> float:
    """Parse float environment values with a safe fallback."""

    raw = environ.get(key)
    if raw is None or raw.strip() == "":
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def _get_env_mode(environ: Mapping[str, str], key: str, default: str) -> str:
    """Read thermostat mode from environment while enforcing valid values."""

    mode = str(environ.get(key, default)).strip().lower()
    if mode in VALID_MODES:
        return mode
    return default


def load_runtime_config(environ: Mapping[str, str] | None = None) -> dict[str, Any]:
    """Load runtime configuration from local environment variables.

    Device-specific addresses (for example Tailscale hostnames) are intentionally
    read from local environment variables so private device names are not stored
    directly in source code.
    """

    env = os.environ if environ is None else environ
    return {
        # Local default keeps development simple when no environment variables are set.
        "BACKEND_BASE_URL": str(env.get("THERMOSTAT_BACKEND_BASE_URL", "http://localhost:8000")).strip(),
        "DEVICE_ID": str(env.get("THERMOSTAT_DEVICE_ID", "thermostat-device")).strip(),
        "API_TIMEOUT_SECONDS": max(1, _get_env_int(env, "THERMOSTAT_API_TIMEOUT_SECONDS", 5)),
        "SYNC_INTERVAL_SECONDS": max(1, _get_env_int(env, "THERMOSTAT_SYNC_INTERVAL_SECONDS", 30)),
        "HEARTBEAT_INTERVAL_SECONDS": max(1, _get_env_int(env, "THERMOSTAT_HEARTBEAT_INTERVAL_SECONDS", 30)),
        "TEMP_LOG_INTERVAL_SECONDS": max(1, _get_env_int(env, "THERMOSTAT_TEMP_LOG_INTERVAL_SECONDS", 300)),
        "SETTINGS_REFRESH_INTERVAL_SECONDS": max(
            1,
            _get_env_int(env, "THERMOSTAT_SETTINGS_REFRESH_INTERVAL_SECONDS", 30),
        ),
        "DEFAULT_MODE": _get_env_mode(env, "THERMOSTAT_DEFAULT_MODE", "off"),
        "DEFAULT_TARGET_TEMPERATURE": _get_env_float(env, "THERMOSTAT_DEFAULT_TARGET_TEMPERATURE", 72.0),
    }


RUNTIME_CONFIG = load_runtime_config()

# Backend host for the FastAPI server, loaded from local environment.
BACKEND_BASE_URL = RUNTIME_CONFIG["BACKEND_BASE_URL"]

# Device metadata used in logs/messages.
DEVICE_ID = RUNTIME_CONFIG["DEVICE_ID"]

# Backend communication timing.
API_TIMEOUT_SECONDS = float(RUNTIME_CONFIG["API_TIMEOUT_SECONDS"])
SYNC_INTERVAL_SECONDS = float(RUNTIME_CONFIG["SYNC_INTERVAL_SECONDS"])
HEARTBEAT_INTERVAL_SECONDS = float(RUNTIME_CONFIG["HEARTBEAT_INTERVAL_SECONDS"])
TEMP_LOG_INTERVAL_SECONDS = float(RUNTIME_CONFIG["TEMP_LOG_INTERVAL_SECONDS"])
SETTINGS_REFRESH_INTERVAL_SECONDS = float(RUNTIME_CONFIG["SETTINGS_REFRESH_INTERVAL_SECONDS"])

# Default local fallback values when backend data is unavailable/invalid.
DEFAULT_MODE = RUNTIME_CONFIG["DEFAULT_MODE"]
DEFAULT_TARGET_TEMPERATURE = max(
    MIN_TARGET_TEMPERATURE,
    min(MAX_TARGET_TEMPERATURE, float(RUNTIME_CONFIG["DEFAULT_TARGET_TEMPERATURE"])),
)

# Weekly day ordering used for schedule trigger comparison helpers.
DAY_ORDER = {
    "sunday": 0,
    "monday": 1,
    "tuesday": 2,
    "wednesday": 3,
    "thursday": 4,
    "friday": 5,
    "saturday": 6,
}

# Backend user to scope settings/schedules/logs for this physical thermostat.
BACKEND_USER_ID = 1

# Optional serial status output.
ENABLE_SERIAL_OUTPUT = False
SERIAL_STATUS_INTERVAL_SECONDS = 30
SERIAL_PORT = "/dev/ttyS0"
SERIAL_BAUDRATE = 115200


# ---------------------------------------------------------------------------
# Hardware setup
# ---------------------------------------------------------------------------


class NoOpPWMLED:
    """Fallback LED implementation used when GPIO hardware is not available."""

    def on(self) -> None:
        return

    def off(self) -> None:
        return

    def pulse(self) -> None:
        return


class ManagedDisplay:
    """16x2 LCD manager.

    On Raspberry Pi hardware this uses the real LCD pins.
    In non-hardware environments this class prints to console when DEBUG is True.
    """

    def __init__(self, hardware_enabled: bool = True) -> None:
        self.hardware_enabled = hardware_enabled and board is not None and digitalio is not None and characterlcd is not None
        self._lcd = None
        if not self.hardware_enabled:
            if DEBUG:
                print("[display] Hardware LCD unavailable; using no-op display mode.")
            return

        # Pin setup for the connected LCD.
        self._lcd_rs = digitalio.DigitalInOut(board.D17)
        self._lcd_en = digitalio.DigitalInOut(board.D27)
        self._lcd_d4 = digitalio.DigitalInOut(board.D5)
        self._lcd_d5 = digitalio.DigitalInOut(board.D6)
        self._lcd_d6 = digitalio.DigitalInOut(board.D13)
        self._lcd_d7 = digitalio.DigitalInOut(board.D26)

        self._lcd = characterlcd.Character_LCD_Mono(
            self._lcd_rs,
            self._lcd_en,
            self._lcd_d4,
            self._lcd_d5,
            self._lcd_d6,
            self._lcd_d7,
            16,
            2,
        )
        self._lcd.clear()

    def update_screen(self, message: str) -> None:
        if self._lcd is None:
            if DEBUG:
                print(f"[display] {message.replace(chr(10), ' | ')}")
            return
        self._lcd.clear()
        self._lcd.message = message

    def cleanup(self) -> None:
        if self._lcd is None:
            return
        self._lcd.clear()
        self._lcd_rs.deinit()
        self._lcd_en.deinit()
        self._lcd_d4.deinit()
        self._lcd_d5.deinit()
        self._lcd_d6.deinit()
        self._lcd_d7.deinit()


# ---------------------------------------------------------------------------
# Backend API helpers
# ---------------------------------------------------------------------------


@dataclass
class BackendContext:
    """Holds backend availability status and latest error for fallback reporting."""

    available: bool = False
    last_error: str = ""


def backend_is_available(session: requests.Session) -> bool:
    """Quick backend health check.

    We use GET /docs as a lightweight availability probe because it exists in this
    application and does not mutate state.
    """

    try:
        response = session.get(f"{BACKEND_BASE_URL}/docs", timeout=API_TIMEOUT_SECONDS)
        return response.status_code == 200
    except requests.RequestException:
        return False


def handle_backend_error(context: BackendContext, operation: str, error: Exception) -> dict[str, str]:
    """Record backend communication failures without crashing local thermostat logic."""

    context.available = False
    context.last_error = f"{operation} failed: {error}"
    if DEBUG:
        print(f"[backend] {context.last_error}")
    return {"status": "error", "message": context.last_error}


def get_backend_settings(
    session: requests.Session,
    context: BackendContext,
    user_id: int,
) -> dict[str, Any] | None:
    """Fetch persisted thermostat settings for the configured backend user."""

    try:
        response = session.get(
            f"{BACKEND_BASE_URL}/settings/",
            params={"user_id": user_id, "create_default": "true"},
            timeout=API_TIMEOUT_SECONDS,
        )
        response.raise_for_status()
        payload = response.json()
        context.available = True
        return payload[0] if isinstance(payload, list) and payload else None
    except requests.RequestException as exc:
        handle_backend_error(context, "get_backend_settings", exc)
        return None


def get_next_scheduled_event(
    session: requests.Session,
    context: BackendContext,
    user_id: int,
) -> dict[str, Any] | None:
    """Fetch next weekly schedule event from backend (already sorted by backend logic)."""

    try:
        response = session.get(
            f"{BACKEND_BASE_URL}/schedules/next",
            params={"user_id": user_id},
            timeout=API_TIMEOUT_SECONDS,
        )
        response.raise_for_status()
        context.available = True
        return response.json()
    except requests.RequestException as exc:
        handle_backend_error(context, "get_next_scheduled_event", exc)
        return None


def send_temperature_log(
    session: requests.Session,
    context: BackendContext,
    payload: dict[str, Any],
) -> bool:
    """Upload a temperature sample to backend storage.

    Failures are non-fatal because local control must continue even if networking fails.
    """

    try:
        response = session.post(
            f"{BACKEND_BASE_URL}/temperature-logs/",
            json=payload,
            timeout=API_TIMEOUT_SECONDS,
        )
        response.raise_for_status()
        context.available = True
        return True
    except requests.RequestException as exc:
        handle_backend_error(context, "send_temperature_log", exc)
        return False


def format_heartbeat_payload(device_id: str) -> dict[str, str]:
    """Build heartbeat payload for thermostat connection tracking endpoint."""

    return {"device_id": device_id}


def send_heartbeat(
    session: requests.Session,
    context: BackendContext,
    device_id: str,
) -> bool:
    """Send thermostat heartbeat to backend status endpoint."""

    try:
        response = session.post(
            f"{BACKEND_BASE_URL}/thermostat/heartbeat",
            json=format_heartbeat_payload(device_id),
            timeout=API_TIMEOUT_SECONDS,
        )
        response.raise_for_status()
        context.available = True
        return True
    except requests.RequestException as exc:
        handle_backend_error(context, "send_heartbeat", exc)
        return False


def send_activity_log(
    session: requests.Session,
    context: BackendContext,
    user_id: int,
    action: str,
) -> bool:
    """Upload an activity log event when backend is reachable."""

    try:
        response = session.post(
            f"{BACKEND_BASE_URL}/activity-logs/",
            json={"user_id": user_id, "action": action},
            timeout=API_TIMEOUT_SECONDS,
        )
        response.raise_for_status()
        context.available = True
        return True
    except requests.RequestException as exc:
        handle_backend_error(context, "send_activity_log", exc)
        return False


def push_backend_settings(
    session: requests.Session,
    context: BackendContext,
    user_id: int,
    mode: str,
    target_temperature: float,
) -> bool:
    """Push thermostat mode/setpoint to backend upsert settings endpoint.

    The current backend schema does not include manual override metadata fields,
    so synchronization updates only current_mode and target_temperature.
    """

    payload = {
        "user_id": user_id,
        "current_mode": mode,
        "target_temperature": float(target_temperature),
    }
    try:
        response = session.post(
            f"{BACKEND_BASE_URL}/settings/",
            json=payload,
            timeout=API_TIMEOUT_SECONDS,
        )
        response.raise_for_status()
        context.available = True
        return True
    except requests.RequestException as exc:
        handle_backend_error(context, "push_backend_settings", exc)
        return False


# ---------------------------------------------------------------------------
# Thermostat helpers
# ---------------------------------------------------------------------------


def validate_mode(mode: str | None) -> bool:
    """Return True only for thermostat-safe mode values."""

    if mode is None:
        return False
    return mode.strip().lower() in VALID_MODES


def validate_target_temperature(temp: Any) -> bool:
    """Verify target temperature is numeric and within safe bounds."""

    try:
        value = float(temp)
    except (TypeError, ValueError):
        return False
    return MIN_TARGET_TEMPERATURE <= value <= MAX_TARGET_TEMPERATURE


def clamp_target_temperature(temp: Any) -> float:
    """Clamp temperatures to safety bounds for reliable hardware behavior."""

    try:
        value = float(temp)
    except (TypeError, ValueError):
        value = DEFAULT_TARGET_TEMPERATURE
    return max(MIN_TARGET_TEMPERATURE, min(MAX_TARGET_TEMPERATURE, value))


def should_heat(current_temp: float, target_temp: float, mode: str) -> bool:
    """Heating runs only when mode is heat and temperature is below target."""

    return mode == "heat" and current_temp < target_temp


def should_cool(current_temp: float, target_temp: float, mode: str) -> bool:
    """Cooling runs only when mode is cool and temperature is above target."""

    return mode == "cool" and current_temp > target_temp


def format_temperature_payload(
    *,
    temperature: float,
    mode: str,
    target_temperature: float,
    user_id: int,
    device_id: str | None = None,
    recorded_at: str | None = None,
) -> dict[str, Any]:
    """Build backend temperature log payload with local safety-normalized fields."""

    payload = {
        "temperature": float(temperature),
        "mode": mode,
        "target_temperature": float(target_temperature),
        "user_id": user_id,
    }
    if device_id:
        payload["device_id"] = device_id
    # recorded_at is optional because current backend schema sets timestamp server-side.
    if recorded_at:
        payload["recorded_at"] = recorded_at
    return payload


def parse_backend_settings(data: dict[str, Any] | None) -> dict[str, Any] | None:
    """Validate/normalize backend settings payload before applying locally."""

    if not isinstance(data, dict):
        return None

    mode = str(data.get("current_mode", "")).strip().lower()
    target = data.get("target_temperature")

    if not validate_mode(mode):
        return None
    if not validate_target_temperature(target):
        return None

    return {
        "current_mode": mode,
        "target_temperature": float(target),
    }


def parse_next_event(data: dict[str, Any] | None) -> dict[str, Any] | None:
    """Validate/normalize next-event payload.

    The backend is the source of truth for event ordering and wrap-around logic, while
    this parser protects local code from malformed network responses.
    """

    if not isinstance(data, dict):
        return None

    day = str(data.get("day_of_week", "")).strip().lower()
    event_time = str(data.get("event_time", "")).strip()
    mode = str(data.get("mode", "")).strip().lower()
    target = data.get("target_temperature")
    is_active = bool(data.get("is_active", False))

    valid_days = {"sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"}

    if day not in valid_days:
        return None
    if len(event_time) != 5 or event_time[2] != ":":
        return None
    if not validate_mode(mode):
        return None
    if not validate_target_temperature(target):
        return None

    return {
        "day_of_week": day,
        "event_time": event_time,
        "mode": mode,
        "target_temperature": float(target),
        "is_active": is_active,
        "event_id": data.get("event_id"),
    }


def apply_remote_settings(
    mode: str,
    target_temperature: float,
    parsed_settings: dict[str, Any] | None,
) -> tuple[str, float]:
    """Apply validated backend settings to local state; otherwise keep local values."""

    if not parsed_settings:
        return mode, target_temperature

    next_mode = parsed_settings["current_mode"]
    next_target = clamp_target_temperature(parsed_settings["target_temperature"])
    return next_mode, next_target


def day_name_from_datetime(now: datetime) -> str:
    """Return lowercase weekday name compatible with backend day_of_week values."""

    return now.strftime("%A").lower()


def event_is_due(event: dict[str, Any] | None, now: datetime) -> bool:
    """Return True when today/time matches or passes next event schedule."""

    parsed = parse_next_event(event)
    if not parsed or not parsed["is_active"]:
        return False

    if parsed["day_of_week"] != day_name_from_datetime(now):
        return False

    try:
        event_hour = int(parsed["event_time"][:2])
        event_minute = int(parsed["event_time"][3:])
    except ValueError:
        return False

    now_minutes = now.hour * 60 + now.minute
    event_minutes = event_hour * 60 + event_minute
    return now_minutes >= event_minutes


def has_scheduled_event_triggered(next_event: dict[str, Any] | None, current_day: str, current_time: str) -> bool:
    """Compare current day/time against event day/time.

    Comparison rules for class clarity:
    - If current day is before event day in weekly order, event has not triggered.
    - If current day is after event day, event is considered triggered.
    - If same day, event triggers when current_time >= event_time.
    """

    parsed = parse_next_event(next_event)
    if not parsed or not parsed["is_active"]:
        return False

    event_day = parsed["day_of_week"]
    event_time = parsed["event_time"]

    current_day_num = DAY_ORDER.get(current_day.strip().lower(), -1)
    event_day_num = DAY_ORDER.get(event_day, -1)
    if current_day_num < 0 or event_day_num < 0:
        return False

    if current_day_num > event_day_num:
        return True
    if current_day_num < event_day_num:
        return False
    return current_time >= event_time


# ---------------------------------------------------------------------------
# Temperature reading
# ---------------------------------------------------------------------------


def read_local_temperature_f(sensor: Any, fallback_temp_f: float) -> float:
    """Read Fahrenheit temperature from sensor with fallback protection."""

    if sensor is None:
        return fallback_temp_f

    try:
        temp_c = float(sensor.temperature)
        temp_f = (9.0 / 5.0) * temp_c + 32.0
        return round(temp_f, 2)
    except Exception as exc:  # pragma: no cover - hardware-dependent path
        if DEBUG:
            print(f"[sensor] read failure: {exc}")
        return fallback_temp_f


# ---------------------------------------------------------------------------
# Schedule and settings sync
# ---------------------------------------------------------------------------


@dataclass
class SyncState:
    """Tracks periodic sync timings and last known backend data."""

    last_settings_refresh: float = 0.0
    last_schedule_refresh: float = 0.0
    last_temp_log: float = 0.0
    last_heartbeat: float = 0.0
    last_serial_output: float = 0.0
    next_event: dict[str, Any] | None = None
    last_applied_event_key: str = ""


# ---------------------------------------------------------------------------
# Local thermostat control
# ---------------------------------------------------------------------------


class ThermostatController:
    """Physical thermostat controller preserving local operation with backend sync."""

    def __init__(self, sensor: Any, display: ManagedDisplay, red_led: Any, blue_led: Any) -> None:
        self.sensor = sensor
        self.display = display
        self.red_led = red_led
        self.blue_led = blue_led

        self.mode = DEFAULT_MODE
        self.target_temperature = DEFAULT_TARGET_TEMPERATURE
        self.current_temperature = DEFAULT_TARGET_TEMPERATURE
        self.backend_context = BackendContext()

        # Manual override state.
        # Priority order is:
        # 1) local manual override, 2) scheduled event, 3) backend settings, 4) defaults.
        self.manual_override_active = False
        self.manual_override_mode = DEFAULT_MODE
        self.manual_override_target_temperature = DEFAULT_TARGET_TEMPERATURE
        self.manual_override_started_at: str | None = None
        self.manual_override_pending_sync = False

        # Backend session/user binding are attached from run_thermostat().
        self.backend_session: requests.Session | None = None
        self.backend_user_id = BACKEND_USER_ID

        # Display thread alternates between temperature and mode/setpoint lines.
        self._stop_event = Event()
        self._display_thread = Thread(target=self._display_loop, daemon=True)
        self._display_counter = 0

    def attach_backend_client(self, session: requests.Session, user_id: int) -> None:
        """Attach backend client context so button handlers can sync local changes."""

        self.backend_session = session
        self.backend_user_id = user_id

    def start(self) -> None:
        self._display_thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        self._display_thread.join(timeout=2)
        self.display.cleanup()

    def cycle_mode(self) -> None:
        """Cycle local mode in off -> heat -> cool -> off order."""

        transitions = {"off": "heat", "heat": "cool", "cool": "off"}
        next_mode = transitions.get(self.get_effective_mode(), DEFAULT_MODE)
        self.apply_local_button_change(mode=next_mode)

    def increase_target(self) -> None:
        next_target = clamp_target_temperature(self.get_effective_target_temperature() + 1)
        self.apply_local_button_change(target_temperature=next_target)

    def decrease_target(self) -> None:
        next_target = clamp_target_temperature(self.get_effective_target_temperature() - 1)
        self.apply_local_button_change(target_temperature=next_target)

    def start_manual_override(self, mode: str, target_temperature: float) -> bool:
        """Start local manual override.

        Manual override means local button changes temporarily override backend settings
        until the next scheduled event occurs.
        """

        if not validate_mode(mode):
            return False
        if not validate_target_temperature(target_temperature):
            return False

        self.manual_override_active = True
        self.manual_override_mode = mode
        self.manual_override_target_temperature = clamp_target_temperature(target_temperature)
        self.manual_override_started_at = datetime.now(CENTRAL_TZ).isoformat()
        self.manual_override_pending_sync = True
        return True

    def clear_manual_override(self, reason: str) -> None:
        """Clear manual override when schedule should take back control."""

        self.manual_override_active = False
        self.manual_override_pending_sync = False
        self.manual_override_started_at = None
        self.log_local_override_activity(reason)

    def get_effective_mode(self) -> str:
        """Return mode respecting manual override priority."""

        if self.manual_override_active:
            return self.manual_override_mode
        return self.mode

    def get_effective_target_temperature(self) -> float:
        """Return target temperature respecting manual override priority."""

        if self.manual_override_active:
            return self.manual_override_target_temperature
        return self.target_temperature

    def log_local_override_activity(self, action_message: str) -> bool:
        """Best-effort activity logging for button overrides and schedule transitions."""

        if self.backend_session is None:
            return False
        return send_activity_log(
            self.backend_session,
            self.backend_context,
            self.backend_user_id,
            action_message,
        )

    def push_local_override_to_backend(self, mode: str, target_temperature: float) -> bool:
        """Push local override values to backend if API is reachable."""

        if self.backend_session is None:
            return False
        success = push_backend_settings(
            self.backend_session,
            self.backend_context,
            self.backend_user_id,
            mode,
            target_temperature,
        )
        if self.manual_override_active:
            self.manual_override_pending_sync = not success
        if not success:
            if self.manual_override_active:
                print("Backend unavailable. Local manual override is active but not synced.")
            else:
                print("Backend unavailable. Scheduled/local setting update will retry on next cycle.")
        return success

    def push_local_mode_change_to_backend(self, mode: str) -> bool:
        """Push mode-only local change using current effective target temperature."""

        return self.push_local_override_to_backend(mode, self.get_effective_target_temperature())

    def push_local_temperature_change_to_backend(self, target_temperature: float) -> bool:
        """Push target-only local change using current effective mode."""

        return self.push_local_override_to_backend(self.get_effective_mode(), target_temperature)

    def apply_local_button_change(self, mode: str | None = None, target_temperature: float | None = None) -> bool:
        """Apply immediate local button changes and start manual override state.

        Local changes must work even with backend offline, so this function updates
        local state first and performs backend sync as best-effort.
        """

        next_mode = self.get_effective_mode() if mode is None else mode
        if mode is not None and not validate_mode(mode):
            if DEBUG:
                print("[local] invalid mode override ignored")
            return False

        next_target = self.get_effective_target_temperature() if target_temperature is None else target_temperature
        if target_temperature is not None and not validate_target_temperature(target_temperature):
            if DEBUG:
                print("[local] invalid target temperature override ignored")
            return False
        next_target = clamp_target_temperature(next_target)

        if not self.start_manual_override(next_mode, next_target):
            if DEBUG:
                print("[local] invalid button override ignored")
            return False

        self.mode = self.manual_override_mode
        self.target_temperature = self.manual_override_target_temperature
        self.update_outputs()

        self.log_local_override_activity("Local manual override started")
        if mode is not None:
            self.log_local_override_activity(f"Local mode changed to {self.mode}")
        if target_temperature is not None:
            self.log_local_override_activity(f"Local target temperature changed to {self.target_temperature}")

        self.push_local_override_to_backend(self.mode, self.target_temperature)

        if DEBUG:
            print(f"[local] manual override active mode={self.mode}, target={self.target_temperature}")
        return True

    def retry_pending_manual_override_sync(self) -> bool:
        """Retry pending manual override sync on regular sync cycles."""

        if not self.manual_override_active or not self.manual_override_pending_sync:
            return True
        return self.push_local_override_to_backend(self.manual_override_mode, self.manual_override_target_temperature)

    def should_apply_backend_settings(self) -> bool:
        """Prevent backend settings pull from overwriting active local manual override."""

        return not self.manual_override_active

    def refresh_local_temperature(self) -> None:
        self.current_temperature = read_local_temperature_f(self.sensor, self.current_temperature)

    def update_outputs(self) -> None:
        """Update LED output while enforcing safety rules.

        - off: both LEDs off
        - heat: pulse red when below setpoint, else solid red
        - cool: pulse blue when above setpoint, else solid blue
        """

        self.red_led.off()
        self.blue_led.off()

        effective_mode = self.get_effective_mode()
        effective_target = self.get_effective_target_temperature()
        temp_int = floor(self.current_temperature)
        target_int = floor(effective_target)

        if effective_mode == "off":
            return

        if effective_mode == "heat":
            if should_heat(temp_int, target_int, effective_mode):
                self.red_led.pulse()
            else:
                self.red_led.on()
            return

        if effective_mode == "cool":
            if should_cool(temp_int, target_int, effective_mode):
                self.blue_led.pulse()
            else:
                self.blue_led.on()

    def apply_backend_settings(self, settings_payload: dict[str, Any] | None) -> None:
        """Apply backend settings safely, or keep local state if payload invalid."""

        if not self.should_apply_backend_settings():
            return

        parsed = parse_backend_settings(settings_payload)
        self.mode, self.target_temperature = apply_remote_settings(self.mode, self.target_temperature, parsed)
        self.update_outputs()

    def apply_scheduled_event(self, next_event_payload: dict[str, Any] | None, sync_state: SyncState) -> bool:
        """Apply due schedule event and end manual override when schedule time is reached."""

        parsed = parse_next_event(next_event_payload)
        if not parsed:
            return False

        event_key = f"{parsed.get('event_id')}|{parsed['day_of_week']}|{parsed['event_time']}"
        if event_key == sync_state.last_applied_event_key:
            return False

        now = datetime.now(CENTRAL_TZ)
        current_day = day_name_from_datetime(now)
        current_time = now.strftime("%H:%M")

        if not has_scheduled_event_triggered(parsed, current_day, current_time):
            return False

        if self.manual_override_active:
            self.clear_manual_override("Manual override ended by scheduled event")

        self.mode = parsed["mode"]
        self.target_temperature = clamp_target_temperature(parsed["target_temperature"])
        self.update_outputs()
        sync_state.last_applied_event_key = event_key

        # Push scheduled values back to backend so dashboard/server reflect current state.
        self.push_local_override_to_backend(self.mode, self.target_temperature)
        self.log_local_override_activity(
            f"Scheduled event applied: {self.mode} at {parsed['event_time']} on {parsed['day_of_week']}"
        )

        if DEBUG:
            print(f"[schedule] applied event {event_key} -> mode={self.mode}, target={self.target_temperature}")
        return True

    def serial_status_line(self) -> str:
        """Return a comma-delimited serial status line."""

        return f"{self.mode},{floor(self.current_temperature)},{floor(self.target_temperature)}\n"

    def _display_loop(self) -> None:
        """Alternate the LCD between temperature and mode/setpoint status."""

        while not self._stop_event.is_set():
            now = datetime.now(CENTRAL_TZ)
            line_1 = now.strftime("%m/%d %H:%M:%S\n")

            if self._display_counter < 5:
                line_2 = f"Temp: {floor(self.current_temperature)} F".ljust(16)
            else:
                line_2 = f"{self.mode.upper()}:{floor(self.target_temperature)}F".ljust(16)

            self._display_counter = (self._display_counter + 1) % 10
            self.display.update_screen(line_1 + line_2)
            sleep(1)


# ---------------------------------------------------------------------------
# Hardware bootstrap helpers
# ---------------------------------------------------------------------------


def build_hardware_objects() -> tuple[Any, ManagedDisplay, Any, Any]:
    """Create hardware resources with safe no-hardware fallbacks."""

    # Sensor setup
    sensor = None
    if board is not None and adafruit_ahtx0 is not None:
        try:
            i2c = board.I2C()
            sensor = adafruit_ahtx0.AHTx0(i2c)
        except Exception as exc:  # pragma: no cover - hardware-dependent path
            if DEBUG:
                print(f"[hardware] sensor setup failed: {exc}")

    display = ManagedDisplay(hardware_enabled=True)

    # LED setup (fallback no-op LEDs keep local logic runnable without GPIO).
    red_led = NoOpPWMLED()
    blue_led = NoOpPWMLED()
    if PWMLED is not None:
        try:
            red_led = PWMLED(18)
            blue_led = PWMLED(23)
        except Exception as exc:  # pragma: no cover - hardware-dependent path
            if DEBUG:
                print(f"[hardware] LED setup failed: {exc}")

    return sensor, display, red_led, blue_led


def setup_buttons(controller: ThermostatController) -> None:
    """Bind physical buttons to local thermostat controls when GPIO is available."""

    if Button is None:
        if DEBUG:
            print("[hardware] Button library unavailable; skipping hardware button bindings.")
        return

    try:
        green_button = Button(24)
        red_button = Button(25)
        blue_button = Button(12)

        green_button.when_pressed = controller.cycle_mode
        red_button.when_pressed = controller.increase_target
        blue_button.when_pressed = controller.decrease_target
    except Exception as exc:  # pragma: no cover - hardware-dependent path
        if DEBUG:
            print(f"[hardware] Button setup failed: {exc}")


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------


def run_thermostat() -> None:
    """Run thermostat main loop with backend sync and local safety fallback."""

    if HARDWARE_IMPORT_ERROR and DEBUG:
        print(f"[hardware] Running with partial/no hardware support: {HARDWARE_IMPORT_ERROR}")

    sensor, display, red_led, blue_led = build_hardware_objects()
    controller = ThermostatController(sensor=sensor, display=display, red_led=red_led, blue_led=blue_led)
    setup_buttons(controller)
    controller.start()

    session = requests.Session()
    sync_state = SyncState()
    controller.attach_backend_client(session, BACKEND_USER_ID)

    serial_conn = None
    if ENABLE_SERIAL_OUTPUT and serial is not None:
        try:
            serial_conn = serial.Serial(
                port=SERIAL_PORT,
                baudrate=SERIAL_BAUDRATE,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                bytesize=serial.EIGHTBITS,
                timeout=1,
            )
        except Exception as exc:  # pragma: no cover - depends on hardware
            if DEBUG:
                print(f"[serial] setup failed: {exc}")

    # Startup activity log is best-effort only.
    send_activity_log(
        session,
        controller.backend_context,
        BACKEND_USER_ID,
        f"Device {DEVICE_ID} thermostat client started.",
    )

    keep_running = True
    while keep_running:
        try:
            now_monotonic = monotonic()

            # Always run local control first so safety and hardware responsiveness
            # do not depend on backend network availability.
            controller.refresh_local_temperature()
            controller.update_outputs()

            # Backend settings refresh
            if now_monotonic - sync_state.last_settings_refresh >= SETTINGS_REFRESH_INTERVAL_SECONDS:
                settings_payload = get_backend_settings(session, controller.backend_context, BACKEND_USER_ID)
                controller.apply_backend_settings(settings_payload)
                controller.retry_pending_manual_override_sync()
                sync_state.last_settings_refresh = now_monotonic

            # Next-event refresh from backend
            if now_monotonic - sync_state.last_schedule_refresh >= SYNC_INTERVAL_SECONDS:
                sync_state.next_event = get_next_scheduled_event(session, controller.backend_context, BACKEND_USER_ID)
                sync_state.last_schedule_refresh = now_monotonic

            # If event is now due, apply it locally.
            controller.apply_scheduled_event(sync_state.next_event, sync_state)

            # Periodic temperature logging (best-effort).
            if now_monotonic - sync_state.last_temp_log >= TEMP_LOG_INTERVAL_SECONDS:
                payload = format_temperature_payload(
                    temperature=controller.current_temperature,
                    mode=controller.mode,
                    target_temperature=controller.target_temperature,
                    user_id=BACKEND_USER_ID,
                    device_id=DEVICE_ID,
                    recorded_at=datetime.now(CENTRAL_TZ).isoformat(),
                )
                send_temperature_log(session, controller.backend_context, payload)
                sync_state.last_temp_log = now_monotonic

            # Send connection heartbeat so dashboard can show online/offline state.
            if now_monotonic - sync_state.last_heartbeat >= HEARTBEAT_INTERVAL_SECONDS:
                send_heartbeat(session, controller.backend_context, DEVICE_ID)
                sync_state.last_heartbeat = now_monotonic

            # Optional serial output for external status consumers.
            if serial_conn is not None and now_monotonic - sync_state.last_serial_output >= SERIAL_STATUS_INTERVAL_SECONDS:
                serial_conn.write(controller.serial_status_line().encode())
                sync_state.last_serial_output = now_monotonic

            sleep(1)

        except KeyboardInterrupt:
            if DEBUG:
                print("[system] KeyboardInterrupt received; shutting down thermostat client.")
            keep_running = False
        except Exception as exc:
            # Never crash control loop on transient network/parsing issues.
            if DEBUG:
                print(f"[system] non-fatal runtime error: {exc}")
            sleep(1)

    send_activity_log(
        session,
        controller.backend_context,
        BACKEND_USER_ID,
        f"Device {DEVICE_ID} thermostat client stopped.",
    )

    if serial_conn is not None:
        try:
            serial_conn.close()
        except Exception:
            pass

    controller.stop()


if __name__ == "__main__":
    run_thermostat()
