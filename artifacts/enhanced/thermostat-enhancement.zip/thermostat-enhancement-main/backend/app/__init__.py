"""
backend.app package initialization.

"""
