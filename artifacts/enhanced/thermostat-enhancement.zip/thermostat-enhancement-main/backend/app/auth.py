"""
Authentication helper module.

"""

from passlib.context import CryptContext

# Use a pure-passlib scheme to avoid external bcrypt backend compatibility issues.
pwd_context = CryptContext(schemes=["pbkdf2_sha256"], deprecated="auto")


def hash_password(password: str) -> str:
    """Hash a plain-text password for secure storage.

    Parameters:
    - password: Raw password input.

    Returns:
    - str: Cryptographic hash suitable for DB storage.
    """

    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a plain password against a stored hash.

    Parameters:
    - plain_password: User-entered password.
    - hashed_password: Stored database hash.

    Returns:
    - bool: True when credentials match, False otherwise.
    """

    return pwd_context.verify(plain_password, hashed_password)
