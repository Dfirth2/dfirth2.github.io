"""
Activity log database service.

This module keeps audit-persistence logic out of route handlers so database
operations remain reusable, readable, and easy to test.
"""

from __future__ import annotations

from sqlalchemy.orm import Session

from app.models.activity_log import ActivityLog
from app.models.user import User


def list_activity_logs(
    db: Session,
    *,
    user_id: int | None = None,
    limit: int | None = None,
) -> list[ActivityLog]:
    """Return audit rows ordered from newest to oldest.

    Activity logs are queried as a SQLAlchemy result set and returned as a
    Python list because the project only needs modest record volumes for local
    thermostat auditing in this phase.
    """

    query = db.query(ActivityLog)
    if user_id is not None:
        query = query.filter(ActivityLog.user_id == user_id)

    query = query.order_by(ActivityLog.timestamp.desc())
    if limit is not None:
        query = query.limit(limit)

    return query.all()


def create_activity_log(db: Session, *, user_id: int, action: str) -> ActivityLog:
    """Persist an audit record for a user action.

    The user relationship is validated up front so activity rows always point to
    a real user account and preserve referential integrity in SQLite.
    """

    normalized_action = action.strip()
    if not normalized_action:
        raise ValueError("Activity action is required.")

    user = db.query(User).filter(User.user_id == user_id).first()
    if user is None:
        raise ValueError("User not found for activity logging.")

    log = ActivityLog(user_id=user_id, action=normalized_action)
    db.add(log)
    db.flush()
    return log
