"""
Thermostat business logic service.

"""

ALLOWED_MODES = {"off", "heat", "cool"}
MIN_TARGET_TEMPERATURE = 45.0
MAX_TARGET_TEMPERATURE = 90.0


def validate_mode(mode: str) -> str:
    # Validate and normalize thermostat operating mode.

    normalized = mode.strip().lower()
    if normalized not in ALLOWED_MODES:
        raise ValueError(f"Mode must be one of: {', '.join(sorted(ALLOWED_MODES))}.")
    return normalized


def validate_target_temperature(target_temperature: float) -> float:
    # Validate target temperature against safe/expected operating bounds.

    if not (MIN_TARGET_TEMPERATURE <= target_temperature <= MAX_TARGET_TEMPERATURE):
        raise ValueError(
            f"Target temperature must be between {MIN_TARGET_TEMPERATURE} and {MAX_TARGET_TEMPERATURE}."
        )
    return target_temperature


def validate_settings(mode: str, target_temperature: float) -> tuple[str, float]:
    # Validate a complete thermostat settings payload.

    return validate_mode(mode), validate_target_temperature(target_temperature)
