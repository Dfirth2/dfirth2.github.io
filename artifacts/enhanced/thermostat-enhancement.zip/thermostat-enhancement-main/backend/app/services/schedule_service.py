"""
Schedule algorithm service.

Weekly schedule enhancement: this module contains all scheduling algorithms
rewritten to operate on a day_of_week + event_time model instead of a one-time
datetime.  Keeping algorithm logic here (separate from routes) makes every
function independently testable and keeps routes thin.
"""

from __future__ import annotations

from typing import Iterable

from app.models.schedule_event import ScheduleEvent, VALID_DAYS
from app.models.user import User
from app.services.activity_log_service import create_activity_log
from app.services.thermostat_service import validate_settings

# DAY_ORDER maps day names to numeric positions so events can be sorted in
# Sunday-first order without string comparison.  A dictionary is used because
# O(1) lookup is cleaner than repeated list.index() calls and the mapping is
# small and fixed for the life of the project.
DAY_ORDER: dict[str, int] = {
    "sunday": 0,
    "monday": 1,
    "tuesday": 2,
    "wednesday": 3,
    "thursday": 4,
    "friday": 5,
    "saturday": 6,
}


def _day_num(day: str) -> int:
    """Return the numeric order for a day name (sunday=0 … saturday=6)."""
    return DAY_ORDER.get(day.strip().lower(), 99)


def _time_key(event_time: str) -> str:
    """Return event_time as a sortable string (already HH:MM, lexicographic order works)."""
    return event_time.strip()


def sort_weekly_events(events: Iterable[ScheduleEvent]) -> list[ScheduleEvent]:
    """Return schedule events sorted Sunday-first, then by time of day.

    The sort key is a tuple (day_order_int, time_str) so that:
    - sunday 07:00 comes before monday 06:00
    - monday 06:00 comes before monday 08:00
    Python's built-in list sort is stable and efficient for the small record
    counts expected in a thermostat schedule.
    """

    return sorted(list(events), key=lambda e: (_day_num(e.day_of_week), _time_key(e.event_time)))


# Keep the old name as an alias so existing code that imports sort_events_by_time
# continues to work without a widespread rename.
sort_events_by_time = sort_weekly_events


def filter_events_by_day(events: Iterable[ScheduleEvent], day_of_week: str) -> list[ScheduleEvent]:
    """Return only events scheduled on the given day.

    A filtered list is used because schedules are small collections and
    readability matters more than micro-optimisation at this project scale.
    """

    target = day_of_week.strip().lower()
    return [e for e in events if e.day_of_week.strip().lower() == target]


def filter_active_events(events: Iterable[ScheduleEvent]) -> list[ScheduleEvent]:
    """Return only active schedule events."""

    return [e for e in events if e.is_active]


def filter_inactive_events(events: Iterable[ScheduleEvent]) -> list[ScheduleEvent]:
    """Return only inactive (soft-disabled) schedule events."""

    return [e for e in events if not e.is_active]


def filter_events_by_mode(events: Iterable[ScheduleEvent], mode: str) -> list[ScheduleEvent]:
    """Return events matching the given thermostat mode (off / heat / cool)."""

    target = mode.strip().lower()
    return [e for e in events if e.mode.strip().lower() == target]


def has_weekly_schedule_conflict(
    existing_events: Iterable[ScheduleEvent],
    new_event: ScheduleEvent,
    user_id: int,
) -> bool:
    """Check whether a new event conflicts with an existing active event.

    Conflict rules:
    - Only active events can block a new active event.
    - Conflict is defined as: same user_id AND same day_of_week AND same event_time.
    - A dictionary keyed by user_id groups active events for fast per-user lookup.
    - Inactive events are ignored so deactivated slots can be reused.
    - Events belonging to a different user never conflict.
    """

    if not new_event.is_active:
        # Inactive events cannot conflict with anything.
        return False

    # Group active events by user_id using a dict for O(1) per-user access.
    events_by_user: dict[int, list[ScheduleEvent]] = {}
    for event in existing_events:
        if not event.is_active:
            continue
        events_by_user.setdefault(event.user_id, []).append(event)

    new_day = new_event.day_of_week.strip().lower()
    new_time = _time_key(new_event.event_time)

    for event in events_by_user.get(user_id, []):
        if event.day_of_week.strip().lower() == new_day and _time_key(event.event_time) == new_time:
            return True

    return False


# Expose the old name as an alias for any code that used the previous function.
has_schedule_conflict = has_weekly_schedule_conflict


def get_next_weekly_event(
    events: Iterable[ScheduleEvent],
    current_day: str,
    current_time: str,
) -> ScheduleEvent | None:
    """Return the next active scheduled event from the current day/time.

    Algorithm:
    1. Filter to active events only.
    2. Look for events later in the current day (same day_order, event_time > current_time).
    3. If none, look for events on later days in the same week.
    4. Wrap-around: if no events remain in the week, start searching from Sunday.
       Wrap-around makes the weekly schedule truly recurring so Saturday's last
       event wraps back to Sunday's first event.
    5. Return the earliest match, or None when no active events exist at all.
    """

    active_events = filter_active_events(list(events))
    if not active_events:
        return None

    current_day_num = _day_num(current_day)
    current_time_key = _time_key(current_time)

    # Split into "later this week" vs "wrap-around to earlier days/times".
    # Events at the same day and same time are NOT included (already triggered).
    later_this_week: list[ScheduleEvent] = []
    wrap_around: list[ScheduleEvent] = []

    for event in active_events:
        event_day_num = _day_num(event.day_of_week)
        event_time_key = _time_key(event.event_time)

        if event_day_num > current_day_num:
            later_this_week.append(event)
        elif event_day_num == current_day_num and event_time_key > current_time_key:
            later_this_week.append(event)
        else:
            # Event is earlier in the week (or same day earlier time): goes to wrap-around.
            wrap_around.append(event)

    # Prefer events later this week; fall back to wrap-around for the next occurrence.
    candidates = later_this_week if later_this_week else wrap_around
    if not candidates:
        return None

    return sort_weekly_events(candidates)[0]


# Keep the old function name available so existing callers (routes, tests)
# that referenced get_next_event still resolve without a hard rename.
def get_next_event(events, current_time=None, **_kwargs):  # type: ignore[no-untyped-def]
    """Compatibility shim – delegates to get_next_weekly_event.

    The old API accepted a datetime; this shim derives the current day and
    time from it so old call-sites continue working while tests migrate.
    """

    from datetime import datetime, timezone as _tz

    if current_time is None:
        current_time = datetime.now(_tz.utc)

    # Derive day-of-week from the datetime (weekday() is 0=Monday; we need 0=Sunday).
    python_weekday = current_time.weekday()
    # Python: Mon=0 … Sun=6 → convert to Sun=0 … Sat=6
    day_index = (python_weekday + 1) % 7
    day_names = list(DAY_ORDER.keys())  # ordered sunday-saturday
    current_day = day_names[day_index]
    current_time_str = current_time.strftime("%H:%M")

    return get_next_weekly_event(events, current_day, current_time_str)


# ── Database helper functions ────────────────────────────────────────────────

def list_schedule_records(db, *, user_id: int | None = None) -> list[ScheduleEvent]:
    """Return persisted schedule rows, optionally scoped to one user."""

    query = db.query(ScheduleEvent)
    if user_id is not None:
        query = query.filter(ScheduleEvent.user_id == user_id)
    return query.all()


def get_schedule_by_id(db, event_id: int) -> ScheduleEvent | None:
    """Return a single schedule row by primary key."""

    return db.query(ScheduleEvent).filter(ScheduleEvent.event_id == event_id).first()


def create_schedule_record(
    db,
    *,
    user_id: int,
    day_of_week: str,
    event_time: str,
    mode: str,
    target_temperature: float,
    is_active: bool,
) -> ScheduleEvent:
    """Create a weekly schedule record with validation, conflict detection, and auditing."""

    user = db.query(User).filter(User.user_id == user_id).first()
    if user is None:
        raise ValueError("User not found.")

    normalized_mode, normalized_target = validate_settings(mode, target_temperature)
    schedule = ScheduleEvent(
        user_id=user_id,
        day_of_week=day_of_week.strip().lower(),
        event_time=event_time.strip(),
        mode=normalized_mode,
        target_temperature=normalized_target,
        is_active=is_active,
    )

    existing_events = list_schedule_records(db, user_id=user_id)
    if has_weekly_schedule_conflict(existing_events, schedule, user_id):
        raise RuntimeError(
            f"Schedule conflict: an active event already exists on {day_of_week} at {event_time}."
        )

    db.add(schedule)
    db.flush()
    create_activity_log(
        db,
        user_id=user_id,
        action=(
            f"Created weekly schedule event: {normalized_mode} on {day_of_week} at {event_time}"
            f" targeting {normalized_target}."
        ),
    )
    return schedule


def update_schedule_record(
    db,
    *,
    event_id: int,
    day_of_week: str | None = None,
    event_time: str | None = None,
    mode: str | None = None,
    target_temperature: float | None = None,
    is_active: bool | None = None,
) -> ScheduleEvent:
    """Update a weekly schedule row and re-run conflict validation."""

    schedule = get_schedule_by_id(db, event_id)
    if schedule is None:
        raise ValueError("Schedule event not found.")

    next_day = day_of_week.strip().lower() if day_of_week is not None else schedule.day_of_week
    next_time = event_time.strip() if event_time is not None else schedule.event_time
    next_mode = mode if mode is not None else schedule.mode
    next_target = target_temperature if target_temperature is not None else schedule.target_temperature
    next_active = is_active if is_active is not None else schedule.is_active
    normalized_mode, normalized_target = validate_settings(next_mode, next_target)

    # Build a candidate event to run conflict detection without mutating the DB row yet.
    candidate = ScheduleEvent(
        user_id=schedule.user_id,
        day_of_week=next_day,
        event_time=next_time,
        mode=normalized_mode,
        target_temperature=normalized_target,
        is_active=next_active,
    )
    existing_events = [
        e for e in list_schedule_records(db, user_id=schedule.user_id) if e.event_id != event_id
    ]
    if has_weekly_schedule_conflict(existing_events, candidate, schedule.user_id):
        raise RuntimeError(
            f"Schedule conflict: an active event already exists on {next_day} at {next_time}."
        )

    schedule.day_of_week = next_day
    schedule.event_time = next_time
    schedule.mode = normalized_mode
    schedule.target_temperature = normalized_target
    schedule.is_active = next_active
    db.flush()
    create_activity_log(
        db,
        user_id=schedule.user_id,
        action=(
            f"Updated weekly schedule event {event_id}: {normalized_mode} on {next_day}"
            f" at {next_time} targeting {normalized_target}; active={next_active}."
        ),
    )
    return schedule


def deactivate_schedule_record(db, *, event_id: int) -> ScheduleEvent:
    """Soft-disable a schedule row while preserving it for audit/history purposes."""

    schedule = get_schedule_by_id(db, event_id)
    if schedule is None:
        raise ValueError("Schedule event not found.")

    schedule.is_active = False
    db.flush()
    create_activity_log(
        db,
        user_id=schedule.user_id,
        action=f"Deactivated weekly schedule event {event_id}.",
    )
    return schedule


def delete_schedule_record(db, *, event_id: int) -> None:
    """Delete a schedule row when permanent removal is explicitly requested."""

    schedule = get_schedule_by_id(db, event_id)
    if schedule is None:
        raise ValueError("Schedule event not found.")

    user_id = schedule.user_id
    db.delete(schedule)
    db.flush()
    create_activity_log(
        db,
        user_id=user_id,
        action=f"Deleted weekly schedule event {event_id}.",
    )
