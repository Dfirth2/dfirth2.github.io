"""Thermostat connection-status service logic."""

from __future__ import annotations

from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from sqlalchemy.orm import Session

from app.models.thermostat_device_status import ThermostatDeviceStatus

# Use Central Time (America/Chicago) for all timestamps
CENTRAL_TZ = ZoneInfo("America/Chicago")


def upsert_thermostat_heartbeat(db: Session, *, device_id: str) -> ThermostatDeviceStatus:
    """Record a device heartbeat by updating last_seen.

    Any successful thermostat check-in marks the device as online for status
    calculations until the timeout window expires.
    """

    now = datetime.now(CENTRAL_TZ)
    row = db.query(ThermostatDeviceStatus).filter(ThermostatDeviceStatus.device_id == device_id).first()
    if row is None:
        row = ThermostatDeviceStatus(device_id=device_id, last_seen=now, last_status="online", updated_at=now)
        db.add(row)
        db.flush()
        return row

    row.last_seen = now
    row.last_status = "online"
    row.updated_at = now
    db.flush()
    return row


def build_thermostat_connection_status(
    db: Session,
    *,
    device_id: str,
    timeout_seconds: int,
) -> dict[str, object]:
    """Return connected/disconnected status based on last_seen age.

    The endpoint intentionally returns only connection state and message so the
    dashboard remains simple and does not expose timestamps.
    """

    row = db.query(ThermostatDeviceStatus).filter(ThermostatDeviceStatus.device_id == device_id).first()
    if row is None:
        return {
            "device_id": device_id,
            "connected": False,
            "status_message": "Thermostat Disconnected",
        }

    now = datetime.now(CENTRAL_TZ)
    last_seen = row.last_seen
    if last_seen.tzinfo is None:
        last_seen = last_seen.replace(tzinfo=CENTRAL_TZ)

    connected = last_seen >= now - timedelta(seconds=timeout_seconds)
    return {
        "device_id": device_id,
        "connected": connected,
        "status_message": "Thermostat Connected" if connected else "Thermostat Disconnected",
    }
