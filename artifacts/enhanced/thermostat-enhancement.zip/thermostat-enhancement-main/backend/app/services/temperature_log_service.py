"""
Temperature log database service.

This module keeps temperature-log persistence and query rules reusable across
routes, tests, and future hardware ingestion workflows.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy.orm import Session

from app.models.temperature_log import TemperatureLog
from app.services.activity_log_service import create_activity_log
from app.services.thermostat_service import validate_settings
from app.services.thermostat_status_service import upsert_thermostat_heartbeat


def list_temperature_logs(
    db: Session,
    *,
    start_time: datetime | None = None,
    end_time: datetime | None = None,
    limit: int | None = None,
    ascending: bool = False,
) -> list[TemperatureLog]:
    """Return temperature rows ordered by recorded time.

    Date-range filters and ordering make the SQLite history table useful for
    both recent dashboard summaries and broader history inspection.
    """

    query = db.query(TemperatureLog)
    if start_time is not None:
        query = query.filter(TemperatureLog.recorded_at >= start_time)
    if end_time is not None:
        query = query.filter(TemperatureLog.recorded_at <= end_time)

    order_column = TemperatureLog.recorded_at.asc() if ascending else TemperatureLog.recorded_at.desc()
    query = query.order_by(order_column)

    if limit is not None:
        query = query.limit(limit)

    return query.all()


def create_temperature_log(
    db: Session,
    *,
    temperature: float,
    mode: str,
    target_temperature: float,
    user_id: int | None = None,
    device_id: str | None = None,
) -> TemperatureLog:
    """Persist a validated temperature history entry.

    Activity logging is optional here because not every hardware reading will be
    tied to a user action, but the hook exists for dashboard/manual writes.
    """

    valid_mode, valid_target = validate_settings(mode, target_temperature)
    log = TemperatureLog(
        temperature=temperature,
        mode=valid_mode,
        target_temperature=valid_target,
    )
    db.add(log)
    db.flush()

    if user_id is not None:
        create_activity_log(
            db,
            user_id=user_id,
            action=f"Recorded temperature log: temp={temperature}, mode={valid_mode}, target={valid_target}.",
        )

    # Thermostat temperature uploads also count as a backend check-in signal.
    if device_id:
        upsert_thermostat_heartbeat(db, device_id=device_id)

    return log
