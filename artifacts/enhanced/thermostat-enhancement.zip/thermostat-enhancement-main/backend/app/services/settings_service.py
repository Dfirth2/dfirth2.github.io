"""
Thermostat settings database service.

This module centralizes settings CRUD and audit behavior so route handlers stay
focused on request/response concerns rather than direct persistence details.
"""

from __future__ import annotations

from sqlalchemy.orm import Session

from app.models.thermostat_setting import ThermostatSetting
from app.models.user import User
from app.services.activity_log_service import create_activity_log
from app.services.thermostat_service import validate_settings


def list_settings(db: Session, *, user_id: int | None = None) -> list[ThermostatSetting]:
    """Return thermostat settings rows ordered by most recently updated first."""

    query = db.query(ThermostatSetting)
    if user_id is not None:
        query = query.filter(ThermostatSetting.user_id == user_id)
    return query.order_by(ThermostatSetting.updated_at.desc()).all()


def get_setting_by_id(db: Session, setting_id: int) -> ThermostatSetting | None:
    """Return a single thermostat setting row by primary key."""

    return db.query(ThermostatSetting).filter(ThermostatSetting.setting_id == setting_id).first()


def get_setting_for_user(db: Session, user_id: int) -> ThermostatSetting | None:
    """Return the current thermostat setting for a user when one exists."""

    return db.query(ThermostatSetting).filter(ThermostatSetting.user_id == user_id).first()


def create_default_setting_if_missing(
    db: Session,
    *,
    user_id: int,
    current_mode: str = "off",
    target_temperature: float = 72.0,
) -> ThermostatSetting:
    """Create a default thermostat setting row only when a user has none.

    This provides predictable persistent defaults for newly seeded or created
    users without duplicating rows on repeated calls.
    """

    existing_setting = get_setting_for_user(db, user_id)
    if existing_setting is not None:
        return existing_setting

    user = db.query(User).filter(User.user_id == user_id).first()
    if user is None:
        raise ValueError("User not found.")

    valid_mode, valid_target = validate_settings(current_mode, target_temperature)
    setting = ThermostatSetting(
        user_id=user_id,
        current_mode=valid_mode,
        target_temperature=valid_target,
    )
    db.add(setting)
    db.flush()
    create_activity_log(db, user_id=user_id, action="Created default thermostat settings.")
    return setting


def upsert_setting(
    db: Session,
    *,
    user_id: int,
    current_mode: str,
    target_temperature: float,
) -> ThermostatSetting:
    """Create or update a thermostat setting row for a user.

    SQLite persists one current settings row per user in this phase, so an
    upsert pattern keeps the API simple for the dashboard.
    """

    valid_mode, valid_target = validate_settings(current_mode, target_temperature)
    setting = get_setting_for_user(db, user_id)
    if setting is None:
        setting = create_default_setting_if_missing(
            db,
            user_id=user_id,
            current_mode=valid_mode,
            target_temperature=valid_target,
        )
        setting.current_mode = valid_mode
        setting.target_temperature = valid_target
        create_activity_log(
            db,
            user_id=user_id,
            action=f"Saved thermostat settings: mode={valid_mode}, target={valid_target}.",
        )
        db.flush()
        return setting

    setting.current_mode = valid_mode
    setting.target_temperature = valid_target
    create_activity_log(
        db,
        user_id=user_id,
        action=f"Updated thermostat settings: mode={valid_mode}, target={valid_target}.",
    )
    db.flush()
    return setting


def update_setting_fields(
    db: Session,
    *,
    setting_id: int,
    current_mode: str | None = None,
    target_temperature: float | None = None,
) -> ThermostatSetting:
    """Update one or both thermostat setting fields on an existing row."""

    setting = get_setting_by_id(db, setting_id)
    if setting is None:
        raise ValueError("Thermostat setting not found.")

    next_mode = current_mode if current_mode is not None else setting.current_mode
    next_target = target_temperature if target_temperature is not None else setting.target_temperature
    valid_mode, valid_target = validate_settings(next_mode, next_target)

    setting.current_mode = valid_mode
    setting.target_temperature = valid_target
    create_activity_log(
        db,
        user_id=setting.user_id,
        action=f"Patched thermostat settings: mode={valid_mode}, target={valid_target}.",
    )
    db.flush()
    return setting
