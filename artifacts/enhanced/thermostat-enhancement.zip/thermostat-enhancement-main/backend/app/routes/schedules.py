"""
Schedule event routes module.

Weekly schedule enhancement: routes now support day_of_week and event_time
(HH:MM) fields rather than a one-time datetime.  Filtering by day is added;
upcoming/past filters are removed because events recur every week.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.schedule_event import ScheduleEvent
from app.schemas.schedule_event import ScheduleEventCreate, ScheduleEventResponse, ScheduleEventUpdate
from app.services.schedule_service import (
    create_schedule_record,
    deactivate_schedule_record,
    delete_schedule_record,
    filter_active_events,
    filter_events_by_day,
    filter_events_by_mode,
    filter_inactive_events,
    get_next_weekly_event,
    get_schedule_by_id,
    list_schedule_records,
    sort_weekly_events,
    update_schedule_record,
)

router = APIRouter(prefix="/schedules", tags=["schedules"])


@router.get("/", response_model=list[ScheduleEventResponse])
def list_schedule_events(
    active: bool | None = None,
    day: str | None = None,
    mode: str | None = None,
    user_id: int | None = None,
    db: Session = Depends(get_db),
) -> list[ScheduleEvent]:
    """Return weekly schedule events sorted Sunday through Saturday.

    Supported query parameters:
    - active: true/false to filter by active/inactive status.
    - day: sunday, monday, … saturday to narrow by day of week.
    - mode: off, heat, or cool to narrow by thermostat mode.
    - user_id: restrict results to one user.
    """

    events = list_schedule_records(db)

    if user_id is not None:
        events = [e for e in events if e.user_id == user_id]

    if active is True:
        events = filter_active_events(events)
    elif active is False:
        events = filter_inactive_events(events)

    if day:
        events = filter_events_by_day(events, day)

    if mode:
        events = filter_events_by_mode(events, mode)

    return sort_weekly_events(events)


@router.get("/next", response_model=ScheduleEventResponse | None)
def next_schedule_event(
    user_id: int | None = None,
    current_day: str | None = None,
    current_time: str | None = None,
    db: Session = Depends(get_db),
) -> ScheduleEvent | None:
    """Return the next active weekly event from the supplied day/time.

    current_day and current_time default to the server's current weekday and
    HH:MM so callers can override them for testing without mocking time.
    Wrap-around is applied when no events remain later in the current week.
    """

    from datetime import datetime
    from zoneinfo import ZoneInfo

    central_tz = ZoneInfo("America/Chicago")
    now = datetime.now(central_tz)
    if current_day is None:
        # Convert Python's Monday=0 weekday to Sunday=0 day index.
        day_index = (now.weekday() + 1) % 7
        day_names = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"]
        current_day = day_names[day_index]
    if current_time is None:
        current_time = now.strftime("%H:%M")

    events = list_schedule_records(db)
    if user_id is not None:
        events = [e for e in events if e.user_id == user_id]

    return get_next_weekly_event(events, current_day, current_time)


@router.get("/{event_id}", response_model=ScheduleEventResponse)
def get_schedule_event(event_id: int, db: Session = Depends(get_db)) -> ScheduleEvent:
    """Return one persisted weekly schedule event by ID."""

    event = get_schedule_by_id(db, event_id)
    if event is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Schedule event not found.")
    return event


@router.post("/", response_model=ScheduleEventResponse, status_code=status.HTTP_201_CREATED)
def create_schedule_event(payload: ScheduleEventCreate, db: Session = Depends(get_db)) -> ScheduleEvent:
    """Create a weekly schedule event after validation and conflict detection."""

    try:
        event = create_schedule_record(
            db,
            user_id=payload.user_id,
            day_of_week=payload.day_of_week,
            event_time=payload.event_time,
            mode=payload.mode,
            target_temperature=payload.target_temperature,
            is_active=payload.is_active,
        )
        db.commit()
        db.refresh(event)
        return event
    except ValueError as exc:
        db.rollback()
        detail = str(exc)
        status_code = status.HTTP_404_NOT_FOUND if "User not found" in detail else status.HTTP_400_BAD_REQUEST
        raise HTTPException(status_code=status_code, detail=detail) from exc
    except RuntimeError as exc:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc


@router.patch("/{event_id}", response_model=ScheduleEventResponse)
def patch_schedule_event(event_id: int, payload: ScheduleEventUpdate, db: Session = Depends(get_db)) -> ScheduleEvent:
    """Update one weekly schedule record while preserving conflict validation."""

    if all(
        v is None
        for v in (payload.day_of_week, payload.event_time, payload.mode, payload.target_temperature, payload.is_active)
    ):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="At least one schedule field must be provided.",
        )

    try:
        event = update_schedule_record(
            db,
            event_id=event_id,
            day_of_week=payload.day_of_week,
            event_time=payload.event_time,
            mode=payload.mode,
            target_temperature=payload.target_temperature,
            is_active=payload.is_active,
        )
        db.commit()
        db.refresh(event)
        return event
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    except RuntimeError as exc:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc


@router.patch("/{event_id}/deactivate", response_model=ScheduleEventResponse)
def deactivate_schedule_event(event_id: int, db: Session = Depends(get_db)) -> ScheduleEvent:
    """Soft-disable a weekly schedule row, keeping it in SQLite for audit purposes."""

    try:
        event = deactivate_schedule_record(db, event_id=event_id)
        db.commit()
        db.refresh(event)
        return event
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc


@router.delete("/{event_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_schedule_event(event_id: int, db: Session = Depends(get_db)) -> None:
    """Permanently remove a weekly schedule row when deletion is explicitly requested."""

    try:
        delete_schedule_record(db, event_id=event_id)
        db.commit()
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

