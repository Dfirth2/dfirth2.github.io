"""
Authentication routes.

"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.auth import verify_password
from app.database import get_db
from app.models.user import User
from app.schemas.user import LoginRequest, LoginResponse, UserResponse
from app.services.activity_log_service import create_activity_log

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/login", response_model=LoginResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)) -> LoginResponse:
    # Validate username/password and return user identity for frontend state.

    user = db.query(User).filter(User.username == payload.username).first()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password.",
        )

    if not verify_password(payload.password, user.password_hash):
        create_activity_log(db, user_id=user.user_id, action="Login failed: invalid password.")
        db.commit()
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password.",
        )

    create_activity_log(db, user_id=user.user_id, action="Login successful.")
    db.commit()

    return LoginResponse(
        message="Login successful.",
        user=UserResponse.model_validate(user),
    )
