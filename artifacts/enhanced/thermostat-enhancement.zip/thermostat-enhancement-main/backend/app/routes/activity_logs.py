"""
Activity log routes module.

"""

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.activity_log import ActivityLog
from app.schemas.activity_log import ActivityLogCreate, ActivityLogResponse
from app.services.activity_log_service import create_activity_log, list_activity_logs

router = APIRouter(prefix="/activity-logs", tags=["activity-logs"])


@router.get("/", response_model=list[ActivityLogResponse])
def list_activity_log_rows(
    user_id: int | None = None,
    limit: int | None = Query(default=None, ge=1, le=500),
    db: Session = Depends(get_db),
) -> list[ActivityLog]:
    # Return activity logs ordered from most recent to oldest, optionally by user.

    return list_activity_logs(db, user_id=user_id, limit=limit)


@router.post("/", response_model=ActivityLogResponse, status_code=status.HTTP_201_CREATED)
def create_activity_log_row(payload: ActivityLogCreate, db: Session = Depends(get_db)) -> ActivityLog:
    # Persist a manual audit row when the frontend or tests need explicit activity creation.

    try:
        log = create_activity_log(db, user_id=payload.user_id, action=payload.action)
        db.commit()
        db.refresh(log)
        return log
    except ValueError as exc:
        db.rollback()
        detail = str(exc)
        status_code = status.HTTP_404_NOT_FOUND if "User not found" in detail else status.HTTP_400_BAD_REQUEST
        raise HTTPException(status_code=status_code, detail=detail) from exc