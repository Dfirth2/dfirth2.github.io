"""
Temperature log routes module.

"""

from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.temperature_log import TemperatureLog
from app.schemas.temperature_log import TemperatureLogCreate, TemperatureLogResponse
from app.services.temperature_log_service import (
    create_temperature_log as create_temperature_log_record,
    list_temperature_logs,
)

router = APIRouter(prefix="/temperature-logs", tags=["temperature-logs"])


@router.get("/", response_model=list[TemperatureLogResponse])
def list_temperature_log_rows(
    limit: int | None = Query(default=None, ge=1, le=500),
    start_time: datetime | None = None,
    end_time: datetime | None = None,
    order: str = Query(default="desc", pattern="^(asc|desc)$"),
    db: Session = Depends(get_db),
) -> list[TemperatureLog]:
    # Return temperature history with optional date-range and recent-record filtering.

    return list_temperature_logs(
        db,
        start_time=start_time,
        end_time=end_time,
        limit=limit,
        ascending=order == "asc",
    )


@router.post("/", response_model=TemperatureLogResponse, status_code=status.HTTP_201_CREATED)
def create_temperature_log(payload: TemperatureLogCreate, db: Session = Depends(get_db)) -> TemperatureLog:
    # Create a temperature history entry in SQLite and optionally audit the action.

    try:
        log = create_temperature_log_record(
            db,
            temperature=payload.temperature,
            mode=payload.mode,
            target_temperature=payload.target_temperature,
            user_id=payload.user_id,
            device_id=payload.device_id,
        )
        db.commit()
        db.refresh(log)
        return log
    except ValueError as exc:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
