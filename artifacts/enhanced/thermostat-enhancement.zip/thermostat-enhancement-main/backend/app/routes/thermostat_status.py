"""Thermostat connection-status routes."""

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.config import load_app_config
from app.database import get_db
from app.schemas.thermostat_status import ThermostatHeartbeatRequest, ThermostatStatusResponse
from app.services.thermostat_status_service import (
    build_thermostat_connection_status,
    upsert_thermostat_heartbeat,
)

router = APIRouter(prefix="/thermostat", tags=["thermostat-status"])
PLACEHOLDER_DEVICE_ID = "your-thermostat-device-id"


def _connection_timeout_seconds() -> int:
    """Load connection timeout from environment.

    Thermostat is considered disconnected if backend has not heard from it
    within this timeout window.
    """

    return load_app_config().thermostat_connection_timeout_seconds


def _allowed_device_id() -> str:
    """Load thermostat allowlisted device ID from environment.

    This is a simple development-level device identification control used to
    ensure heartbeat/status requests are scoped to the expected thermostat.
    """

    return load_app_config().thermostat_allowed_device_id


@router.post("/heartbeat", status_code=status.HTTP_204_NO_CONTENT)
def thermostat_heartbeat(payload: ThermostatHeartbeatRequest, db: Session = Depends(get_db)) -> None:
    # Heartbeat marks thermostat as recently seen.

    if payload.device_id != _allowed_device_id():
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Heartbeat device_id is not allowed.")

    upsert_thermostat_heartbeat(db, device_id=payload.device_id)
    db.commit()


@router.get("/status", response_model=ThermostatStatusResponse)
def thermostat_status(
    device_id: str | None = Query(default=None),
    db: Session = Depends(get_db),
) -> dict[str, object]:
    # Return simple connected/disconnected state for dashboard indicator.

    allowed_device_id = _allowed_device_id()
    requested_device_id = allowed_device_id if device_id in (None, "", PLACEHOLDER_DEVICE_ID) else device_id

    if requested_device_id != allowed_device_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Status device_id is not allowed.")

    return build_thermostat_connection_status(
        db,
        device_id=requested_device_id,
        timeout_seconds=_connection_timeout_seconds(),
    )
