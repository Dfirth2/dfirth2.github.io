"""
Route package initialization for API router modules.

"""
