"""
Thermostat settings routes module.

"""

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.thermostat_setting import ThermostatSetting
from app.schemas.thermostat_setting import ThermostatSettingCreate, ThermostatSettingResponse, ThermostatSettingUpdate
from app.services.settings_service import (
    create_default_setting_if_missing,
    get_setting_by_id,
    list_settings as list_settings_records,
    update_setting_fields,
    upsert_setting,
)

router = APIRouter(prefix="/settings", tags=["settings"])


@router.get("/", response_model=list[ThermostatSettingResponse])
def list_settings(
    user_id: int | None = None,
    create_default: bool = Query(default=False),
    db: Session = Depends(get_db),
) -> list[ThermostatSetting]:
    # Return persisted thermostat settings and optionally create a default row.

    if create_default and user_id is None:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="user_id is required when create_default=true.")

    if create_default and user_id is not None:
        try:
            create_default_setting_if_missing(db, user_id=user_id)
            db.commit()
        except ValueError as exc:
            db.rollback()
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    return list_settings_records(db, user_id=user_id)


@router.get("/{setting_id}", response_model=ThermostatSettingResponse)
def get_setting(setting_id: int, db: Session = Depends(get_db)) -> ThermostatSetting:
    # Return one thermostat settings row so clients can inspect database state directly.

    setting = get_setting_by_id(db, setting_id)
    if setting is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Thermostat setting not found.")

    return setting


@router.post("/", response_model=ThermostatSettingResponse, status_code=status.HTTP_201_CREATED)
def create_or_update_setting(payload: ThermostatSettingCreate, db: Session = Depends(get_db)) -> ThermostatSetting:
    # Upsert a user's persisted thermostat setting row.

    try:
        setting = upsert_setting(
            db,
            user_id=payload.user_id,
            current_mode=payload.current_mode,
            target_temperature=payload.target_temperature,
        )
        db.commit()
        db.refresh(setting)
        return setting
    except ValueError as exc:
        db.rollback()
        detail = str(exc)
        status_code = status.HTTP_404_NOT_FOUND if "User not found" in detail else status.HTTP_400_BAD_REQUEST
        raise HTTPException(status_code=status_code, detail=detail) from exc


@router.patch("/{setting_id}", response_model=ThermostatSettingResponse)
def patch_setting(setting_id: int, payload: ThermostatSettingUpdate, db: Session = Depends(get_db)) -> ThermostatSetting:
    # Partially update one or both thermostat settings fields.

    if payload.current_mode is None and payload.target_temperature is None:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="At least one setting field must be provided.")

    try:
        setting = update_setting_fields(
            db,
            setting_id=setting_id,
            current_mode=payload.current_mode,
            target_temperature=payload.target_temperature,
        )
        db.commit()
        db.refresh(setting)
        return setting
    except ValueError as exc:
        db.rollback()
        detail = str(exc)
        status_code = status.HTTP_404_NOT_FOUND if "not found" in detail.lower() else status.HTTP_400_BAD_REQUEST
        raise HTTPException(status_code=status_code, detail=detail) from exc

