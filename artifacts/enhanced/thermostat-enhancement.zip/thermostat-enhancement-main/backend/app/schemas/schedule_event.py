"""
Schedule event schema definitions.

Schemas protect the API from invalid weekly schedule data by validating
day_of_week, event_time format, mode, and target temperature before records
are passed to service-layer logic.
"""

import re

from pydantic import BaseModel, ConfigDict, Field, field_validator

# Accepted day names in Sunday-first order.
VALID_DAYS = {"sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"}

# Accepted thermostat operating modes.
VALID_MODES = {"off", "heat", "cool"}

# HH:MM pattern for the time-of-day field.
_TIME_PATTERN = re.compile(r"^\d{2}:\d{2}$")


def _validate_day(value: str) -> str:
    # Normalize and validate the day_of_week field.

    normalized = value.strip().lower()
    if normalized not in VALID_DAYS:
        raise ValueError(f"day_of_week must be one of: {', '.join(sorted(VALID_DAYS))}.")
    return normalized


def _validate_event_time(value: str) -> str:
    # Validate that event_time matches HH:MM and represents a real time.

    stripped = value.strip()
    if not _TIME_PATTERN.match(stripped):
        raise ValueError("event_time must be in HH:MM format (e.g. '07:00').")
    hour, minute = int(stripped[:2]), int(stripped[3:])
    if not (0 <= hour <= 23 and 0 <= minute <= 59):
        raise ValueError("event_time must be a valid 24-hour time (00:00 – 23:59).")
    return stripped


class ScheduleEventCreate(BaseModel):
    # Incoming request schema for creating weekly schedule events.
    # All four scheduling fields are required so backend validation can run
    # before any database write is attempted.

    user_id: int
    day_of_week: str
    event_time: str
    mode: str
    target_temperature: float = Field(ge=45.0, le=90.0)
    is_active: bool = True

    @field_validator("day_of_week")
    @classmethod
    def check_day(cls, v: str) -> str:
        return _validate_day(v)

    @field_validator("event_time")
    @classmethod
    def check_time(cls, v: str) -> str:
        return _validate_event_time(v)

    @field_validator("mode")
    @classmethod
    def check_mode(cls, v: str) -> str:
        normalized = v.strip().lower()
        if normalized not in VALID_MODES:
            raise ValueError(f"mode must be one of: {', '.join(sorted(VALID_MODES))}.")
        return normalized


class ScheduleEventUpdate(BaseModel):
    # Partial-update schema used when changing or deactivating weekly schedule events.
    # All fields are optional so a client can patch only what changed.

    day_of_week: str | None = None
    event_time: str | None = None
    mode: str | None = None
    target_temperature: float | None = Field(default=None, ge=45.0, le=90.0)
    is_active: bool | None = None

    @field_validator("day_of_week")
    @classmethod
    def check_day(cls, v: str | None) -> str | None:
        if v is None:
            return v
        return _validate_day(v)

    @field_validator("event_time")
    @classmethod
    def check_time(cls, v: str | None) -> str | None:
        if v is None:
            return v
        return _validate_event_time(v)

    @field_validator("mode")
    @classmethod
    def check_mode(cls, v: str | None) -> str | None:
        if v is None:
            return v
        normalized = v.strip().lower()
        if normalized not in VALID_MODES:
            raise ValueError(f"mode must be one of: {', '.join(sorted(VALID_MODES))}.")
        return normalized


class ScheduleEventResponse(BaseModel):
    # Outgoing response schema for weekly schedule events.

    model_config = ConfigDict(from_attributes=True)

    event_id: int
    user_id: int
    day_of_week: str
    event_time: str
    mode: str
    target_temperature: float
    is_active: bool
