"""Thermostat connection status schemas."""

from pydantic import BaseModel


class ThermostatHeartbeatRequest(BaseModel):
    device_id: str


class ThermostatStatusResponse(BaseModel):
    device_id: str
    connected: bool
    status_message: str
