"""
Thermostat setting schema definitions.

"""

from datetime import datetime
from zoneinfo import ZoneInfo

from pydantic import BaseModel, Field, ConfigDict, field_serializer


class ThermostatSettingCreate(BaseModel):
    # Incoming request schema for creating or upserting thermostat settings.

    user_id: int
    current_mode: str = Field(default="off")
    target_temperature: float = Field(default=72.0)


class ThermostatSettingUpdate(BaseModel):
    # Partial-update schema used for mode-only, target-only, or combined edits.

    current_mode: str | None = None
    target_temperature: float | None = None


class ThermostatSettingResponse(BaseModel):
    # Outgoing response schema for thermostat settings.

    model_config = ConfigDict(from_attributes=True)

    setting_id: int
    user_id: int
    current_mode: str
    target_temperature: float
    updated_at: datetime

    @field_serializer('updated_at')
    def serialize_updated_at(self, value: datetime) -> str:
        """Serialize timestamp with Central Time timezone offset."""
        if value.tzinfo is None:
            # Naive datetime from database is in Central Time
            value = value.replace(tzinfo=ZoneInfo('America/Chicago'))
        return value.isoformat()
