"""
Activity log schema definitions.

"""

from datetime import datetime
from zoneinfo import ZoneInfo

from pydantic import BaseModel, ConfigDict, field_serializer


class ActivityLogCreate(BaseModel):
    # Incoming request schema for manual activity/audit log entries.

    user_id: int
    action: str


class ActivityLogResponse(BaseModel):
    #Outgoing response schema for activity log records.

    model_config = ConfigDict(from_attributes=True)

    activity_id: int
    user_id: int
    action: str
    timestamp: datetime

    @field_serializer('timestamp')
    def serialize_timestamp(self, value: datetime) -> str:
        """Serialize timestamp with Central Time timezone offset."""
        if value.tzinfo is None:
            # Naive datetime from database is in Central Time
            value = value.replace(tzinfo=ZoneInfo('America/Chicago'))
        return value.isoformat()
