"""
Temperature log schema definitions.

"""

from datetime import datetime
from zoneinfo import ZoneInfo

from pydantic import BaseModel, ConfigDict, field_serializer


class TemperatureLogCreate(BaseModel):
    # Incoming request schema for adding a temperature log entry.

    temperature: float
    mode: str
    target_temperature: float
    user_id: int | None = None
    device_id: str | None = None


class TemperatureLogResponse(BaseModel):
    #Outgoing response schema for temperature logs

    model_config = ConfigDict(from_attributes=True)

    log_id: int
    temperature: float
    mode: str
    target_temperature: float
    recorded_at: datetime

    @field_serializer('recorded_at')
    def serialize_recorded_at(self, value: datetime) -> str:
        """Serialize timestamp with Central Time timezone offset."""
        if value.tzinfo is None:
            # Naive datetime from database is in Central Time
            value = value.replace(tzinfo=ZoneInfo('America/Chicago'))
        return value.isoformat()
