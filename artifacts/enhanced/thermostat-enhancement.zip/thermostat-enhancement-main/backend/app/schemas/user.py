"""
User schema definitions.

"""

from datetime import datetime
from zoneinfo import ZoneInfo

from pydantic import BaseModel, Field, ConfigDict, field_serializer


class UserCreate(BaseModel):
    #Incoming request schema used when creating a user

    username: str = Field(min_length=3, max_length=50)
    password: str = Field(min_length=8)
    role: str = Field(default="user")


class UserResponse(BaseModel):
    #Outgoing response schema used for user-related API responses.

    model_config = ConfigDict(from_attributes=True)

    user_id: int
    username: str
    role: str
    created_at: datetime

    @field_serializer('created_at')
    def serialize_created_at(self, value: datetime) -> str:
        """Serialize timestamp with Central Time timezone offset."""
        if value.tzinfo is None:
            # Naive datetime from database is in Central Time
            value = value.replace(tzinfo=ZoneInfo('America/Chicago'))
        return value.isoformat()


class LoginRequest(BaseModel):
    # Incoming request schema used for credential-based login.

    username: str = Field(min_length=1, max_length=50)
    password: str = Field(min_length=1)


class LoginResponse(BaseModel):
    # Outgoing response schema returned when login succeeds.

    message: str
    user: UserResponse
