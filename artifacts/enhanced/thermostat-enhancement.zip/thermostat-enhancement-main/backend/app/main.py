"""FastAPI application entry point."""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import SETTINGS, load_app_config
from app.routes import auth, users, settings, schedules, temperature_logs, activity_logs, thermostat_status

app = FastAPI(title="Thermostat Enhancement Backend", version="0.1.0")


def _load_cors_origins() -> list[str]:
    """Load CORS origins from environment.

    CORS controls which frontend origins can call backend routes.
    Environment-based loading lets this backend run locally or behind Tailscale
    without hard-coding hostnames in source code.
    """

    # Re-read env when needed so tests can validate parsing behavior directly.
    return load_app_config().cors_origins

app.add_middleware(
    CORSMiddleware,
    allow_origins=SETTINGS.cors_origins,
    allow_origin_regex=r"^https?://(localhost|127\.0\.0\.1|0\.0\.0\.0|192\.168\.\d+\.\d+|10\.\d+\.\d+\.\d+|172\.(1[6-9]|2\d|3[0-1])\.\d+\.\d+)(:\d+)?$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Router separation keeps user, settings, logs, and scheduling concerns modular.
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(settings.router)
app.include_router(schedules.router)
app.include_router(temperature_logs.router)
app.include_router(activity_logs.router)
app.include_router(thermostat_status.router)


@app.get("/")
def root() -> dict[str, str]:
    """Return a health-style root response for quick API verification."""

    return {
        "message": "Thermostat backend is running.",
        "note": "Hardware device integration will be added in a later phase.",
    }
