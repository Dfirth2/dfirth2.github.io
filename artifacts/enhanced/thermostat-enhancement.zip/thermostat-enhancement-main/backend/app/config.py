"""Application configuration helpers.

"""

from __future__ import annotations

from dataclasses import dataclass
import os
from typing import Mapping


@dataclass(frozen=True)
class AppConfig:
    """Typed container for backend configuration values."""

    app_env: str
    backend_host: str
    backend_port: int
    database_url: str
    cors_origins: list[str]
    thermostat_connection_timeout_seconds: int
    thermostat_allowed_device_id: str


def _get_env_int(environ: Mapping[str, str], key: str, default: int) -> int:
    """Parse integer env values with a safe default for development."""

    raw = environ.get(key)
    if raw is None or raw.strip() == "":
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _parse_cors_origins(raw: str) -> list[str]:
    """Parse comma-separated CORS origins into a clean list.

    CORS controls which frontend origins are allowed to call backend routes.
    """

    origins = [origin.strip() for origin in raw.split(",") if origin.strip()]
    if origins:
        return origins
    return ["http://localhost:4200", "http://127.0.0.1:4200"]


def load_app_config(environ: Mapping[str, str] | None = None) -> AppConfig:
    """Load backend config from environment variables.

    Safe defaults keep local class development simple while allowing override
    for Tailscale-hosted execution on a separate backend device.
    """

    env = os.environ if environ is None else environ
    return AppConfig(
        app_env=env.get("APP_ENV", "local").strip() or "local",
        backend_host=env.get("BACKEND_HOST", "0.0.0.0").strip() or "0.0.0.0",
        backend_port=max(1, _get_env_int(env, "BACKEND_PORT", 8000)),
        # SQLite remains the default DB for this capstone artifact.
        database_url=env.get("DATABASE_URL", "sqlite:///./thermostat.db").strip() or "sqlite:///./thermostat.db",
        cors_origins=_parse_cors_origins(
            env.get("BACKEND_CORS_ORIGINS", "http://localhost:4200,http://127.0.0.1:4200")
        ),
        thermostat_connection_timeout_seconds=max(
            1,
            _get_env_int(env, "THERMOSTAT_CONNECTION_TIMEOUT_SECONDS", 120),
        ),
        # Development-level device ID allowlist for thermostat heartbeat/status.
        thermostat_allowed_device_id=env.get("THERMOSTAT_ALLOWED_DEVICE_ID", "your-thermostat-device-id").strip() or "your-thermostat-device-id",
    )


SETTINGS = load_app_config()
