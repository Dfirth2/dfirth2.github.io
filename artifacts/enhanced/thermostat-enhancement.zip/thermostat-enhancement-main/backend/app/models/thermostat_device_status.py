"""Thermostat device connection status model.

Stores when the backend last heard from the physical thermostat device.
The status endpoint uses last_seen internally to report connected/disconnected.
"""

from datetime import datetime
from zoneinfo import ZoneInfo

from sqlalchemy import Column, DateTime, Integer, String

from app.database import Base

# Use Central Time (America/Chicago) for all timestamps
CENTRAL_TZ = ZoneInfo("America/Chicago")


class ThermostatDeviceStatus(Base):
    __tablename__ = "thermostat_device_status"

    status_id = Column(Integer, primary_key=True, index=True)
    device_id = Column(String(100), unique=True, nullable=False, index=True)
    last_seen = Column(DateTime, nullable=False, default=lambda: datetime.now(CENTRAL_TZ))
    last_status = Column(String(20), nullable=False, default="online")
    updated_at = Column(DateTime, nullable=False, default=lambda: datetime.now(CENTRAL_TZ), onupdate=lambda: datetime.now(CENTRAL_TZ))
