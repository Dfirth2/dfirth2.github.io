"""Activity log model definition.

"""

from datetime import datetime
from zoneinfo import ZoneInfo

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.database import Base

CENTRAL_TZ = ZoneInfo("America/Chicago")

# activity_logs stores traceable actions tied to user identities.
class ActivityLog(Base):

    __tablename__ = "activity_logs"

    # Primary key for each activity record.
    activity_id = Column(Integer, primary_key=True, index=True)

    # Foreign key links action entries to user records.
    user_id = Column(Integer, ForeignKey("users.user_id"), nullable=False, index=True)

    # action describes the user/system behavior being audited.
    action = Column(String(255), nullable=False)

    # timestamp supports chronological analysis and incident review.
    timestamp = Column(DateTime, nullable=False, default=lambda: datetime.now(CENTRAL_TZ))

    user = relationship("User", back_populates="activity_logs")
