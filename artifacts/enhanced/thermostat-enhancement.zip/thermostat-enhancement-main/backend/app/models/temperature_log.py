"""
Temperature log model definition.

"""

from datetime import datetime
from zoneinfo import ZoneInfo

from sqlalchemy import Column, DateTime, Float, Integer, String

from app.database import Base

CENTRAL_TZ = ZoneInfo("America/Chicago")

# temperature_logs captures historical data points for reporting and debugging.
class TemperatureLog(Base):

    __tablename__ = "temperature_logs"

    # Primary key for each temperature sample.
    log_id = Column(Integer, primary_key=True, index=True)
    temperature = Column(Float, nullable=False)

    # mode and target_temperature provide context at record time.
    mode = Column(String(20), nullable=False, default="off")
    target_temperature = Column(Float, nullable=False, default=72.0)

    # recorded_at identifies exactly when this reading was captured.
    recorded_at = Column(DateTime, nullable=False, default=lambda: datetime.now(CENTRAL_TZ))
