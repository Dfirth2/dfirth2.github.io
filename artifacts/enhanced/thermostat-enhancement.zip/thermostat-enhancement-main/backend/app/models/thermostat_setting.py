"""
Thermostat setting model definition.

"""

from datetime import datetime
from zoneinfo import ZoneInfo

from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.database import Base

CENTRAL_TZ = ZoneInfo("America/Chicago")

# thermostat_settings table stores latest thermostat preference values.
class ThermostatSetting(Base):

    __tablename__ = "thermostat_settings"

    # Primary key for each thermostat setting record.
    setting_id = Column(Integer, primary_key=True, index=True)

    # Foreign key ties each setting to a user account.
    # A unique constraint keeps one current settings row per user in this phase.
    user_id = Column(Integer, ForeignKey("users.user_id"), nullable=False, unique=True, index=True)

    # current_mode is validated in service logic (off/heat/cool).
    current_mode = Column(String(20), nullable=False, default="off")

    # target_temperature is validated against acceptable operational ranges.
    target_temperature = Column(Float, nullable=False, default=72.0)

    # updated_at tracks when settings were last changed.
    updated_at = Column(
        DateTime,
        default=lambda: datetime.now(CENTRAL_TZ),
        onupdate=lambda: datetime.now(CENTRAL_TZ),
        nullable=False,
    )

    # Relationship lets SQLAlchemy join the single current settings row back to its user.
    user = relationship("User", back_populates="settings")
