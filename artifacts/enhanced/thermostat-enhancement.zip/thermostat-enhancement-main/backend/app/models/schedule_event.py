"""
Schedule event model definition.

Weekly schedule enhancement: events now repeat on a fixed day of the week at a
fixed time of day rather than firing once at an absolute datetime.  Separating
day_of_week and event_time from a combined datetime makes the recurring pattern
explicit and avoids date-arithmetic complexity on the read path.
"""

from sqlalchemy import Boolean, Column, Float, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.database import Base

# Valid day names in Sunday-first order.
VALID_DAYS = ("sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday")


# schedule_events stores recurring weekly thermostat actions tied to user accounts.
class ScheduleEvent(Base):

    __tablename__ = "schedule_events"

    # Primary key for each scheduled event.
    event_id = Column(Integer, primary_key=True, index=True)

    # Foreign key indicates event ownership.
    user_id = Column(Integer, ForeignKey("users.user_id"), nullable=False, index=True)

    # day_of_week stores the day name (sunday-saturday) so the schedule repeats
    # every week without needing a full datetime stamp.
    day_of_week = Column(String(10), nullable=False, default="sunday")

    # event_time stores the time of day as "HH:MM" (24-hour, e.g. "07:00").
    # Keeping it separate from day_of_week lets sorting and filtering operate on
    # each dimension independently.
    event_time = Column(String(5), nullable=False, default="07:00")

    mode = Column(String(20), nullable=False, default="off")
    target_temperature = Column(Float, nullable=False, default=72.0)

    # is_active enables soft disabling without deleting historical schedules.
    is_active = Column(Boolean, nullable=False, default=True)

    # Relationship lets SQLAlchemy navigate from an event back to its user.
    user = relationship("User", back_populates="schedule_events")
