"""
User model definition.

"""

from datetime import datetime
from zoneinfo import ZoneInfo

from sqlalchemy import Column, DateTime, Integer, String
from sqlalchemy.orm import relationship

from app.database import Base

CENTRAL_TZ = ZoneInfo("America/Chicago")

# users table stores login identity, role, and account creation metadata.
class User(Base):

    __tablename__ = "users"

    # Primary key for uniquely identifying each user record.
    user_id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, nullable=False, index=True)

    # password_hash stores a cryptographic hash, never a plain-text password.
    password_hash = Column(String(255), nullable=False)

    # role supports basic authorization tiers for Phase 1.
    role = Column(String(20), nullable=False, default="user")

    # Timestamp for auditability and account lifecycle tracking.
    created_at = Column(DateTime, default=lambda: datetime.now(CENTRAL_TZ), nullable=False)

    # Relationship links allow ORM navigation and cascade cleanup behavior.
    # Settings, schedules, and activity logs are all persisted child records tied
    # back to a user for auditing and dashboard retrieval.
    settings = relationship("ThermostatSetting", back_populates="user", cascade="all, delete-orphan")
    schedule_events = relationship("ScheduleEvent", back_populates="user", cascade="all, delete-orphan")
    activity_logs = relationship("ActivityLog", back_populates="user", cascade="all, delete-orphan")
