"""
Database configuration module.

"""

from __future__ import annotations

from typing import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker, Session

from app.config import SETTINGS

# SQLite remains the default for local development and capstone artifact review,
# but DATABASE_URL can override this to reuse the same backend code in other environments.
DATABASE_URL = SETTINGS.database_url

# check_same_thread=False is required for SQLite under FastAPI threaded handling.
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db() -> Generator[Session, None, None]:
    """Provide a database session per request.

    This dependency ensures each request receives an isolated session and that
    sessions are always closed, preventing resource leaks.
    """

    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
