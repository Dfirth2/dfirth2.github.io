"""
from zoneinfo import ZoneInfo
Tests for temperature log routes.

This file ensures temperature history endpoints accept, query, and validate persistent data.
"""

from contextlib import contextmanager
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from urllib.parse import quote

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app.main import app
from app.models.activity_log import ActivityLog
from app.models.thermostat_device_status import ThermostatDeviceStatus
from app.models.temperature_log import TemperatureLog
from app.models.user import User


@contextmanager
def _client_with_db():
    # Create isolated test client and in-memory DB override.

    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Session = sessionmaker(bind=engine)
    Base.metadata.create_all(bind=engine)

    def override_get_db():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    try:
        yield client, Session
    finally:
        client.close()
        app.dependency_overrides.pop(get_db, None)
        engine.dispose()


def test_create_temperature_log_success() -> None:
    # POST /temperature-logs should create a valid log record.

    with _client_with_db() as (client, _):
        response = client.post(
            "/temperature-logs/",
            json={"temperature": 69.5, "mode": "off", "target_temperature": 72},
        )

    assert response.status_code == 201
    assert response.json()["temperature"] == 69.5


def test_create_temperature_log_invalid_mode() -> None:
    # POST /temperature-logs should reject unsupported thermostat modes.

    with _client_with_db() as (client, _):
        response = client.post(
            "/temperature-logs/",
            json={"temperature": 69.5, "mode": "fan", "target_temperature": 72},
        )

    assert response.status_code == 400


def test_list_temperature_logs_supports_recent_and_date_range_queries() -> None:
    # GET /temperature-logs should support ordering, limits, and date-range filtering.

    with _client_with_db() as (client, Session):
        db = Session()
        now = datetime.now(ZoneInfo("America/Chicago"))
        db.add(TemperatureLog(temperature=67, mode="off", target_temperature=72, recorded_at=now - timedelta(hours=2)))
        db.add(TemperatureLog(temperature=68, mode="heat", target_temperature=70, recorded_at=now - timedelta(hours=1)))
        db.add(TemperatureLog(temperature=69, mode="cool", target_temperature=68, recorded_at=now))
        db.commit()
        db.close()

        recent_response = client.get("/temperature-logs/?limit=2")
        range_response = client.get(
            f"/temperature-logs/?start_time={quote((now - timedelta(hours=1, minutes=1)).isoformat())}&order=asc",
        )

    assert recent_response.status_code == 200
    assert len(recent_response.json()) == 2
    assert recent_response.json()[0]["temperature"] == 69
    assert range_response.status_code == 200
    assert len(range_response.json()) == 2
    assert range_response.json()[0]["temperature"] == 68


def test_create_temperature_log_with_user_id_creates_activity_log() -> None:
    # Manual temperature-log creation can also create an audit record when a user ID is provided.

    with _client_with_db() as (client, Session):
        db = Session()
        user = User(username="temploguser", password_hash="hashed", role="user")
        db.add(user)
        db.commit()
        db.refresh(user)
        db.close()

        response = client.post(
            "/temperature-logs/",
            json={"temperature": 71, "mode": "heat", "target_temperature": 72, "user_id": user.user_id},
        )

        db = Session()
        activity_logs = db.query(ActivityLog).filter(ActivityLog.user_id == user.user_id).all()
        db.close()

    assert response.status_code == 201
    assert any("temperature log" in log.action.lower() for log in activity_logs)


def test_create_temperature_log_with_device_id_updates_thermostat_status() -> None:
    # Temperature uploads from thermostat should also count as backend check-ins.

    with _client_with_db() as (client, Session):
        response = client.post(
            "/temperature-logs/",
            json={"temperature": 70, "mode": "heat", "target_temperature": 72, "device_id": "your-thermostat-device-id"},
        )

        db = Session()
        status_row = db.query(ThermostatDeviceStatus).filter(ThermostatDeviceStatus.device_id == "your-thermostat-device-id").first()
        db.close()

    assert response.status_code == 201
    assert status_row is not None
