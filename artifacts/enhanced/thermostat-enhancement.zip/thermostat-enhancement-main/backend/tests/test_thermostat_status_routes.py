"""Tests for thermostat connection status routes."""

from contextlib import contextmanager
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
import os

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.config import load_app_config
from app.database import Base, get_db
from app.main import app
from app.models.thermostat_device_status import ThermostatDeviceStatus

CENTRAL_TZ = ZoneInfo("America/Chicago")
ALLOWED_DEVICE_ID = load_app_config().thermostat_allowed_device_id


@contextmanager
def _client_with_db():
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Session = sessionmaker(bind=engine)
    Base.metadata.create_all(bind=engine)

    def override_get_db():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    try:
        yield client, Session
    finally:
        client.close()
        app.dependency_overrides.pop(get_db, None)
        engine.dispose()


def test_heartbeat_updates_device_status_row() -> None:
    with _client_with_db() as (client, Session):
        response = client.post("/thermostat/heartbeat", json={"device_id": ALLOWED_DEVICE_ID})
        db = Session()
        row = db.query(ThermostatDeviceStatus).filter(ThermostatDeviceStatus.device_id == ALLOWED_DEVICE_ID).first()
        db.close()

    assert response.status_code == 204
    assert row is not None


def test_status_connected_when_recent_heartbeat_exists() -> None:
    with _client_with_db() as (client, Session):
        db = Session()
        db.add(
            ThermostatDeviceStatus(
                device_id=ALLOWED_DEVICE_ID,
                last_seen=datetime.now(CENTRAL_TZ),
                last_status="online",
                updated_at=datetime.now(CENTRAL_TZ),
            )
        )
        db.commit()
        db.close()

        response = client.get(f"/thermostat/status?device_id={ALLOWED_DEVICE_ID}")

    assert response.status_code == 200
    assert response.json()["connected"] is True
    assert response.json()["status_message"] == "Thermostat Connected"


def test_status_disconnected_when_last_seen_is_stale() -> None:
    with _client_with_db() as (client, Session):
        db = Session()
        db.add(
            ThermostatDeviceStatus(
                device_id=ALLOWED_DEVICE_ID,
                last_seen=datetime.now(CENTRAL_TZ) - timedelta(seconds=600),
                last_status="online",
                updated_at=datetime.now(CENTRAL_TZ),
            )
        )
        db.commit()
        db.close()

        response = client.get(f"/thermostat/status?device_id={ALLOWED_DEVICE_ID}")

    assert response.status_code == 200
    assert response.json()["connected"] is False
    assert response.json()["status_message"] == "Thermostat Disconnected"


def test_status_missing_device_returns_disconnected() -> None:
    with _client_with_db() as (client, _):
        response = client.get("/thermostat/status")

    assert response.status_code == 200
    assert response.json() == {
        "device_id": ALLOWED_DEVICE_ID,
        "connected": False,
        "status_message": "Thermostat Disconnected",
    }


def test_status_rejects_non_allowlisted_device_id() -> None:
    with _client_with_db() as (client, _):
        response = client.get("/thermostat/status?device_id=other-device")

    assert response.status_code == 403


def test_heartbeat_rejects_non_allowlisted_device_id() -> None:
    with _client_with_db() as (client, _):
        response = client.post("/thermostat/heartbeat", json={"device_id": "other-device"})

    assert response.status_code == 403


def test_status_timeout_fallback_uses_120_when_env_invalid() -> None:
    os.environ["THERMOSTAT_CONNECTION_TIMEOUT_SECONDS"] = "not-an-int"
    try:
        with _client_with_db() as (client, _):
            response = client.get("/thermostat/status")
    finally:
        os.environ.pop("THERMOSTAT_CONNECTION_TIMEOUT_SECONDS", None)

    assert response.status_code == 200
