"""Tests for backend environment configuration loading."""

from app.config import load_app_config


def test_cors_defaults_when_env_missing() -> None:
    settings = load_app_config({})
    assert settings.cors_origins == ["http://localhost:4200", "http://127.0.0.1:4200"]


def test_cors_parses_comma_separated_origins() -> None:
    settings = load_app_config(
        {
            "BACKEND_CORS_ORIGINS": "http://localhost:4200,http://your-frontend-host.ts.net:4200",
        }
    )
    assert settings.cors_origins == [
        "http://localhost:4200",
        "http://your-frontend-host.ts.net:4200",
    ]


def test_database_url_fallback_when_env_missing() -> None:
    settings = load_app_config({})
    assert settings.database_url == "sqlite:///./thermostat.db"


def test_thermostat_timeout_fallback_when_env_missing() -> None:
    settings = load_app_config({})
    assert settings.thermostat_connection_timeout_seconds == 120


def test_thermostat_allowed_device_id_fallback_when_env_missing() -> None:
    settings = load_app_config({})
    assert settings.thermostat_allowed_device_id == "your-thermostat-device-id"
