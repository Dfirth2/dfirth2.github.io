"""
Tests for thermostat service validation logic.

This file validates allowed modes and target temperature range enforcement.
"""

import pytest

from app.services.thermostat_service import (
    validate_mode,
    validate_target_temperature,
    validate_settings,
)


def test_validate_mode_accepts_supported_values() -> None:
    #validate_mode should normalize and return valid modes.

    assert validate_mode("HEAT") == "heat"
    assert validate_mode("off") == "off"


def test_validate_mode_rejects_invalid_value() -> None:
    #validate_mode should raise ValueError for unsupported modes.

    with pytest.raises(ValueError):
        validate_mode("fan")


def test_validate_target_temperature_accepts_in_range_values() -> None:
    #validate_target_temperature should accept values within bounds.

    assert validate_target_temperature(45.0) == 45.0
    assert validate_target_temperature(90.0) == 90.0


def test_validate_target_temperature_rejects_out_of_range_values() -> None:
    #validate_target_temperature should reject values outside bounds.

    with pytest.raises(ValueError):
        validate_target_temperature(30.0)


def test_validate_settings_returns_validated_tuple() -> None:
    #validate_settings should return validated mode and target pair.

    mode, temp = validate_settings("Cool", 68.0)
    assert mode == "cool"
    assert temp == 68.0
