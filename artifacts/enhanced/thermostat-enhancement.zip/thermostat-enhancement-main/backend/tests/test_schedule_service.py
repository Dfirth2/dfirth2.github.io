"""
Tests for weekly schedule service algorithms.

These tests verify Sunday-through-Saturday sorting, day/mode/active filtering,
conflict detection, and next-event wrap-around logic.
"""

from __future__ import annotations

from app.models.schedule_event import ScheduleEvent
from app.services.schedule_service import (
    DAY_ORDER,
    filter_active_events,
    filter_events_by_day,
    filter_events_by_mode,
    filter_inactive_events,
    get_next_weekly_event,
    has_weekly_schedule_conflict,
    sort_weekly_events,
)


def _event(
    *,
    user_id: int,
    day_of_week: str = "monday",
    event_time: str = "07:00",
    mode: str = "off",
    is_active: bool = True,
    temp: float = 72.0,
) -> ScheduleEvent:
    # Build in-memory ScheduleEvent objects for pure algorithm tests without a DB.

    return ScheduleEvent(
        user_id=user_id,
        day_of_week=day_of_week,
        event_time=event_time,
        mode=mode,
        target_temperature=temp,
        is_active=is_active,
    )


# ── Sorting ──────────────────────────────────────────────────────────────────

def test_sort_weekly_events_sunday_first_order() -> None:
    # Events should come out Sunday-first regardless of insertion order.

    events = [
        _event(user_id=1, day_of_week="saturday", event_time="09:00"),
        _event(user_id=1, day_of_week="sunday",   event_time="07:00"),
        _event(user_id=1, day_of_week="wednesday", event_time="17:30"),
        _event(user_id=1, day_of_week="monday",   event_time="06:30"),
    ]

    sorted_events = sort_weekly_events(events)

    day_order = [e.day_of_week for e in sorted_events]
    assert day_order == ["sunday", "monday", "wednesday", "saturday"]


def test_sort_weekly_events_same_day_sorts_by_time() -> None:
    # When two events fall on the same day, the earlier time should come first.

    events = [
        _event(user_id=1, day_of_week="monday", event_time="08:00"),
        _event(user_id=1, day_of_week="monday", event_time="06:30"),
        _event(user_id=1, day_of_week="monday", event_time="07:00"),
    ]

    sorted_events = sort_weekly_events(events)

    assert [e.event_time for e in sorted_events] == ["06:30", "07:00", "08:00"]


def test_day_order_dict_sunday_first_saturday_last() -> None:
    # Verify the DAY_ORDER dictionary has the expected Sunday-first mapping.

    assert DAY_ORDER["sunday"] == 0
    assert DAY_ORDER["saturday"] == 6
    assert DAY_ORDER["monday"] < DAY_ORDER["friday"]


# ── Filtering ─────────────────────────────────────────────────────────────────

def test_filter_events_by_day_returns_matching_day_only() -> None:
    # Only events on the specified day should be returned.

    events = [
        _event(user_id=1, day_of_week="monday",    event_time="06:30"),
        _event(user_id=1, day_of_week="monday",    event_time="08:00"),
        _event(user_id=1, day_of_week="wednesday", event_time="17:30"),
        _event(user_id=1, day_of_week="friday",    event_time="18:00"),
    ]

    filtered = filter_events_by_day(events, "monday")

    assert len(filtered) == 2
    assert all(e.day_of_week == "monday" for e in filtered)


def test_filter_active_events_returns_only_active() -> None:
    # Active filter should keep only enabled events.

    events = [
        _event(user_id=1, day_of_week="monday", is_active=True),
        _event(user_id=1, day_of_week="tuesday", is_active=False),
    ]

    filtered = filter_active_events(events)

    assert len(filtered) == 1
    assert filtered[0].is_active is True


def test_filter_inactive_events_returns_only_inactive() -> None:
    # Inactive filter should keep only disabled events.

    events = [
        _event(user_id=1, day_of_week="monday", is_active=True),
        _event(user_id=1, day_of_week="tuesday", is_active=False),
    ]

    filtered = filter_inactive_events(events)

    assert len(filtered) == 1
    assert filtered[0].is_active is False


def test_filter_events_by_mode_returns_matching_mode() -> None:
    # Mode filter should return only events with the selected thermostat mode.

    events = [
        _event(user_id=1, day_of_week="sunday",    mode="heat"),
        _event(user_id=1, day_of_week="monday",    mode="cool"),
        _event(user_id=1, day_of_week="wednesday", mode="off"),
    ]

    filtered = filter_events_by_mode(events, "cool")

    assert len(filtered) == 1
    assert filtered[0].mode == "cool"


# ── Conflict detection ────────────────────────────────────────────────────────

def test_conflict_returns_false_when_no_conflict() -> None:
    # Different times on the same day should not conflict.

    existing = [_event(user_id=1, day_of_week="monday", event_time="06:30", is_active=True)]
    new_event = _event(user_id=1, day_of_week="monday", event_time="08:00", is_active=True)

    assert has_weekly_schedule_conflict(existing, new_event, user_id=1) is False


def test_conflict_returns_true_for_same_day_and_time() -> None:
    # Same user + same day + same time + both active should conflict.

    existing = [_event(user_id=1, day_of_week="friday", event_time="18:00", is_active=True)]
    new_event  = _event(user_id=1, day_of_week="friday", event_time="18:00", is_active=True)

    assert has_weekly_schedule_conflict(existing, new_event, user_id=1) is True


def test_conflict_returns_false_different_days() -> None:
    # Same time on a different day should not conflict.

    existing = [_event(user_id=1, day_of_week="monday", event_time="07:00", is_active=True)]
    new_event  = _event(user_id=1, day_of_week="tuesday", event_time="07:00", is_active=True)

    assert has_weekly_schedule_conflict(existing, new_event, user_id=1) is False


def test_conflict_ignores_inactive_existing_event() -> None:
    # Inactive events must not block creation of an active event at the same slot.

    existing = [_event(user_id=1, day_of_week="monday", event_time="07:00", is_active=False)]
    new_event  = _event(user_id=1, day_of_week="monday", event_time="07:00", is_active=True)

    assert has_weekly_schedule_conflict(existing, new_event, user_id=1) is False


def test_conflict_applies_only_to_same_user() -> None:
    # Two different users may have events on the same day and time.

    existing = [_event(user_id=2, day_of_week="monday", event_time="07:00", is_active=True)]
    new_event  = _event(user_id=1, day_of_week="monday", event_time="07:00", is_active=True)

    assert has_weekly_schedule_conflict(existing, new_event, user_id=1) is False


# ── Next-event identification ─────────────────────────────────────────────────

def test_next_event_returns_later_event_same_day() -> None:
    # Later event on the same day should be returned when current time is before it.

    events = [
        _event(user_id=1, day_of_week="monday", event_time="06:30", is_active=True),
        _event(user_id=1, day_of_week="monday", event_time="08:00", is_active=True),
    ]

    # Current day is Monday 07:00 – 06:30 is past, 08:00 should be next.
    result = get_next_weekly_event(events, current_day="monday", current_time="07:00")

    assert result is not None
    assert result.event_time == "08:00"


def test_next_event_returns_event_on_later_day() -> None:
    # When no events remain today, next event should come from a later day this week.

    events = [
        _event(user_id=1, day_of_week="monday",   event_time="06:30", is_active=True),
        _event(user_id=1, day_of_week="wednesday", event_time="17:30", is_active=True),
    ]

    # Current day is Monday 09:00 – only Wednesday event is ahead.
    result = get_next_weekly_event(events, current_day="monday", current_time="09:00")

    assert result is not None
    assert result.day_of_week == "wednesday"


def test_next_event_wraps_around_saturday_to_sunday() -> None:
    # When no events remain later in the week, wrap-around should find Sunday's event.

    events = [
        _event(user_id=1, day_of_week="sunday",   event_time="07:00", is_active=True),
        _event(user_id=1, day_of_week="saturday",  event_time="09:00", is_active=True),
    ]

    # Current day is Saturday 10:00 – Saturday 09:00 is past, so wrap to Sunday.
    result = get_next_weekly_event(events, current_day="saturday", current_time="10:00")

    assert result is not None
    assert result.day_of_week == "sunday"
    assert result.event_time == "07:00"


def test_next_event_ignores_inactive_events() -> None:
    # Inactive events should never be returned as the next event.

    events = [
        _event(user_id=1, day_of_week="monday", event_time="08:00", is_active=False),
        _event(user_id=1, day_of_week="tuesday", event_time="07:00", is_active=True),
    ]

    result = get_next_weekly_event(events, current_day="monday", current_time="07:00")

    assert result is not None
    assert result.day_of_week == "tuesday"


def test_next_event_returns_none_when_no_active_events() -> None:
    # If all events are inactive, None should be returned.

    events = [
        _event(user_id=1, day_of_week="monday", event_time="07:00", is_active=False),
    ]

    assert get_next_weekly_event(events, current_day="monday", current_time="06:00") is None
