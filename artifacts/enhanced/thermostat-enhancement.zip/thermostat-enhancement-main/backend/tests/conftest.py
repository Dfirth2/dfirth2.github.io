"""
Pytest shared configuration.

Purpose:
- Ensure backend package imports are stable across local/server environments.
- Keep test execution consistent when invoked from different working directories.
"""

from pathlib import Path
import sys

# Add backend root to sys.path so `app` and `scripts` packages import reliably.
BACKEND_ROOT = Path(__file__).resolve().parents[1]
if str(BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(BACKEND_ROOT))
