"""
Tests for authentication helper utilities.

This file verifies password hashing and verification correctness.
"""

from app.auth import hash_password, verify_password


def test_hash_password_returns_non_plain_text() -> None:
    # Hashing should return a value different from the raw password.

    plain = "admin123"
    hashed = hash_password(plain)

    # Hash output should not equal source input for security.
    assert hashed != plain
    assert hashed.startswith("$")


def test_verify_password_accepts_valid_password() -> None:
    # Verification should succeed for matching password/hash pairs.

    plain = "securePass123"
    hashed = hash_password(plain)
    assert verify_password(plain, hashed) is True


def test_verify_password_rejects_invalid_password() -> None:
    # Verification should fail for non-matching passwords.

    hashed = hash_password("securePass123")
    assert verify_password("wrongPass123", hashed) is False
