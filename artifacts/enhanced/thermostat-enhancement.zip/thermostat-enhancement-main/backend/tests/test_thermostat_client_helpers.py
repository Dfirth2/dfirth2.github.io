"""Unit tests for Raspberry Pi thermostat client helper logic.

These tests cover only pure helper functions so they run without GPIO/LCD/sensor
hardware in CI and local development environments.
"""

from __future__ import annotations

import importlib.util
import sys
from datetime import datetime
from pathlib import Path


MODULE_PATH = Path(__file__).resolve().parents[2] / "thermostat" / "DayneFirth-Thermostat.py"
SPEC = importlib.util.spec_from_file_location("thermostat_client", MODULE_PATH)
thermostat_client = importlib.util.module_from_spec(SPEC)
assert SPEC and SPEC.loader
sys.modules[SPEC.name] = thermostat_client
SPEC.loader.exec_module(thermostat_client)


def test_validate_mode_accepts_valid_modes() -> None:
    assert thermostat_client.validate_mode("off")
    assert thermostat_client.validate_mode("heat")
    assert thermostat_client.validate_mode("cool")


def test_validate_mode_rejects_invalid_modes() -> None:
    assert not thermostat_client.validate_mode("fan")
    assert not thermostat_client.validate_mode("")
    assert not thermostat_client.validate_mode(None)


def test_validate_target_temperature_bounds() -> None:
    assert thermostat_client.validate_target_temperature(72)
    assert thermostat_client.validate_target_temperature(45)
    assert thermostat_client.validate_target_temperature(90)


def test_validate_target_temperature_rejects_bad_values() -> None:
    assert not thermostat_client.validate_target_temperature(44)
    assert not thermostat_client.validate_target_temperature(91)
    assert not thermostat_client.validate_target_temperature("not-a-number")


def test_heat_cool_decision_logic() -> None:
    assert thermostat_client.should_heat(current_temp=68, target_temp=72, mode="heat")
    assert not thermostat_client.should_heat(current_temp=74, target_temp=72, mode="heat")
    assert thermostat_client.should_cool(current_temp=76, target_temp=72, mode="cool")
    assert not thermostat_client.should_cool(current_temp=70, target_temp=72, mode="cool")


def test_off_mode_disables_heat_and_cool_decisions() -> None:
    assert not thermostat_client.should_heat(current_temp=60, target_temp=72, mode="off")
    assert not thermostat_client.should_cool(current_temp=80, target_temp=72, mode="off")


def test_parse_backend_settings_valid_payload() -> None:
    payload = {"current_mode": "heat", "target_temperature": 70}
    parsed = thermostat_client.parse_backend_settings(payload)
    assert parsed == {"current_mode": "heat", "target_temperature": 70.0}


def test_parse_backend_settings_rejects_invalid_payload() -> None:
    assert thermostat_client.parse_backend_settings({"current_mode": "fan", "target_temperature": 70}) is None
    assert thermostat_client.parse_backend_settings({"current_mode": "heat", "target_temperature": 5}) is None
    assert thermostat_client.parse_backend_settings(None) is None


def test_format_temperature_payload_shape() -> None:
    payload = thermostat_client.format_temperature_payload(
        temperature=71.5,
        mode="cool",
        target_temperature=69.0,
        user_id=1,
        recorded_at="2026-06-06T12:00:00",
    )
    assert payload["temperature"] == 71.5
    assert payload["mode"] == "cool"
    assert payload["target_temperature"] == 69.0
    assert payload["user_id"] == 1
    assert payload["recorded_at"] == "2026-06-06T12:00:00"


def test_parse_next_event_valid_and_invalid_payloads() -> None:
    valid = {
        "day_of_week": "monday",
        "event_time": "08:00",
        "mode": "heat",
        "target_temperature": 70,
        "is_active": True,
    }
    parsed_valid = thermostat_client.parse_next_event(valid)
    assert parsed_valid is not None
    assert parsed_valid["mode"] == "heat"

    invalid = {
        "day_of_week": "monday",
        "event_time": "8am",
        "mode": "heat",
        "target_temperature": 70,
        "is_active": True,
    }
    assert thermostat_client.parse_next_event(invalid) is None


def test_backend_error_handler_does_not_raise() -> None:
    context = thermostat_client.BackendContext(available=True, last_error="")
    result = thermostat_client.handle_backend_error(context, "unit_test", RuntimeError("network down"))
    assert context.available is False
    assert "unit_test failed" in context.last_error
    assert result["status"] == "error"


def test_runtime_config_uses_environment_backend_url_when_set() -> None:
    config = thermostat_client.load_runtime_config(
        {
            "THERMOSTAT_BACKEND_BASE_URL": "http://example-backend:9000",
            "THERMOSTAT_DEVICE_ID": "test-device",
        }
    )
    assert config["BACKEND_BASE_URL"] == "http://example-backend:9000"
    assert config["DEVICE_ID"] == "test-device"


def test_runtime_config_falls_back_to_localhost_when_missing() -> None:
    config = thermostat_client.load_runtime_config({})
    assert config["BACKEND_BASE_URL"] == "http://localhost:8000"


def test_runtime_config_parses_numeric_values() -> None:
    config = thermostat_client.load_runtime_config(
        {
            "THERMOSTAT_API_TIMEOUT_SECONDS": "7",
            "THERMOSTAT_SYNC_INTERVAL_SECONDS": "45",
            "THERMOSTAT_HEARTBEAT_INTERVAL_SECONDS": "15",
            "THERMOSTAT_TEMP_LOG_INTERVAL_SECONDS": "600",
            "THERMOSTAT_DEFAULT_TARGET_TEMPERATURE": "70.5",
        }
    )
    assert config["API_TIMEOUT_SECONDS"] == 7
    assert config["SYNC_INTERVAL_SECONDS"] == 45
    assert config["HEARTBEAT_INTERVAL_SECONDS"] == 15
    assert config["TEMP_LOG_INTERVAL_SECONDS"] == 600
    assert config["DEFAULT_TARGET_TEMPERATURE"] == 70.5


def test_format_heartbeat_payload_shape() -> None:
    payload = thermostat_client.format_heartbeat_payload("your-thermostat-device-id")
    assert payload == {"device_id": "your-thermostat-device-id"}


def test_send_heartbeat_failure_is_non_fatal() -> None:
    class _FailingSession:
        def post(self, *_args, **_kwargs):
            raise thermostat_client.requests.RequestException("offline")

    context = thermostat_client.BackendContext(available=True, last_error="")
    result = thermostat_client.send_heartbeat(_FailingSession(), context, "your-thermostat-device-id")
    assert result is False
    assert context.available is False
    assert "send_heartbeat failed" in context.last_error


class _DisplayStub:
    def update_screen(self, _message: str) -> None:
        return

    def cleanup(self) -> None:
        return


class _LedStub:
    def __init__(self) -> None:
        self.state = "off"

    def on(self) -> None:
        self.state = "on"

    def off(self) -> None:
        self.state = "off"

    def pulse(self) -> None:
        self.state = "pulse"


def _build_controller() -> object:
    return thermostat_client.ThermostatController(
        sensor=None,
        display=_DisplayStub(),
        red_led=_LedStub(),
        blue_led=_LedStub(),
    )


def test_local_button_change_starts_manual_override() -> None:
    controller = _build_controller()
    controller.push_local_override_to_backend = lambda *_args, **_kwargs: True
    controller.log_local_override_activity = lambda _msg: True

    changed = controller.apply_local_button_change(mode="heat", target_temperature=71)
    assert changed is True
    assert controller.manual_override_active is True
    assert controller.manual_override_mode == "heat"
    assert controller.manual_override_target_temperature == 71


def test_manual_override_priority_over_backend_settings() -> None:
    controller = _build_controller()
    controller.manual_override_active = True
    controller.manual_override_mode = "cool"
    controller.manual_override_target_temperature = 66

    controller.apply_backend_settings({"current_mode": "heat", "target_temperature": 75})
    assert controller.get_effective_mode() == "cool"
    assert controller.get_effective_target_temperature() == 66


def test_local_button_mode_change_calls_backend_sync_helper() -> None:
    controller = _build_controller()
    calls: list[tuple[str, float]] = []
    controller.log_local_override_activity = lambda _msg: True
    controller.push_local_override_to_backend = lambda mode, target: calls.append((mode, target)) or True

    controller.apply_local_button_change(mode="heat")
    assert len(calls) == 1
    assert calls[0][0] == "heat"


def test_local_button_target_change_calls_backend_sync_helper() -> None:
    controller = _build_controller()
    calls: list[tuple[str, float]] = []
    controller.log_local_override_activity = lambda _msg: True
    controller.push_local_override_to_backend = lambda mode, target: calls.append((mode, target)) or True

    controller.apply_local_button_change(target_temperature=68)
    assert len(calls) == 1
    assert calls[0][1] == 68


def test_backend_sync_failure_keeps_manual_override_and_sets_pending_sync() -> None:
    controller = _build_controller()
    controller.log_local_override_activity = lambda _msg: True
    controller.push_local_override_to_backend = lambda *_args, **_kwargs: False

    controller.apply_local_button_change(mode="heat", target_temperature=70)
    assert controller.manual_override_active is True
    assert controller.manual_override_pending_sync is True


def test_successful_retry_clears_pending_sync() -> None:
    controller = _build_controller()
    controller.manual_override_active = True
    controller.manual_override_mode = "heat"
    controller.manual_override_target_temperature = 69
    controller.manual_override_pending_sync = True
    controller.push_local_override_to_backend = lambda *_args, **_kwargs: True

    assert controller.retry_pending_manual_override_sync() is True


def test_scheduled_event_clears_manual_override_and_applies_schedule() -> None:
    controller = _build_controller()
    controller.manual_override_active = True
    controller.manual_override_mode = "cool"
    controller.manual_override_target_temperature = 66
    controller.log_local_override_activity = lambda _msg: True
    controller.push_local_override_to_backend = lambda *_args, **_kwargs: True

    sync_state = thermostat_client.SyncState()
    now = datetime.now()
    today = thermostat_client.day_name_from_datetime(now)
    event_time = now.strftime("%H:%M")
    event = {
        "event_id": 77,
        "day_of_week": today,
        "event_time": event_time,
        "mode": "heat",
        "target_temperature": 73,
        "is_active": True,
    }

    applied = controller.apply_scheduled_event(event, sync_state)
    assert applied is True
    assert controller.manual_override_active is False
    assert controller.mode == "heat"
    assert controller.target_temperature == 73


def test_scheduled_event_pushes_setting_and_not_reapplied() -> None:
    controller = _build_controller()
    calls: list[tuple[str, float]] = []
    controller.log_local_override_activity = lambda _msg: True
    controller.push_local_override_to_backend = lambda mode, target: calls.append((mode, target)) or True

    sync_state = thermostat_client.SyncState()
    now = datetime.now()
    event = {
        "event_id": 9,
        "day_of_week": thermostat_client.day_name_from_datetime(now),
        "event_time": now.strftime("%H:%M"),
        "mode": "cool",
        "target_temperature": 67,
        "is_active": True,
    }

    first_applied = controller.apply_scheduled_event(event, sync_state)
    second_applied = controller.apply_scheduled_event(event, sync_state)

    assert first_applied is True
    assert second_applied is False
    assert len(calls) == 1


def test_invalid_manual_override_inputs_are_rejected() -> None:
    controller = _build_controller()
    controller.log_local_override_activity = lambda _msg: True
    controller.push_local_override_to_backend = lambda *_args, **_kwargs: True

    assert controller.apply_local_button_change(mode="fan", target_temperature=72) is False
    assert controller.apply_local_button_change(mode="heat", target_temperature=999) is False


def test_has_scheduled_event_triggered_comparison_helper() -> None:
    event = {
        "event_id": 101,
        "day_of_week": "monday",
        "event_time": "08:00",
        "mode": "heat",
        "target_temperature": 70,
        "is_active": True,
    }
    assert thermostat_client.has_scheduled_event_triggered(event, "monday", "08:00") is True
    assert thermostat_client.has_scheduled_event_triggered(event, "monday", "07:59") is False
