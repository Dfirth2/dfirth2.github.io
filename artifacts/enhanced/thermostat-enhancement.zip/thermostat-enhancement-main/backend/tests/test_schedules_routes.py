"""
Tests for weekly schedule event routes.

These tests verify Sunday-through-Saturday sorting, day/mode/active filtering,
conflict validation, next-event logic, CRUD operations, and audit logging.
"""

from contextlib import contextmanager

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app.main import app
from app.models.activity_log import ActivityLog
from app.models.schedule_event import ScheduleEvent
from app.models.user import User


@contextmanager
def _client_with_db():
    # Create test client and dependency override for an isolated in-memory DB.

    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Session = sessionmaker(bind=engine)
    Base.metadata.create_all(bind=engine)

    def override_get_db():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    try:
        yield client, Session
    finally:
        client.close()
        app.dependency_overrides.pop(get_db, None)
        engine.dispose()


def _seed_user(session, username: str) -> User:
    # Create and return a user for schedule route tests.

    user = User(username=username, password_hash="hashed", role="user")
    session.add(user)
    session.commit()
    session.refresh(user)
    return user


def _seed_event(
    session,
    *,
    user_id: int,
    day_of_week: str = "monday",
    event_time: str = "07:00",
    mode: str = "cool",
    target_temperature: float = 68.0,
    is_active: bool = True,
) -> ScheduleEvent:
    # Seed a weekly schedule row in the in-memory DB for route verification.

    event = ScheduleEvent(
        user_id=user_id,
        day_of_week=day_of_week,
        event_time=event_time,
        mode=mode,
        target_temperature=target_temperature,
        is_active=is_active,
    )
    session.add(event)
    session.commit()
    session.refresh(event)
    return event


# ── Sorting ───────────────────────────────────────────────────────────────────

def test_list_schedule_events_returns_sunday_first_order() -> None:
    # GET /schedules/ should return events sorted Sunday through Saturday, then by time.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "scheduser")

        _seed_event(db, user_id=user.user_id, day_of_week="saturday",  event_time="09:00")
        _seed_event(db, user_id=user.user_id, day_of_week="sunday",    event_time="07:00")
        _seed_event(db, user_id=user.user_id, day_of_week="wednesday", event_time="17:30")
        _seed_event(db, user_id=user.user_id, day_of_week="monday",    event_time="06:30")
        db.close()

        response = client.get("/schedules/")

    assert response.status_code == 200
    days = [item["day_of_week"] for item in response.json()]
    assert days == ["sunday", "monday", "wednesday", "saturday"]


# ── Filtering ─────────────────────────────────────────────────────────────────

def test_list_schedule_events_active_filter() -> None:
    # active=true should return only active events.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "activefilteruser")

        _seed_event(db, user_id=user.user_id, day_of_week="monday", is_active=True)
        _seed_event(db, user_id=user.user_id, day_of_week="tuesday", is_active=False)
        db.close()

        response = client.get("/schedules/?active=true")

    assert response.status_code == 200
    payload = response.json()
    assert len(payload) == 1
    assert payload[0]["is_active"] is True


def test_list_schedule_events_day_filter() -> None:
    # day=monday should return only Monday events.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "dayfilteruser")

        _seed_event(db, user_id=user.user_id, day_of_week="monday",    event_time="06:30", mode="heat")
        _seed_event(db, user_id=user.user_id, day_of_week="monday",    event_time="08:00", mode="off")
        _seed_event(db, user_id=user.user_id, day_of_week="wednesday", event_time="17:30", mode="heat")
        db.close()

        response = client.get("/schedules/?day=monday")

    assert response.status_code == 200
    payload = response.json()
    assert len(payload) == 2
    assert all(item["day_of_week"] == "monday" for item in payload)


def test_list_schedule_events_mode_filter() -> None:
    # mode=heat should return only heat events.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "modefilteruser")

        _seed_event(db, user_id=user.user_id, day_of_week="monday",    event_time="06:30", mode="heat")
        _seed_event(db, user_id=user.user_id, day_of_week="wednesday", event_time="17:30", mode="cool")
        _seed_event(db, user_id=user.user_id, day_of_week="friday",    event_time="18:00", mode="heat")
        db.close()

        response = client.get("/schedules/?mode=heat")

    assert response.status_code == 200
    payload = response.json()
    assert len(payload) == 2
    assert all(item["mode"] == "heat" for item in payload)


# ── Next event ────────────────────────────────────────────────────────────────

def test_next_schedule_event_returns_closest_later_event() -> None:
    # /schedules/next should find the next active event from the supplied day/time.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "nextuser")
        user_id = user.user_id

        _seed_event(db, user_id=user.user_id, day_of_week="monday", event_time="06:30", is_active=True)
        _seed_event(db, user_id=user.user_id, day_of_week="monday", event_time="08:00", is_active=True, mode="heat")
        _seed_event(db, user_id=user.user_id, day_of_week="friday", event_time="18:00", is_active=False)
        db.close()

        response = client.get(f"/schedules/next?user_id={user_id}&current_day=monday&current_time=07:00")

    assert response.status_code == 200
    payload = response.json()
    assert payload is not None
    assert payload["event_time"] == "08:00"
    assert payload["mode"] == "heat"


def test_next_schedule_event_wraps_saturday_to_sunday() -> None:
    # Wrap-around: when no events remain later in the week, start from Sunday.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "wrapuser")
        user_id = user.user_id

        _seed_event(db, user_id=user.user_id, day_of_week="sunday",   event_time="07:00", is_active=True, mode="heat")
        _seed_event(db, user_id=user.user_id, day_of_week="saturday", event_time="09:00", is_active=True, mode="off")
        db.close()

        # Saturday at 10:00 – the Saturday 09:00 event is already past, wrap to Sunday.
        response = client.get(f"/schedules/next?user_id={user_id}&current_day=saturday&current_time=10:00")

    assert response.status_code == 200
    payload = response.json()
    assert payload is not None
    assert payload["day_of_week"] == "sunday"


def test_next_schedule_event_returns_none_when_no_active_events() -> None:
    # No active events means next endpoint should return null.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "noneuser")
        user_id = user.user_id

        _seed_event(db, user_id=user.user_id, day_of_week="monday", event_time="07:00", is_active=False)
        db.close()

        response = client.get(f"/schedules/next?user_id={user_id}&current_day=sunday&current_time=00:00")

    assert response.status_code == 200
    assert response.json() is None


# ── Conflict validation ───────────────────────────────────────────────────────

def test_create_schedule_event_rejects_same_day_time_conflict() -> None:
    # Creating an active event on the same day/time for the same user should return 409.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "conflictuser")
        user_id = user.user_id

        _seed_event(db, user_id=user.user_id, day_of_week="monday", event_time="07:00", is_active=True)
        db.close()

        response = client.post(
            "/schedules/",
            json={
                "user_id": user_id,
                "day_of_week": "monday",
                "event_time": "07:00",
                "mode": "cool",
                "target_temperature": 68,
                "is_active": True,
            },
        )

    assert response.status_code == 409
    assert "Schedule conflict" in response.json()["detail"]


def test_create_schedule_event_allows_different_day_same_time() -> None:
    # Same time on a different day should not conflict.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "nodiffconflict")
        user_id = user.user_id

        _seed_event(db, user_id=user.user_id, day_of_week="monday", event_time="07:00", is_active=True)
        db.close()

        response = client.post(
            "/schedules/",
            json={
                "user_id": user_id,
                "day_of_week": "tuesday",
                "event_time": "07:00",
                "mode": "heat",
                "target_temperature": 70,
                "is_active": True,
            },
        )

    assert response.status_code == 201


def test_create_schedule_event_inactive_existing_does_not_conflict() -> None:
    # An inactive existing event should allow a new active event at the same slot.

    with _client_with_db() as (client, Session):
        db = Session()
        user_a = _seed_user(db, "usera")
        user_b = _seed_user(db, "userb")
        user_a_id = user_a.user_id

        # user_a's Monday 07:00 is inactive; user_b's is active.
        _seed_event(db, user_id=user_a.user_id, day_of_week="monday", event_time="07:00", is_active=False)
        _seed_event(db, user_id=user_b.user_id, day_of_week="monday", event_time="07:00", is_active=True)
        db.close()

        response = client.post(
            "/schedules/",
            json={
                "user_id": user_a_id,
                "day_of_week": "monday",
                "event_time": "07:00",
                "mode": "heat",
                "target_temperature": 70,
                "is_active": True,
            },
        )

    assert response.status_code == 201
    assert response.json()["user_id"] == user_a_id


# ── CRUD operations ───────────────────────────────────────────────────────────

def test_create_and_get_schedule_event_by_id() -> None:
    # POST then GET should return the persisted weekly schedule event.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "getscheduleuser")
        event = _seed_event(db, user_id=user.user_id, day_of_week="friday", event_time="18:00", mode="cool")
        event_id = event.event_id
        db.close()

        response = client.get(f"/schedules/{event_id}")

    assert response.status_code == 200
    payload = response.json()
    assert payload["event_id"] == event_id
    assert payload["day_of_week"] == "friday"
    assert payload["event_time"] == "18:00"


def test_patch_schedule_event_updates_mode_and_logs_activity() -> None:
    # PATCH should persist the field change and create an audit record.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "patchuser")
        event = _seed_event(db, user_id=user.user_id, day_of_week="monday", event_time="07:00", mode="heat")
        event_id = event.event_id
        user_id = user.user_id
        db.close()

        response = client.patch(f"/schedules/{event_id}", json={"mode": "cool", "target_temperature": 67})

        db = Session()
        updated = db.query(ScheduleEvent).filter(ScheduleEvent.event_id == event_id).first()
        logs = db.query(ActivityLog).filter(ActivityLog.user_id == user_id).all()
        db.close()

    assert response.status_code == 200
    assert updated is not None
    assert updated.mode == "cool"
    assert any(f"Updated weekly schedule event {event_id}" in log.action for log in logs)


def test_deactivate_schedule_event_sets_inactive_flag() -> None:
    # Deactivation should preserve the row in SQLite but mark is_active=False.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "deactivateuser")
        event = _seed_event(db, user_id=user.user_id, day_of_week="monday", event_time="07:00", mode="heat")
        event_id = event.event_id
        db.close()

        response = client.patch(f"/schedules/{event_id}/deactivate")

        db = Session()
        updated = db.query(ScheduleEvent).filter(ScheduleEvent.event_id == event_id).first()
        db.close()

    assert response.status_code == 200
    assert updated is not None
    assert updated.is_active is False


def test_delete_schedule_event_removes_row_and_keeps_audit_entry() -> None:
    # DELETE should remove the row while the audit log entry is preserved.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "deleteuser")
        user_id = user.user_id
        event = _seed_event(db, user_id=user.user_id, day_of_week="saturday", event_time="09:00", mode="off")
        event_id = event.event_id
        db.close()

        response = client.delete(f"/schedules/{event_id}")

        db = Session()
        deleted = db.query(ScheduleEvent).filter(ScheduleEvent.event_id == event_id).first()
        logs = db.query(ActivityLog).filter(ActivityLog.user_id == user_id).all()
        db.close()

    assert response.status_code == 204
    assert deleted is None
    assert any(f"Deleted weekly schedule event {event_id}" in log.action for log in logs)
