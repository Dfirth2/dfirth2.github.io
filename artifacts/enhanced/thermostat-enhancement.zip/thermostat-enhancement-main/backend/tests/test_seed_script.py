"""
Tests for the development seed script.

These tests verify idempotent demo-data creation for database enhancement work.
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base
from app.models import ActivityLog, ScheduleEvent, TemperatureLog, ThermostatSetting, User
from scripts import seed as seed_module


def test_seed_database_creates_demo_records_without_duplicates(monkeypatch) -> None:
    # The seed script should be safe to run more than once in development.

    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Session = sessionmaker(bind=engine)
    Base.metadata.create_all(bind=engine)

    monkeypatch.setattr(seed_module, "engine", engine)
    monkeypatch.setattr(seed_module, "SessionLocal", Session)

    seed_module.seed_database()
    seed_module.seed_database()

    db = Session()
    try:
        users = db.query(User).all()
        settings = db.query(ThermostatSetting).all()
        schedules = db.query(ScheduleEvent).all()
        temperature_logs = db.query(TemperatureLog).all()
        activity_logs = db.query(ActivityLog).all()
    finally:
        db.close()
        engine.dispose()

    usernames = sorted(user.username for user in users)
    assert usernames == ["admin", "user1"]
    assert len(settings) == 2
    # Seed now creates 8 weekly schedule events across multiple days.
    assert len(schedules) == 8
    assert len(temperature_logs) == 3
    assert len(activity_logs) == 3
    # Verify weekly schedule fields are present on seeded rows.
    days = {s.day_of_week for s in schedules}
    assert len(days) > 1, "Seed should create events across multiple days of the week."
    assert all(s.event_time for s in schedules), "Every seeded event must have an event_time."
