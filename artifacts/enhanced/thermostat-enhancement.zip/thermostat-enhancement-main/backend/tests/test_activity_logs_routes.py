"""
Tests for activity log routes.

This file verifies manual activity logging, filtering, and user validation.
"""

from contextlib import contextmanager

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app.main import app
from app.models.activity_log import ActivityLog
from app.models.user import User


@contextmanager
def _client_with_db():
    # Create test client with dependency override using in-memory SQLite.

    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Session = sessionmaker(bind=engine)
    Base.metadata.create_all(bind=engine)

    def override_get_db():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    try:
        yield client, Session
    finally:
        client.close()
        app.dependency_overrides.pop(get_db, None)
        engine.dispose()


def _seed_user(session, username: str) -> User:
    # Create and return a persistent user for activity log tests.

    user = User(username=username, password_hash="hashed", role="user")
    session.add(user)
    session.commit()
    session.refresh(user)
    return user


def test_create_activity_log_success() -> None:
    # POST /activity-logs should persist a manual audit row for a valid user.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "audituser")
        db.close()

        response = client.post(
            "/activity-logs/",
            json={"user_id": user.user_id, "action": "Changed target temperature"},
        )

    assert response.status_code == 201
    assert response.json()["action"] == "Changed target temperature"


def test_create_activity_log_user_not_found() -> None:
    # Manual activity creation should fail when the user does not exist.

    with _client_with_db() as (client, _):
        response = client.post(
            "/activity-logs/",
            json={"user_id": 9999, "action": "Attempted action"},
        )

    assert response.status_code == 404


def test_list_activity_logs_supports_user_filter_and_recent_order() -> None:
    # GET /activity-logs should return most recent rows first and allow user filtering.

    with _client_with_db() as (client, Session):
        db = Session()
        user_a = _seed_user(db, "activitya")
        user_b = _seed_user(db, "activityb")
        user_a_id = user_a.user_id
        db.add(ActivityLog(user_id=user_a.user_id, action="Older action"))
        db.commit()
        db.add(ActivityLog(user_id=user_b.user_id, action="Newest action"))
        db.commit()
        db.close()

        all_response = client.get("/activity-logs/?limit=1")
        filtered_response = client.get(f"/activity-logs/?user_id={user_a_id}")

    assert all_response.status_code == 200
    assert len(all_response.json()) == 1
    assert all_response.json()[0]["action"] == "Newest action"
    assert filtered_response.status_code == 200
    assert len(filtered_response.json()) == 1
    assert filtered_response.json()[0]["user_id"] == user_a_id
