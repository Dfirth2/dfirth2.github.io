"""
Tests for SQLAlchemy model creation and key relationships.

This file confirms database tables and model-level persistence behavior.
"""

from sqlalchemy import create_engine, inspect
from sqlalchemy.orm import sessionmaker

from app.database import Base
from app.models import User, ThermostatSetting, ScheduleEvent, TemperatureLog, ActivityLog, ThermostatDeviceStatus


def test_all_expected_tables_exist() -> None:
    # Metadata should create all thermostat backend tables.

    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(bind=engine)

    inspector = inspect(engine)
    table_names = set(inspector.get_table_names())

    # Confirm all required domain tables are present.
    assert {
        "users",
        "thermostat_settings",
        "schedule_events",
        "temperature_logs",
        "activity_logs",
        "thermostat_device_status",
    }.issubset(
        table_names
    )
    engine.dispose()


def test_models_can_be_persisted_with_relationships() -> None:
    # Core models should persist and load with expected relationships.

    engine = create_engine("sqlite:///:memory:")
    Session = sessionmaker(bind=engine)
    Base.metadata.create_all(bind=engine)
    db = Session()

    user = User(username="modeluser", password_hash="hashed", role="user")
    db.add(user)
    db.commit()
    db.refresh(user)

    db.add(ThermostatSetting(user_id=user.user_id, current_mode="off", target_temperature=72.0))
    db.add(ScheduleEvent(user_id=user.user_id, mode="heat", target_temperature=70.0))
    db.add(TemperatureLog(temperature=68.0, mode="off", target_temperature=72.0))
    db.add(ActivityLog(user_id=user.user_id, action="Created test records"))
    db.add(ThermostatDeviceStatus(device_id="your-thermostat-device-id"))
    db.commit()

    loaded_user = db.query(User).filter(User.username == "modeluser").first()
    # Relationship checks ensure foreign key wiring is functioning.
    assert loaded_user is not None
    assert len(loaded_user.settings) == 1
    assert len(loaded_user.schedule_events) == 1
    assert len(loaded_user.activity_logs) == 1
    db.close()
    engine.dispose()
