"""
Tests for FastAPI app startup and root endpoint behavior.

This file validates that the API boots and exposes expected baseline routes.
"""

from fastapi.testclient import TestClient
import os

from app.main import app, _load_cors_origins

client = TestClient(app)


def test_root_endpoint_returns_status_message() -> None:
    # Root endpoint should return a successful startup response.

    response = client.get("/")
    assert response.status_code == 200

    payload = response.json()
    # Assert key health fields so developers can verify the API is live.
    assert "message" in payload
    assert "Thermostat backend" in payload["message"]


def test_docs_endpoint_available() -> None:
    # FastAPI documentation endpoint should be reachable.

    response = client.get("/docs")
    assert response.status_code == 200


def test_cors_origins_default_when_env_missing() -> None:
    original = os.environ.pop("BACKEND_CORS_ORIGINS", None)
    try:
        origins = _load_cors_origins()
    finally:
        if original is not None:
            os.environ["BACKEND_CORS_ORIGINS"] = original

    assert origins == ["http://localhost:4200", "http://127.0.0.1:4200"]


def test_cors_origins_parse_comma_separated_env_value() -> None:
    original = os.environ.get("BACKEND_CORS_ORIGINS")
    os.environ["BACKEND_CORS_ORIGINS"] = "http://localhost:4200,http://your-frontend-host.ts.net:4200"
    try:
        origins = _load_cors_origins()
    finally:
        if original is None:
            os.environ.pop("BACKEND_CORS_ORIGINS", None)
        else:
            os.environ["BACKEND_CORS_ORIGINS"] = original

    assert origins == ["http://localhost:4200", "http://your-frontend-host.ts.net:4200"]
