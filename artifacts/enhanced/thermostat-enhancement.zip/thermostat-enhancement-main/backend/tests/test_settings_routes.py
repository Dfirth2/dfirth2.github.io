"""
Tests for thermostat settings routes.

This file verifies settings CRUD, default creation, validation, and audit behavior.
"""

from contextlib import contextmanager

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app.main import app
from app.models.activity_log import ActivityLog
from app.models.thermostat_setting import ThermostatSetting
from app.models.user import User


@contextmanager
def _client_with_db():
    # Build a test client with isolated in-memory database dependency override.

    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Session = sessionmaker(bind=engine)
    Base.metadata.create_all(bind=engine)

    def override_get_db():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    try:
        yield client, Session
    finally:
        client.close()
        app.dependency_overrides.pop(get_db, None)
        engine.dispose()


def _seed_user(session, username: str) -> User:
    # Create and return a persistent user for settings tests.

    user = User(username=username, password_hash="hashed", role="user")
    session.add(user)
    session.commit()
    session.refresh(user)
    return user


def test_create_or_update_setting_persists_row_and_audit_log() -> None:
    # POST /settings should save thermostat settings and create an audit record.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "settingsuser")
        db.close()

        response = client.post(
            "/settings/",
            json={"user_id": user.user_id, "current_mode": "heat", "target_temperature": 70},
        )

        db = Session()
        settings_row = db.query(ThermostatSetting).filter(ThermostatSetting.user_id == user.user_id).first()
        activity_logs = db.query(ActivityLog).filter(ActivityLog.user_id == user.user_id).all()
        db.close()

    assert response.status_code == 201
    assert response.json()["current_mode"] == "heat"
    assert settings_row is not None
    assert settings_row.target_temperature == 70
    assert any("thermostat settings" in log.action.lower() for log in activity_logs)


def test_create_setting_rejects_invalid_mode() -> None:
    # Unsupported thermostat modes should be rejected before persistence.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "badmodeuser")
        db.close()

        response = client.post(
            "/settings/",
            json={"user_id": user.user_id, "current_mode": "fan", "target_temperature": 70},
        )

    assert response.status_code == 400


def test_list_settings_can_create_default_when_missing() -> None:
    # GET /settings with create_default=true should create a row only when one is missing.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "defaultsettingsuser")
        db.close()

        response = client.get(f"/settings/?user_id={user.user_id}&create_default=true")

    assert response.status_code == 200
    payload = response.json()
    assert len(payload) == 1
    assert payload[0]["current_mode"] == "off"


def test_patch_setting_updates_single_field() -> None:
    # PATCH /settings/{id} should update only the provided fields.

    with _client_with_db() as (client, Session):
        db = Session()
        user = _seed_user(db, "patchsettingsuser")
        setting = ThermostatSetting(user_id=user.user_id, current_mode="off", target_temperature=72)
        db.add(setting)
        db.commit()
        db.refresh(setting)
        setting_id = setting.setting_id
        db.close()

        response = client.patch(f"/settings/{setting_id}", json={"target_temperature": 68})

    assert response.status_code == 200
    payload = response.json()
    assert payload["current_mode"] == "off"
    assert payload["target_temperature"] == 68
