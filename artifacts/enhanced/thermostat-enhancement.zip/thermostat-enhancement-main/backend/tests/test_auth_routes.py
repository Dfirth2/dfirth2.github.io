"""
Tests for authentication routes.

This file verifies login success and failure behavior.
"""

from contextlib import contextmanager

from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.auth import hash_password
from app.database import Base, get_db
from app.main import app
from app.models.activity_log import ActivityLog
from app.models.user import User


@contextmanager
def _client_with_db():
    # Build a test client with isolated in-memory database dependency override.

    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Session = sessionmaker(bind=engine)
    Base.metadata.create_all(bind=engine)

    def override_get_db():
        db = Session()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    try:
        yield client, Session
    finally:
        client.close()
        app.dependency_overrides.pop(get_db, None)
        engine.dispose()


def test_login_returns_user_on_valid_credentials() -> None:
    # Login should return basic user info for valid credentials.

    with _client_with_db() as (client, Session):
        db = Session()
        db.add(
            User(
                username="admin",
                password_hash=hash_password("admin123"),
                role="admin",
            )
        )
        db.commit()
        db.close()

        response = client.post(
            "/auth/login",
            json={"username": "admin", "password": "admin123"},
        )

        activity_logs = db.query(ActivityLog).all()
        db.close()

    assert response.status_code == 200
    payload = response.json()
    assert payload["message"] == "Login successful."
    assert payload["user"]["username"] == "admin"
    assert payload["user"]["role"] == "admin"
    assert "password_hash" not in payload["user"]
    assert any(log.action == "Login successful." for log in activity_logs)


def test_login_rejects_invalid_credentials() -> None:
    # Login should reject non-matching passwords and audit the failed attempt.

    with _client_with_db() as (client, Session):
        db = Session()
        db.add(
            User(
                username="admin",
                password_hash=hash_password("admin123"),
                role="admin",
            )
        )
        db.commit()
        db.close()

        response = client.post(
            "/auth/login",
            json={"username": "admin", "password": "wrongpass"},
        )

        activity_logs = db.query(ActivityLog).all()
        db.close()

    assert response.status_code == 401
    assert response.json() == {"detail": "Invalid username or password."}
    assert any("Login failed" in log.action for log in activity_logs)
