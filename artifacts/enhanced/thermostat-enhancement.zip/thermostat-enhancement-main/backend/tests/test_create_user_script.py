"""
Tests for scripts/create_user.py user creation logic.

This file validates role/password checks, duplicate handling, and password hashing.
"""

from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.database import Base
from app.models.user import User
from scripts.create_user import create_user_record


@contextmanager
def _build_session():
    # Create an isolated in-memory session for script testing.

    engine = create_engine("sqlite:///:memory:")
    Session = sessionmaker(bind=engine)
    Base.metadata.create_all(bind=engine)
    db = Session()
    try:
        yield db
    finally:
        db.close()
        engine.dispose()


def test_valid_user_is_created() -> None:
    # Valid input should create a new user successfully.

    with _build_session() as db:
        success, message = create_user_record("newuser", "password123", "user", db)

    assert success is True
    assert "created successfully" in message


def test_duplicate_username_is_rejected() -> None:
    # Script should reject creating a user with an existing username.

    with _build_session() as db:
        create_user_record("dupuser", "password123", "user", db)

        success, message = create_user_record("dupuser", "password123", "user", db)
    assert success is False
    assert "already exists" in message


def test_password_shorter_than_8_chars_is_rejected() -> None:
    # Passwords shorter than 8 characters should fail validation.

    with _build_session() as db:
        success, message = create_user_record("shortpw", "short", "user", db)

    assert success is False
    assert "at least 8 characters" in message


def test_invalid_role_is_rejected() -> None:
    # Roles outside admin/user should fail validation.

    with _build_session() as db:
        success, message = create_user_record("roleuser", "password123", "manager", db)

    assert success is False
    assert "Invalid role" in message


def test_password_is_hashed_not_plain_text() -> None:
    # Stored password should be hashed rather than plain text.

    with _build_session() as db:
        create_user_record("hashuser", "password123", "admin", db)

        user = db.query(User).filter(User.username == "hashuser").first()
    assert user is not None

    # Confirm the DB does not store the original password string.
    assert user.password_hash != "password123"
    assert user.password_hash.startswith("$")
