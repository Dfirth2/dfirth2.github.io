"""
Administrative user creation script.

"""

from __future__ import annotations

from getpass import getpass
from pathlib import Path
import sys
from typing import Optional

# Ensure app imports work when executing this script directly.
sys.path.append(str(Path(__file__).resolve().parents[1]))

from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.auth import hash_password
from app.database import SessionLocal
from app.models.user import User

VALID_ROLES = {"admin", "user"}


def create_user_record(
    username: str,
    password: str,
    role: str,
    db_session: Optional[Session] = None,
) -> tuple[bool, str]:
    # Create a user with validation and duplicate checks.

    role_clean = role.strip().lower()
    if role_clean not in VALID_ROLES:
        return False, "Invalid role. Role must be 'admin' or 'user'."

    if len(password) < 8:
        return False, "Invalid password. Password must be at least 8 characters."

    own_session = db_session is None
    db = db_session or SessionLocal()

    try:
        existing = db.query(User).filter(User.username == username).first()
        if existing:
            return False, f"User '{username}' already exists."

        # Password is hashed before persistence to prevent plain-text storage.
        new_user = User(username=username, password_hash=hash_password(password), role=role_clean)
        db.add(new_user)
        db.commit()
        return True, f"User '{username}' created successfully."
    except SQLAlchemyError as exc:
        if own_session:
            db.rollback()
        return False, f"Database error while creating user: {exc}"
    finally:
        if own_session:
            db.close()


def prompt_for_user_input() -> tuple[str, str, str]:
    # Prompt for username, password, and role in interactive CLI mode.

    username = input("Enter username: ").strip()
    password = getpass("Enter password (min 8 chars): ")
    role = input("Enter role (admin/user): ").strip().lower()
    return username, password, role


def main() -> None:
    # Run interactive user creation workflow for local admin operations.

    username, password, role = prompt_for_user_input()
    success, message = create_user_record(username, password, role)
    print(message)


if __name__ == "__main__":
    main()
