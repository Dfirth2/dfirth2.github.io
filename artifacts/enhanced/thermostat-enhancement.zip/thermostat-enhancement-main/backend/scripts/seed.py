"""
Database seed script for local development.

Weekly schedule enhancement: seed data now creates recurring weekly schedule
events using day_of_week + event_time instead of one-time datetime values.
"""

from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys

# Ensure app imports work when executing this script directly.
sys.path.append(str(Path(__file__).resolve().parents[1]))

from app.auth import hash_password
from app.database import Base, SessionLocal, engine
from app.models import User, ThermostatSetting, ScheduleEvent, TemperatureLog, ActivityLog


def _get_or_create_user(db, *, username: str, password: str, role: str) -> User:
    # Seed users by username so reruns do not duplicate identities.

    user = db.query(User).filter(User.username == username).first()
    if user is not None:
        return user

    user = User(username=username, password_hash=hash_password(password), role=role)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def _ensure_setting(db, *, user_id: int, mode: str, target_temperature: float) -> None:
    # Each seeded user gets one current thermostat settings row.

    setting = db.query(ThermostatSetting).filter(ThermostatSetting.user_id == user_id).first()
    if setting is None:
        db.add(
            ThermostatSetting(
                user_id=user_id,
                current_mode=mode,
                target_temperature=target_temperature,
            )
        )


def _ensure_weekly_schedule(
    db,
    *,
    user_id: int,
    day_of_week: str,
    event_time: str,
    mode: str,
    target_temperature: float,
    is_active: bool = True,
) -> None:
    # Seed weekly schedule rows by (user, day, time) tuple so reruns are idempotent.
    # Weekly schedule events are identified by user_id + day_of_week + event_time
    # because that combination is what triggers a recurring thermostat action.

    existing = (
        db.query(ScheduleEvent)
        .filter(
            ScheduleEvent.user_id == user_id,
            ScheduleEvent.day_of_week == day_of_week,
            ScheduleEvent.event_time == event_time,
        )
        .first()
    )
    if existing is None:
        db.add(
            ScheduleEvent(
                user_id=user_id,
                day_of_week=day_of_week,
                event_time=event_time,
                mode=mode,
                target_temperature=target_temperature,
                is_active=is_active,
            )
        )


def _ensure_temperature_log(db, *, temperature: float, mode: str, target_temperature: float, recorded_at: datetime) -> None:
    # Development seed data should be deterministic enough to avoid duplicates on rerun.

    existing = (
        db.query(TemperatureLog)
        .filter(
            TemperatureLog.temperature == temperature,
            TemperatureLog.mode == mode,
            TemperatureLog.target_temperature == target_temperature,
            TemperatureLog.recorded_at == recorded_at,
        )
        .first()
    )
    if existing is None:
        db.add(
            TemperatureLog(
                temperature=temperature,
                mode=mode,
                target_temperature=target_temperature,
                recorded_at=recorded_at,
            )
        )


def _ensure_activity_log(db, *, user_id: int, action: str) -> None:
    # Seed activity logs by exact action text so reruns do not create duplicates.

    existing = db.query(ActivityLog).filter(ActivityLog.user_id == user_id, ActivityLog.action == action).first()
    if existing is None:
        db.add(ActivityLog(user_id=user_id, action=action))


# Create schema and seed starter records in an idempotent way.
def seed_database() -> None:

    # Ensure all model tables exist before inserting starter data.
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        # Development-only users provide predictable demo accounts for the dashboard.
        admin = _get_or_create_user(db, username="admin", password="admin123", role="admin")
        regular_user = _get_or_create_user(db, username="user1", password="user12345", role="user")

        _ensure_setting(db, user_id=admin.user_id, mode="off", target_temperature=72.0)
        _ensure_setting(db, user_id=regular_user.user_id, mode="heat", target_temperature=69.0)

        # Weekly schedule seed data – covers each day of the week for demo purposes.
        # Events are identified by (user, day, time) so reruns stay idempotent.
        _ensure_weekly_schedule(db, user_id=admin.user_id, day_of_week="sunday",    event_time="07:00", mode="heat", target_temperature=70.0)
        _ensure_weekly_schedule(db, user_id=admin.user_id, day_of_week="monday",    event_time="06:30", mode="heat", target_temperature=70.0)
        _ensure_weekly_schedule(db, user_id=admin.user_id, day_of_week="monday",    event_time="08:00", mode="off",  target_temperature=68.0)
        _ensure_weekly_schedule(db, user_id=admin.user_id, day_of_week="wednesday", event_time="17:30", mode="heat", target_temperature=71.0)
        _ensure_weekly_schedule(db, user_id=admin.user_id, day_of_week="friday",    event_time="18:00", mode="cool", target_temperature=72.0)
        _ensure_weekly_schedule(db, user_id=admin.user_id, day_of_week="saturday",  event_time="09:00", mode="off",  target_temperature=68.0)
        _ensure_weekly_schedule(db, user_id=regular_user.user_id, day_of_week="tuesday",  event_time="07:00", mode="heat", target_temperature=70.0)
        _ensure_weekly_schedule(db, user_id=regular_user.user_id, day_of_week="thursday", event_time="06:00", mode="heat", target_temperature=70.0)

        base_time = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
        _ensure_temperature_log(db, temperature=68.5, mode="off",  target_temperature=72.0, recorded_at=base_time - timedelta(hours=2))
        _ensure_temperature_log(db, temperature=69.0, mode="heat", target_temperature=70.0, recorded_at=base_time - timedelta(hours=1))
        _ensure_temperature_log(db, temperature=70.0, mode="cool", target_temperature=68.0, recorded_at=base_time)

        _ensure_activity_log(db, user_id=admin.user_id, action="Seed script initialized development data.")
        _ensure_activity_log(db, user_id=admin.user_id, action="Default thermostat setting created for admin.")
        _ensure_activity_log(db, user_id=regular_user.user_id, action="Default thermostat setting created for user1.")

        db.commit()
        print("Seed completed successfully.")
    finally:
        db.close()


if __name__ == "__main__":
    seed_database()

