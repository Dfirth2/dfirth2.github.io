# Thermostat Enhancement Project (CS 499)

## Project Overview
This repository contains the final enhanced version of a thermostat management system prepared for CS 499 submission and public GitHub/ePortfolio review.

The project combines:
- A FastAPI backend for thermostat data, schedules, auth, and activity logs.
- An Angular frontend dashboard for live monitoring and controls.
- A Raspberry Pi thermostat client script that sends heartbeat and temperature data.

All public-facing configuration values in committed files use placeholder-safe values.

## Original CS-350 Artifact
The original artifact was a thermostat control solution built during CS-350, focused on hardware interaction and thermostat behavior logic.
