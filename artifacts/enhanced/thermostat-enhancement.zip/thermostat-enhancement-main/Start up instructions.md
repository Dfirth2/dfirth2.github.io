# Startup Instructions

This document is intentionally startup-focused and public-safe for GitHub/ePortfolio use.

Use placeholder values in tracked files:
- http://your-backend-host.ts.net:8000
- your-thermostat-device-id

Store real private values only in local `.env`, shell startup files, or systemd environment files.

## 1) Local Startup (Backend + Frontend on One Machine)

### Backend
```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
python scripts/seed.py
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Swagger docs:
```text
http://localhost:8000/docs
```

### Frontend
```bash
cd frontend
npm install
npm run start:local
```

Frontend URL:
```text
http://localhost:4200
```

## 2) Tailscale / Separate Server Startup

Use this mode when backend and frontend run on different machines.

### Backend server environment
Set these on the backend host (local file, shell profile, or systemd `EnvironmentFile`):

```bash
export APP_ENV="tailscale"
export BACKEND_HOST="0.0.0.0"
export BACKEND_PORT="8000"
export DATABASE_URL="sqlite:///./thermostat.db"
export BACKEND_CORS_ORIGINS="http://localhost:4200,http://your-frontend-host.ts.net:4200"
export THERMOSTAT_CONNECTION_TIMEOUT_SECONDS="120"
export THERMOSTAT_ALLOWED_DEVICE_ID="your-thermostat-device-id"
```

### Start backend on separate server
```bash
cd backend
source .venv/bin/activate
python scripts/seed.py
uvicorn app.main:app --host "$BACKEND_HOST" --port "$BACKEND_PORT"
```

Backend docs URL pattern:
```text
http://your-backend-host.ts.net:8000/docs
```

### Start frontend in tailscale mode
```bash
cd frontend
npm install
npm run start:tailscale
```

Frontend local URL remains:
```text
http://localhost:4200
```

## 3) Raspberry Pi Thermostat Startup

On the Raspberry Pi, set runtime variables before starting the script:

```bash
export THERMOSTAT_BACKEND_BASE_URL="http://your-backend-host.ts.net:8000"
export THERMOSTAT_DEVICE_ID="your-thermostat-device-id"
export THERMOSTAT_API_TIMEOUT_SECONDS="5"
export THERMOSTAT_SYNC_INTERVAL_SECONDS="30"
export THERMOSTAT_HEARTBEAT_INTERVAL_SECONDS="30"
export THERMOSTAT_TEMP_LOG_INTERVAL_SECONDS="300"
export THERMOSTAT_SETTINGS_REFRESH_INTERVAL_SECONDS="30"
export THERMOSTAT_DEFAULT_MODE="off"
export THERMOSTAT_DEFAULT_TARGET_TEMPERATURE="72"
```

Start script:
```bash
cd thermostat
python3 DayneFirth-Thermostat.py
```

## 4) Test Commands

### Backend tests + coverage
```bash
cd backend
source .venv/bin/activate
pytest --cov=app --cov-report=term-missing
```

### Frontend tests
```bash
cd frontend
npm test -- --watch=false
```

## 5) Public Repo Safety

- Do not commit `.env` files with real hostnames or device IDs.
- Do not commit database files such as `thermostat.db`.
- Do not commit virtual environments or dependency folders (`.venv/`, `node_modules/`).
- Keep tracked defaults and examples placeholder-only for public sharing.