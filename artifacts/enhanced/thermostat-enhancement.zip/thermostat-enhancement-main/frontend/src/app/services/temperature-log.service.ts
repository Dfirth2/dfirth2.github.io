// File: temperature-log.service.ts
// Purpose: Provide database-backed access to thermostat temperature history.

import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { catchError, Observable, of } from 'rxjs';

import { environment } from '../../environments/environment';
import { TemperatureLog, TemperatureLogRequest } from '../models/temperature-log.model';

export interface TemperatureLogQueryOptions {
  limit?: number;
  startTime?: string;
  endTime?: string;
  order?: 'asc' | 'desc';
}

@Injectable({
  providedIn: 'root',
})
export class TemperatureLogService {
  private readonly http = inject(HttpClient);

  getTemperatureHistory(options?: TemperatureLogQueryOptions): Observable<TemperatureLog[]> {
    // Query parameters allow recent-history and date-range database reads without extra components.
    let params = new HttpParams();
    if (options?.limit !== undefined) {
      params = params.set('limit', String(options.limit));
    }
    if (options?.startTime) {
      params = params.set('start_time', options.startTime);
    }
    if (options?.endTime) {
      params = params.set('end_time', options.endTime);
    }
    if (options?.order) {
      params = params.set('order', options.order);
    }

    return this.http.get<TemperatureLog[]>(`${environment.apiBaseUrl}/temperature-logs/`, { params }).pipe(catchError(() => of([])));
  }

  createTemperatureLog(request: TemperatureLogRequest): Observable<TemperatureLog | null> {
    return this.http.post<TemperatureLog>(`${environment.apiBaseUrl}/temperature-logs/`, request).pipe(catchError(() => of(null)));
  }
}
