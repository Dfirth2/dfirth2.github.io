// File: schedule.service.ts
// Purpose: Provide weekly schedule API access for the thermostat dashboard.
// Weekly schedule enhancement: filters now support day_of_week; upcoming/past
// are removed because events recur every week rather than having a one-time date.

import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { catchError, map, Observable, of } from 'rxjs';

import { environment } from '../../environments/environment';
import { ScheduleEvent, ScheduleEventRequest } from '../models/schedule-event.model';

export interface ScheduleQueryFilters {
  active?: boolean;
  day?: string;
  mode?: 'off' | 'heat' | 'cool' | string;
  userId?: number;
}

@Injectable({
  providedIn: 'root',
})
export class ScheduleService {
  private readonly http = inject(HttpClient);

  getScheduleEvents(filters?: ScheduleQueryFilters): Observable<ScheduleEvent[]> {
    // Query parameters map to backend weekly schedule filters.
    // Backend returns events sorted Sunday–Saturday so the frontend fallback just preserves order.
    let params = new HttpParams();

    if (filters?.active !== undefined) {
      params = params.set('active', String(filters.active));
    }
    if (filters?.day) {
      params = params.set('day', filters.day);
    }
    if (filters?.mode) {
      params = params.set('mode', filters.mode);
    }
    if (filters?.userId !== undefined) {
      params = params.set('user_id', String(filters.userId));
    }

    return this.http.get<ScheduleEvent[]>(`${environment.apiBaseUrl}/schedules/`, { params }).pipe(
      map((events) => this.sortEventsByTime(events)),
      catchError(() => of([])),
    );
  }

  getNextScheduleEvent(userId?: number): Observable<ScheduleEvent | null> {
    // The next-event route applies weekly wrap-around logic in the backend service.
    const params = userId !== undefined ? new HttpParams().set('user_id', String(userId)) : undefined;
    return this.http.get<ScheduleEvent | null>(`${environment.apiBaseUrl}/schedules/next`, { params }).pipe(catchError(() => of(null)));
  }

  createScheduleEvent(request: ScheduleEventRequest): Observable<ScheduleEvent> {
    // Creation errors (for example conflicts) are propagated so UI can show explicit feedback.
    return this.http.post<ScheduleEvent>(`${environment.apiBaseUrl}/schedules/`, request);
  }

  updateScheduleEvent(eventId: number, request: Partial<ScheduleEventRequest>): Observable<ScheduleEvent> {
    // PATCH keeps schedule edits minimal and lets backend enforce conflict validation.
    return this.http.patch<ScheduleEvent>(`${environment.apiBaseUrl}/schedules/${eventId}`, request);
  }

  deactivateScheduleEvent(eventId: number): Observable<ScheduleEvent> {
    // Soft-deactivation preserves database history while removing an event from active behavior.
    return this.http.patch<ScheduleEvent>(`${environment.apiBaseUrl}/schedules/${eventId}/deactivate`, {});
  }

  private sortEventsByTime(events: ScheduleEvent[]): ScheduleEvent[] {
    // Frontend fallback sorting: Sunday-first by day name, then by HH:MM time string.
    const DAY_ORDER: Record<string, number> = {
      sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6,
    };
    return [...events].sort((a, b) => {
      const dayDiff = (DAY_ORDER[a.day_of_week] ?? 99) - (DAY_ORDER[b.day_of_week] ?? 99);
      return dayDiff !== 0 ? dayDiff : a.event_time.localeCompare(b.event_time);
    });
  }
}
