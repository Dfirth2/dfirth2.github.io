// File: thermostat-status.service.ts
// Purpose: Fetch thermostat connection status for dashboard indicator.

import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from '../../environments/environment';
import { ThermostatStatus } from '../models/thermostat-status.model';

@Injectable({
  providedIn: 'root',
})
export class ThermostatStatusService {
  private readonly http = inject(HttpClient);

  getThermostatStatus(deviceId?: string): Observable<ThermostatStatus> {
    let params = new HttpParams();

    if (deviceId) {
      params = params.set('device_id', deviceId);
    }

    return this.http.get<ThermostatStatus>(`${environment.apiBaseUrl}/thermostat/status`, { params });
  }
}
