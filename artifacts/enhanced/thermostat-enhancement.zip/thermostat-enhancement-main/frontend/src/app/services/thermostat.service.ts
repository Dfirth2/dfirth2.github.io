// File: thermostat.service.ts
// Purpose: Communicate thermostat settings between the Angular UI and FastAPI backend.
// The service keeps all API access in one place so components stay focused on UI behavior.

import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { catchError, map, Observable, of } from 'rxjs';

import { environment } from '../../environments/environment';
import { ThermostatSetting, ThermostatSettingRequest } from '../models/thermostat-setting.model';

export const ALLOWED_THERMOSTAT_MODES = ['off', 'heat', 'cool'] as const;
export const MIN_TARGET_TEMPERATURE = 45;
export const MAX_TARGET_TEMPERATURE = 90;

@Injectable({
  providedIn: 'root',
})
export class ThermostatService {
  private readonly http = inject(HttpClient);

  // Settings can be scoped to one user so the dashboard reads the correct persisted row.
  getCurrentSettings(userId?: number, createDefault: boolean = false): Observable<ThermostatSetting | null> {
    let params = new HttpParams();
    if (userId !== undefined) {
      params = params.set('user_id', String(userId));
    }
    if (createDefault) {
      params = params.set('create_default', 'true');
    }

    return this.http.get<ThermostatSetting[]>(`${environment.apiBaseUrl}/settings/`, { params }).pipe(
      map((settings) => settings[0] ?? null),
      catchError(() => of(null)),
    );
  }

  updateSettings(request: ThermostatSettingRequest): Observable<ThermostatSetting | null> {
    const normalizedRequest = this.normalizeRequest(request);

    // The backend persists one current settings row per user via an upsert-style POST.
    return this.http.post<ThermostatSetting>(`${environment.apiBaseUrl}/settings/`, normalizedRequest).pipe(
      catchError(() => of(null)),
    );
  }

  validateMode(mode: string): boolean {
    return ALLOWED_THERMOSTAT_MODES.includes(mode.trim().toLowerCase() as (typeof ALLOWED_THERMOSTAT_MODES)[number]);
  }

  validateTargetTemperature(targetTemperature: number): boolean {
    return targetTemperature >= MIN_TARGET_TEMPERATURE && targetTemperature <= MAX_TARGET_TEMPERATURE;
  }

  clampTargetTemperature(targetTemperature: number): number {
    return Math.min(MAX_TARGET_TEMPERATURE, Math.max(MIN_TARGET_TEMPERATURE, targetTemperature));
  }

  private normalizeRequest(request: ThermostatSettingRequest): ThermostatSettingRequest {
    const normalizedMode = request.current_mode.trim().toLowerCase();
    const clampedTemperature = this.clampTargetTemperature(request.target_temperature);

    if (!this.validateMode(normalizedMode)) {
      throw new Error(`Invalid thermostat mode. Allowed values are: ${ALLOWED_THERMOSTAT_MODES.join(', ')}.`);
    }

    return {
      user_id: request.user_id,
      current_mode: normalizedMode as ThermostatSettingRequest['current_mode'],
      target_temperature: clampedTemperature,
    };
  }
}
