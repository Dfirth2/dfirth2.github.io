// File: services.spec.ts
// Purpose: Verify that frontend services call the expected backend API endpoints.
// These tests confirm database-backed UI services are wired to FastAPI routes.

import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { firstValueFrom } from 'rxjs';

import { AuthService } from './auth.service';
import { ThermostatService } from './thermostat.service';
import { ThermostatStatusService } from './thermostat-status.service';
import { ScheduleService } from './schedule.service';
import { TemperatureLogService } from './temperature-log.service';
import { ActivityLogService } from './activity-log.service';

describe('Frontend services', () => {
  let httpController: HttpTestingController;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    }).compileComponents();

    httpController = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpController.verify();
  });

  it('should instantiate the auth service', () => {
    expect(TestBed.inject(AuthService)).toBeTruthy();
  });

  it('should validate thermostat modes locally', () => {
    const service = TestBed.inject(ThermostatService);
    expect(service).toBeTruthy();
    expect(service.validateMode('heat')).toBe(true);
    expect(service.validateMode('fan')).toBe(false);
  });

  it('should request user-scoped thermostat settings', async () => {
    const service = TestBed.inject(ThermostatService);
    const resultPromise = firstValueFrom(service.getCurrentSettings(7, true));

    const request = httpController.expectOne((req) => req.method === 'GET' && req.url.endsWith('/settings/'));
    expect(request.request.params.get('user_id')).toBe('7');
    expect(request.request.params.get('create_default')).toBe('true');
    request.flush([{ setting_id: 1, user_id: 7, current_mode: 'heat', target_temperature: 70, updated_at: '2026-06-05T00:00:00Z' }]);

    const result = await resultPromise;
    expect(result?.user_id).toBe(7);
  });

  it('should request weekly schedule events with day and active filters', async () => {
    const service = TestBed.inject(ScheduleService);
    const resultPromise = firstValueFrom(service.getScheduleEvents({ active: true, day: 'monday', userId: 4 }));

    const request = httpController.expectOne((req) => req.method === 'GET' && req.url.endsWith('/schedules/'));
    expect(request.request.params.get('active')).toBe('true');
    expect(request.request.params.get('day')).toBe('monday');
    expect(request.request.params.get('user_id')).toBe('4');
    request.flush([
      { event_id: 2, user_id: 4, day_of_week: 'monday', event_time: '08:00', mode: 'heat', target_temperature: 71, is_active: true },
      { event_id: 1, user_id: 4, day_of_week: 'monday', event_time: '06:30', mode: 'heat', target_temperature: 68, is_active: true },
    ]);

    const result = await resultPromise;
    // Frontend fallback sort: both Monday events should be sorted by time.
    expect(result[0].event_id).toBe(1); // 06:30 comes first
  });

  it('should send schedule update and deactivate requests to backend routes', () => {
    const service = TestBed.inject(ScheduleService);

    service.updateScheduleEvent(9, { mode: 'cool' }).subscribe();
    const updateRequest = httpController.expectOne((req) => req.method === 'PATCH' && req.url.endsWith('/schedules/9'));
    expect(updateRequest.request.body).toEqual({ mode: 'cool' });
    updateRequest.flush({
      event_id: 9,
      user_id: 1,
      day_of_week: 'monday',
      event_time: '08:00',
      mode: 'cool',
      target_temperature: 68,
      is_active: true,
    });

    service.deactivateScheduleEvent(9).subscribe();
    const deactivateRequest = httpController.expectOne((req) => req.method === 'PATCH' && req.url.endsWith('/schedules/9/deactivate'));
    deactivateRequest.flush({
      event_id: 9,
      user_id: 1,
      day_of_week: 'monday',
      event_time: '08:00',
      mode: 'cool',
      target_temperature: 68,
      is_active: false,
    });
  });

  it('should request recent temperature history with query options', () => {
    const service = TestBed.inject(TemperatureLogService);

    service.getTemperatureHistory({ limit: 5, order: 'asc' }).subscribe();
    const request = httpController.expectOne((req) => req.method === 'GET' && req.url.endsWith('/temperature-logs/'));
    expect(request.request.params.get('limit')).toBe('5');
    expect(request.request.params.get('order')).toBe('asc');
    request.flush([]);
  });

  it('should request activity logs with user and limit filters', () => {
    const service = TestBed.inject(ActivityLogService);

    service.getActivityLogs({ userId: 3, limit: 4 }).subscribe();
    const request = httpController.expectOne((req) => req.method === 'GET' && req.url.endsWith('/activity-logs/'));
    expect(request.request.params.get('user_id')).toBe('3');
    expect(request.request.params.get('limit')).toBe('4');
    request.flush([]);
  });

  it('should request thermostat connection status for a device', async () => {
    const service = TestBed.inject(ThermostatStatusService);
    const resultPromise = firstValueFrom(service.getThermostatStatus('your-thermostat-device-id'));

    const request = httpController.expectOne((req) => req.method === 'GET' && req.url.endsWith('/thermostat/status'));
    expect(request.request.params.get('device_id')).toBe('your-thermostat-device-id');
    request.flush({ device_id: 'your-thermostat-device-id', connected: true, status_message: 'Thermostat Connected' });

    const result = await resultPromise;
    expect(result.connected).toBe(true);
  });

  it('should request default thermostat connection status without a device query', async () => {
    const service = TestBed.inject(ThermostatStatusService);
    const resultPromise = firstValueFrom(service.getThermostatStatus());

    const request = httpController.expectOne((req) => req.method === 'GET' && req.url.endsWith('/thermostat/status'));
    expect(request.request.params.has('device_id')).toBe(false);
    request.flush({ device_id: 'runtime-device', connected: true, status_message: 'Thermostat Connected' });

    const result = await resultPromise;
    expect(result.device_id).toBe('runtime-device');
  });
});
