// File: activity-log.service.ts
// Purpose: Provide database-backed access to audit and troubleshooting activity logs.

import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { catchError, Observable, of } from 'rxjs';

import { environment } from '../../environments/environment';
import { ActivityLog, ActivityLogRequest } from '../models/activity-log.model';

export interface ActivityLogQueryOptions {
  userId?: number;
  limit?: number;
}

@Injectable({
  providedIn: 'root',
})
export class ActivityLogService {
  private readonly http = inject(HttpClient);

  getActivityLogs(options?: ActivityLogQueryOptions): Observable<ActivityLog[]> {
    // The dashboard can request recent logs or one user's logs using simple query parameters.
    let params = new HttpParams();
    if (options?.userId !== undefined) {
      params = params.set('user_id', String(options.userId));
    }
    if (options?.limit !== undefined) {
      params = params.set('limit', String(options.limit));
    }

    return this.http.get<ActivityLog[]>(`${environment.apiBaseUrl}/activity-logs/`, { params }).pipe(catchError(() => of([])));
  }

  createActivityLog(request: ActivityLogRequest): Observable<ActivityLog | null> {
    return this.http.post<ActivityLog>(`${environment.apiBaseUrl}/activity-logs/`, request).pipe(catchError(() => of(null)));
  }
}
