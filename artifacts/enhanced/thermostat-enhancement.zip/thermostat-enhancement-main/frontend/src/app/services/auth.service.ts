// File: auth.service.ts
// Purpose: Handle frontend authentication state backed by FastAPI auth endpoints.

import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { BehaviorSubject, catchError, map, Observable, of, tap } from 'rxjs';

import { environment } from '../../environments/environment';
import { User } from '../models/user.model';

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface LoginResult {
  success: boolean;
  message: string;
  user: User | null;
}

interface StoredAuthState {
  user: User | null;
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly storageKey = 'thermostat-enhancement-auth';
  private readonly currentUserSubject = new BehaviorSubject<User | null>(this.loadStoredUser());
  private readonly loginModalRequestSubject = new BehaviorSubject<number>(0);

  readonly currentUser$ = this.currentUserSubject.asObservable();
  readonly loginModalRequest$ = this.loginModalRequestSubject.asObservable();

  requestLoginModal(): void {
    this.loginModalRequestSubject.next(Date.now());
  }

  login(credentials: LoginCredentials): Observable<LoginResult> {
    const username = credentials.username.trim();
    const password = credentials.password.trim();

    if (!username || !password) {
      return of({
        success: false,
        message: 'Username and password are required.',
        user: null,
      });
    }

    return this.http.post<{ message?: string; user?: User }>(`${environment.apiBaseUrl}/auth/login`, credentials).pipe(
      map((response) => {
        const user = response.user ?? null;
        if (!user) {
          return {
            success: false,
            message: 'Login failed. No user was returned by the server.',
            user: null,
          };
        }

        this.storeUser(user);
        return {
          success: true,
          message: response.message ?? 'Login successful.',
          user,
        };
      }),
      catchError((error: HttpErrorResponse) => {
        const backendMessage =
          typeof error.error?.detail === 'string'
            ? error.error.detail
            : typeof error.error?.message === 'string'
              ? error.error.message
              : 'Unable to log in with those credentials.';

        return of({
          success: false,
          message: backendMessage,
          user: null,
        });
      }),
    );
  }

  logout(): void {
    this.currentUserSubject.next(null);
    localStorage.removeItem(this.storageKey);
  }

  isLoggedIn(): boolean {
    return this.currentUserSubject.value !== null;
  }

  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }

  private storeUser(user: User): void {
    const state: StoredAuthState = { user };
    localStorage.setItem(this.storageKey, JSON.stringify(state));
    this.currentUserSubject.next(user);
  }

  private loadStoredUser(): User | null {
    const rawState = localStorage.getItem(this.storageKey);
    if (!rawState) {
      return null;
    }

    try {
      const parsedState = JSON.parse(rawState) as StoredAuthState;
      return parsedState.user ?? null;
    } catch {
      return null;
    }
  }
}
