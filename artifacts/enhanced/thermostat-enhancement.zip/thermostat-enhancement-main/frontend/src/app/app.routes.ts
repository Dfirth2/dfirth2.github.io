import { Routes } from '@angular/router';

export const routes: Routes = [
	{
		path: '',
		pathMatch: 'full',
		redirectTo: 'dashboard',
	},
	{
		path: 'dashboard',
		loadComponent: () => import('./components/dashboard/dashboard.component').then((m) => m.DashboardComponent),
	},
	{
		path: 'login',
		redirectTo: 'dashboard',
	},
	{
		path: 'schedules',
		redirectTo: 'dashboard',
	},
	{
		path: 'settings',
		redirectTo: 'dashboard',
	},
	{
		path: 'temperature-history',
		redirectTo: 'dashboard',
	},
	{
		path: 'activity-logs',
		redirectTo: 'dashboard',
	},
	{
		path: '**',
		redirectTo: 'dashboard',
	},
];
