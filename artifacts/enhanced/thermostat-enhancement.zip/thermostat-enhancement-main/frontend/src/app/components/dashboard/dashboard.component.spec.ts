// File: dashboard.component.spec.ts
// Purpose: Verify Scheduled Events day-of-week chip filtering and modal actions.

import { TestBed } from '@angular/core/testing';
import { HttpErrorResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';

import { DashboardComponent } from './dashboard.component';
import { ThermostatService } from '../../services/thermostat.service';
import { TemperatureLogService } from '../../services/temperature-log.service';
import { ActivityLogService } from '../../services/activity-log.service';
import { ScheduleService } from '../../services/schedule.service';
import { AuthService } from '../../services/auth.service';
import { ThermostatStatusService } from '../../services/thermostat-status.service';

describe('DashboardComponent', () => {
  let scheduleFiltersSeen: Array<Record<string, unknown> | undefined> = [];
  let getScheduleEventsResult: Observable<unknown> = of([]);
  let getNextScheduleEventResult: Observable<unknown> = of(null);
  let createScheduleEventResult: Observable<unknown> = of(null);
  let getThermostatStatusResult: Observable<unknown> = of({ device_id: 'your-thermostat-device-id', connected: false, status_message: 'Thermostat Disconnected' });

  const scheduleServiceStub = {
    getScheduleEvents: (filters?: Record<string, unknown>) => {
      scheduleFiltersSeen.push(filters);
      return getScheduleEventsResult;
    },
    getNextScheduleEvent: () => getNextScheduleEventResult,
    createScheduleEvent: () => createScheduleEventResult,
    updateScheduleEvent: () => createScheduleEventResult,
    deactivateScheduleEvent: () => createScheduleEventResult,
  };

  beforeEach(async () => {
    scheduleFiltersSeen = [];
    getScheduleEventsResult = of([]);
    getNextScheduleEventResult = of(null);
    createScheduleEventResult = of(null);
    getThermostatStatusResult = of({ device_id: 'your-thermostat-device-id', connected: false, status_message: 'Thermostat Disconnected' });

    await TestBed.configureTestingModule({
      imports: [DashboardComponent],
      providers: [
        {
          provide: ThermostatService,
          useValue: {
            getCurrentSettings: () => of(null),
            updateSettings: () => of(null),
            validateMode: () => true,
            validateTargetTemperature: () => true,
            clampTargetTemperature: (value: number) => value,
          },
        },
        {
          provide: ThermostatStatusService,
          useValue: {
            getThermostatStatus: () => getThermostatStatusResult,
          },
        },
        { provide: TemperatureLogService, useValue: { getTemperatureHistory: () => of([]) } },
        { provide: ActivityLogService, useValue: { getActivityLogs: () => of([]) } },
        { provide: ScheduleService, useValue: scheduleServiceStub },
        {
          provide: AuthService,
          useValue: {
            isLoggedIn: () => true,
            getCurrentUser: () => ({ user_id: 1, username: 'admin', role: 'admin', created_at: new Date().toISOString() }),
            loginModalRequest$: of(0),
            login: () => of({ success: true, message: 'ok', user: null }),
            logout: () => undefined,
          },
        },
      ],
    }).compileComponents();
  });

  it('should create the dashboard', () => {
    const fixture = TestBed.createComponent(DashboardComponent);
    expect(fixture.componentInstance).toBeTruthy();
  });

  it('should render only Sunday-Saturday schedule filter chips', () => {
    const fixture = TestBed.createComponent(DashboardComponent);
    fixture.detectChanges();

    const chipLabels = Array.from<Element>(fixture.nativeElement.querySelectorAll('.schedule-filters button')).map((node) =>
      node.textContent?.trim(),
    );

    expect(chipLabels).toEqual(['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']);
  });

  it('should not render legacy filter chips', () => {
    const fixture = TestBed.createComponent(DashboardComponent);
    fixture.detectChanges();

    const chipLabels = Array.from<Element>(fixture.nativeElement.querySelectorAll('.schedule-filters button')).map((node) =>
      node.textContent?.trim(),
    );
    expect(chipLabels).not.toContain('All');
    expect(chipLabels).not.toContain('Active');
    expect(chipLabels).not.toContain('Inactive');
    expect(chipLabels).not.toContain('Heat');
    expect(chipLabels).not.toContain('Cool');
    expect(chipLabels).not.toContain('Off');
  });

  it('should update selected day when a day chip is clicked', () => {
    const fixture = TestBed.createComponent(DashboardComponent);
    const component = fixture.componentInstance;
    fixture.detectChanges();

    const mondayButton = Array.from<HTMLButtonElement>(fixture.nativeElement.querySelectorAll('.schedule-filters button')).find(
      (button) => button.textContent?.trim() === 'Monday',
    );
    expect(mondayButton).toBeTruthy();

    mondayButton?.click();
    fixture.detectChanges();

    expect(component.selectedScheduleDay).toBe('monday');
    expect(mondayButton?.classList.contains('active')).toBe(true);
  });

  it('should display only selected-day events and sort them by time', () => {
    const fixture = TestBed.createComponent(DashboardComponent);
    const component = fixture.componentInstance;
    const selectedDay = 'monday';
    const otherDay = 'tuesday';

    component.scheduleEvents = [
      { event_id: 11, user_id: 1, day_of_week: selectedDay, event_time: '18:00', mode: 'cool', target_temperature: 68, is_active: true },
      { event_id: 12, user_id: 1, day_of_week: selectedDay, event_time: '07:00', mode: 'heat', target_temperature: 70, is_active: true },
      { event_id: 13, user_id: 1, day_of_week: otherDay, event_time: '08:00', mode: 'off', target_temperature: 72, is_active: true },
    ];
    component.selectedScheduleDay = selectedDay;

    expect(component.displayedScheduleEvents.length).toBe(2);
    expect(component.displayedScheduleEvents[0].event_time).toBe('07:00');
    expect(component.displayedScheduleEvents[1].event_time).toBe('18:00');
  });

  it('should show no-events message when selected day has no events', () => {
    const fixture = TestBed.createComponent(DashboardComponent);
    const component = fixture.componentInstance;

    component.scheduleEvents = [
      { event_id: 21, user_id: 1, day_of_week: 'wednesday', event_time: '09:00', mode: 'heat', target_temperature: 69, is_active: true },
    ];
    component.selectedScheduleDay = 'sunday';
    fixture.detectChanges();

    const emptyStateText = fixture.nativeElement.querySelector('.events-card .empty-state')?.textContent?.trim();

    expect(component.displayedScheduleEvents.length).toBe(0);
    expect(emptyStateText).toBe('No scheduled events for this day.');
  });

  it('should keep Add Event button opening the event modal', () => {
    const fixture = TestBed.createComponent(DashboardComponent);
    const component = fixture.componentInstance;
    fixture.detectChanges();

    const addEventButton = fixture.nativeElement.querySelector('.events-card .card-header button') as HTMLButtonElement;
    addEventButton.click();
    fixture.detectChanges();

    expect(component.showEventModal).toBe(true);
    expect(fixture.nativeElement.querySelector('.modal-card h3')?.textContent).toContain('Add Event');
  });

  it('should load next scheduled event on init', () => {
    getNextScheduleEventResult =
      of({ event_id: 9, user_id: 1, day_of_week: 'monday', event_time: '08:00', mode: 'heat', target_temperature: 70, is_active: true });

    const fixture = TestBed.createComponent(DashboardComponent);
    fixture.detectChanges();

    expect(fixture.componentInstance.nextScheduledEvent?.event_id).toBe(9);
    // Next-event display should include day and time in a readable format.
    expect(fixture.componentInstance.nextScheduledEventDisplay).toContain('monday');
    expect(fixture.componentInstance.nextScheduledEventDisplay).toContain('08:00');
  });

  it('should request user-scoped schedules for dashboard loading', () => {
    const fixture = TestBed.createComponent(DashboardComponent);
    fixture.detectChanges();

    expect(scheduleFiltersSeen.at(-1)).toEqual(expect.objectContaining({ userId: 1 }));
  });

  it('should render connected thermostat status in the hero section', () => {
    getThermostatStatusResult = of({ device_id: 'your-thermostat-device-id', connected: true, status_message: 'Thermostat Connected' });
    const fixture = TestBed.createComponent(DashboardComponent);
    fixture.detectChanges();

    const statusNode = fixture.nativeElement.querySelector('.connection-status') as HTMLElement;
    const statusDot = fixture.nativeElement.querySelector('.status-dot') as HTMLElement;
    expect(statusNode?.textContent).toContain('Thermostat Connected');
    expect(statusNode.classList.contains('connected')).toBe(true);
    expect(statusDot.classList.contains('connected')).toBe(true);
  });

  it('should render disconnected thermostat status when API returns disconnected', () => {
    getThermostatStatusResult = of({ device_id: 'your-thermostat-device-id', connected: false, status_message: 'Thermostat Disconnected' });
    const fixture = TestBed.createComponent(DashboardComponent);
    fixture.detectChanges();

    const statusNode = fixture.nativeElement.querySelector('.connection-status') as HTMLElement;
    const statusDot = fixture.nativeElement.querySelector('.status-dot') as HTMLElement;
    expect(statusNode?.textContent).toContain('Thermostat Disconnected');
    expect(statusNode.classList.contains('disconnected')).toBe(true);
    expect(statusDot.classList.contains('disconnected')).toBe(true);
  });

  it('should fallback to disconnected status when connection API fails', () => {
    getThermostatStatusResult = throwError(() => new HttpErrorResponse({ status: 500 }));
    const fixture = TestBed.createComponent(DashboardComponent);
    fixture.detectChanges();

    const statusNode = fixture.nativeElement.querySelector('.connection-status') as HTMLElement;
    expect(statusNode?.textContent).toContain('Thermostat Disconnected');
    expect(fixture.nativeElement.textContent).not.toContain('Last seen');
  });

  it('should surface conflict errors inside the event modal', () => {
    createScheduleEventResult =
      throwError(
        () =>
          new HttpErrorResponse({
            status: 409,
            error: { detail: 'Schedule conflict: an active event already exists at this date/time.' },
          }),
      );

    const fixture = TestBed.createComponent(DashboardComponent);
    const component = fixture.componentInstance;
    fixture.detectChanges();

    component.showEventModal = true;
    component.eventForm.setValue({
      dayOfWeek: 'monday',
      eventTime: '08:00',
      mode: 'heat',
      targetTemperature: 70,
      isActive: true,
    });

    component.saveEvent();

    expect(component.eventErrorMessage).toContain('Schedule conflict');
  });
});
