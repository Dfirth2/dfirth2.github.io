// File: navbar.component.ts
// Purpose: Provide basic navigation for the thermostat dashboard pages.
// This component helps users move between the main dashboard and future feature pages.

import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';

import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule],
  template: `
    <header class="navbar">

      <div class="nav-title" aria-label="Dashboard title">Dayne's Thermostat Dashboard</div>

      <div class="auth-actions">
        <ng-container *ngIf="currentUser$ | async as currentUser; else loginLink">
          <span class="user-chip">{{ currentUser.username }}</span>
          <button type="button" class="logout-button" (click)="logout()">Logout</button>
        </ng-container>

        <ng-template #loginLink>
          <button type="button" class="login-link" (click)="openLogin()">Log In</button>
        </ng-template>
      </div>
    </header>
  `,
  styles: [
    `
      .navbar {
        position: relative;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: flex-end;
        gap: 16px;
        padding: 20px 24px;
        border-bottom: 1px solid rgba(16, 34, 58, 0.12);
        background: rgba(255, 255, 255, 0.88);
        backdrop-filter: blur(10px);
      }

      .brand-block h1 {
        margin: 0;
        font-size: 1.25rem;
      }

      .brand-block p,
      .brand-kicker {
        margin: 0;
        font-size: 0.9rem;
        color: #516173;
      }

      .brand-kicker {
        text-transform: uppercase;
        letter-spacing: 0.16em;
        font-size: 0.72rem;
        font-weight: 700;
        color: #2856d6;
      }

      .nav-title {
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        font-size: 1.2rem;
        font-weight: 800;
        letter-spacing: 0.02em;
        text-align: center;
        white-space: nowrap;
      }

      .login-link,
      .logout-button {
        border-radius: 999px;
        border: 1px solid rgba(16, 34, 58, 0.16);
        padding: 10px 14px;
        text-decoration: none;
        color: #10223a;
        background: #fff;
        font-size: 0.95rem;
        cursor: pointer;
      }

      .auth-actions {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .user-chip {
        padding: 8px 12px;
        border-radius: 999px;
        background: #eaf0ff;
        color: #2856d6;
        font-weight: 700;
      }

      .logout-button {
        background: #10223a;
        color: #fff;
      }

      @media (max-width: 820px) {
        .navbar {
          justify-content: center;
        }

        .nav-title {
          position: static;
          transform: none;
          width: 100%;
          order: -1;
          white-space: normal;
        }
      }
    `,
  ],
})
export class NavbarComponent {
  // The navbar uses shared auth state so login/logout behavior stays consistent across pages.
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);
  readonly currentUser$ = this.authService.currentUser$;

  openLogin(): void {
    this.router.navigate(['/dashboard']).then(() => {
      this.authService.requestLoginModal();
    });
  }

  logout(): void {
    this.authService.logout();
  }
}
