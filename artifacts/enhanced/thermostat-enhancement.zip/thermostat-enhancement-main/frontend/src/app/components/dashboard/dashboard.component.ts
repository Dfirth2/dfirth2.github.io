// File: dashboard.component.ts
// Purpose: Provide a single-page thermostat dashboard with modal workflows.
// Login and schedule-event actions are handled inline so users stay on one page.

import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnDestroy, OnInit, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';

import { ActivityLog } from '../../models/activity-log.model';
import { ScheduleEvent, ScheduleEventRequest } from '../../models/schedule-event.model';
import { VALID_DAYS } from '../../models/schedule-event.model';
import { TemperatureLog } from '../../models/temperature-log.model';
import { ThermostatStatus } from '../../models/thermostat-status.model';
import { ThermostatSetting } from '../../models/thermostat-setting.model';
import { ActivityLogService } from '../../services/activity-log.service';
import { AuthService } from '../../services/auth.service';
import { MAX_TARGET_TEMPERATURE, MIN_TARGET_TEMPERATURE, ThermostatService, ALLOWED_THERMOSTAT_MODES } from '../../services/thermostat.service';
import { ThermostatStatusService } from '../../services/thermostat-status.service';
import { ScheduleService } from '../../services/schedule.service';
import { TemperatureLogService } from '../../services/temperature-log.service';

interface DayFilterOption {
  label: string;
  value: string;
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <section class="dashboard-page">
      <article class="hero-card">
        <div>
          <h2>Control Center</h2>
          <p class="hero-copy">
            All controls live here.
          </p>
          <p class="connection-status" [class.connected]="thermostatConnected" [class.disconnected]="!thermostatConnected">
            <span class="status-dot" [class.connected]="thermostatConnected" [class.disconnected]="!thermostatConnected"></span>
            {{ thermostatStatusMessage }}
          </p>
        </div>
      </article>

      <section class="control-card">
        <h3 class="section-title">Mode Selection</h3>
        <div class="mode-buttons">
          <button
            type="button"
            *ngFor="let mode of allowedModes"
            [class.active]="selectedMode === mode"
            [disabled]="!isLoggedIn()"
            (click)="selectMode(mode)"
          >
            {{ mode | titlecase }}
          </button>
        </div>

        <h3 class="section-title">Target Temperature</h3>
        <div class="temp-controls">
          <button type="button" [disabled]="!isLoggedIn()" (click)="lowerTemperature()">Lower -1°</button>
          <p>{{ targetTemperature }}&deg;F</p>
          <button type="button" [disabled]="!isLoggedIn()" (click)="raiseTemperature()">Raise +1°</button>
        </div>

        <button type="button" class="save-button" [disabled]="!isLoggedIn()" (click)="saveSettings()">Save Thermostat Settings</button>
        <p class="control-help" *ngIf="!isLoggedIn()">Log in to enable thermostat controls.</p>
      </section>

      <section class="grid-row">
        <article class="stat-card">
          <h3>Current Mode</h3>
          <p>{{ currentSettings?.current_mode ?? selectedMode }}</p>
        </article>

        <article class="stat-card">
          <h3>Current Target</h3>
          <p>{{ currentSettings?.target_temperature ?? targetTemperature }}&deg;F</p>
        </article>

        <article class="stat-card">
          <h3>Next Scheduled Event</h3>
          <p class="next-event-main">{{ nextScheduledEventDisplay }}</p>
            <p class="event-meta" *ngIf="nextScheduledEvent">
              {{ nextScheduledEvent.day_of_week | titlecase }} at {{ nextScheduledEvent.event_time }}
              &mdash; {{ nextScheduledEvent.mode | titlecase }}
              &mdash; Target {{ nextScheduledEvent.target_temperature }}&deg;F
            </p>
        </article>
      </section>

      <section class="events-card">
        <div class="card-header schedule-header">
          <h3>Scheduled Events</h3>
          <button type="button" [disabled]="!isLoggedIn()" (click)="openAddEventModal()">Add Event</button>
        </div>

        <div class="schedule-filters" role="group" aria-label="Schedule day filters">
          <button
            type="button"
            *ngFor="let day of dayFilterOptions"
            [class.active]="selectedScheduleDay === day.value"
            (click)="selectScheduleDay(day.value)"
          >
            {{ day.label }}
          </button>
        </div>

        <section class="schedule-content">
          <ul class="events-list" *ngIf="displayedScheduleEvents.length > 0; else noEventsForDay">
          <li *ngFor="let event of displayedScheduleEvents" [class.inactive-event]="!event.is_active">
            <div>
              <p class="event-main">{{ event.event_time }} &mdash; {{ event.mode | titlecase }}</p>
              <p class="event-meta">
                Target {{ event.target_temperature }}&deg;F
                <span *ngIf="event.is_active" class="badge-active">active</span>
                <span *ngIf="!event.is_active" class="badge-inactive">inactive</span>
              </p>
            </div>

            <div class="event-actions">
              <button type="button" class="change-button" [disabled]="!isLoggedIn()" (click)="openEditEventModal(event)">Change</button>
              <button
                type="button"
                class="ghost-action"
                [disabled]="!isLoggedIn() || !event.is_active"
                (click)="deactivateEventFromList(event)"
              >
                Deactivate
              </button>
            </div>
          </li>
          </ul>

          <ng-template #noEventsForDay>
            <p class="empty-state">No scheduled events for this day.</p>
          </ng-template>
        </section>
      </section>

      <section class="activity-card">
        <h3>Recent Activity</h3>
        <ul>
          <li *ngFor="let item of recentActivity">{{ item }}</li>
        </ul>
      </section>

      <section class="toast-stack" aria-live="polite" aria-atomic="true">
        <article class="toast success" *ngIf="successMessage" role="status">
          <p>{{ successMessage }}</p>
          <button type="button" class="toast-close" (click)="clearToast()" aria-label="Dismiss success message">x</button>
        </article>

        <article class="toast error" *ngIf="failureMessage" role="alert">
          <p>{{ failureMessage }}</p>
          <button type="button" class="toast-close" (click)="clearToast()" aria-label="Dismiss error message">x</button>
        </article>
      </section>
    </section>

    <section class="modal-backdrop" *ngIf="showLoginModal" (click)="closeLoginModal()">
      <article class="modal-card" (click)="$event.stopPropagation()">
        <h3>Log In</h3>
        <p class="modal-copy">Log in to save thermostat settings and add or change events.</p>
        <p class="modal-error" *ngIf="loginErrorMessage" role="alert">{{ loginErrorMessage }}</p>

        <form [formGroup]="loginForm" (ngSubmit)="submitLogin()" class="modal-form" novalidate>
          <label>
            Username
            <input type="text" formControlName="username" placeholder="Enter username" />
          </label>

          <label>
            Password
            <input type="password" formControlName="password" placeholder="Enter password" />
          </label>

          <div class="modal-actions">
            <button type="button" class="ghost" (click)="closeLoginModal()">Cancel</button>
            <button type="submit">Log In</button>
          </div>
        </form>
      </article>
    </section>

    <section class="modal-backdrop" *ngIf="showEventModal" (click)="closeEventModal()">
      <article class="modal-card" (click)="$event.stopPropagation()">
        <h3>{{ editingEventId === null ? 'Add Event' : 'Change Event' }}</h3>
        <p class="modal-copy">Set the mode and target temperature for this scheduled event.</p>
        <p class="modal-error" *ngIf="eventErrorMessage" role="alert">{{ eventErrorMessage }}</p>

        <form [formGroup]="eventForm" (ngSubmit)="saveEvent()" class="modal-form" novalidate>
          <label>
            Day of Week
            <select formControlName="dayOfWeek">
              <option *ngFor="let day of allowedDays" [value]="day">{{ day | titlecase }}</option>
            </select>
          </label>

          <label>
            Time (HH:MM)
            <input type="time" formControlName="eventTime" />
          </label>

          <label>
            Mode
            <select formControlName="mode">
              <option *ngFor="let mode of allowedModes" [value]="mode">{{ mode | titlecase }}</option>
            </select>
          </label>

          <label>
            Target Temperature
            <input type="number" formControlName="targetTemperature" [min]="minTemperature" [max]="maxTemperature" />
          </label>

          <label class="checkbox-row">
            <input type="checkbox" formControlName="isActive" />
            Event Active
          </label>

          <div class="modal-actions">
            <button
              *ngIf="editingEventId !== null"
              type="button"
              class="ghost"
              [disabled]="!isLoggedIn()"
              (click)="deactivateEvent()"
            >
              Deactivate
            </button>
            <button type="button" class="ghost" (click)="closeEventModal()">Cancel</button>
            <button type="submit">Save Event</button>
          </div>
        </form>
      </article>
    </section>
  `,
  styles: [
    `
      .dashboard-page {
        display: grid;
        gap: 20px;
        max-width: 1024px;
        margin: 0 auto;
        width: 100%;
      }

      .hero-card,
      .control-card,
      .events-card,
      .activity-card,
      .stat-card {
        border-radius: 20px;
        background: rgba(255, 255, 255, 0.95);
        box-shadow: 0 18px 50px rgba(16, 34, 58, 0.12);
        padding: 24px;
      }

      .hero-card {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        gap: 18px;
      }

      .eyebrow {
        margin: 0;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        font-size: 0.75rem;
        color: #2856d6;
        font-weight: 700;
      }

      .hero-card h2,
      .hero-copy,
      .control-card h3,
      .events-card h3,
      .activity-card h3,
      .stat-card h3 {
        margin-top: 0;
      }

      .hero-copy,
      .auth-state,
      .event-meta,
      .empty-state,
      .modal-copy {
        color: #516173;
      }

      .connection-status {
        margin: 8px 0 0;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        font-weight: 700;
      }

      .status-dot {
        width: 12px;
        height: 12px;
        border-radius: 999px;
        display: inline-block;
      }

      .status-dot.connected {
        background: #1f9d55;
        box-shadow: 0 0 0 4px rgba(31, 157, 85, 0.16);
      }

      .status-dot.disconnected {
        background: #d64545;
        box-shadow: 0 0 0 4px rgba(214, 69, 69, 0.14);
      }

      .connection-status.connected {
        color: #166534;
      }

      .connection-status.disconnected {
        color: #9f1239;
      }

      .control-card {
        display: grid;
        justify-items: center;
        text-align: center;
        gap: 12px;
      }

      .section-title {
        margin-bottom: 0;
      }

      .hero-auth {
        display: grid;
        justify-items: end;
        gap: 8px;
      }

      .hero-button,
      .save-button,
      .card-header button,
      .change-button,
      .modal-actions button,
      .mode-buttons button,
      .temp-controls button {
        border: none;
        border-radius: 999px;
        padding: 10px 16px;
        background: #2856d6;
        color: #fff;
        font-weight: 700;
        cursor: pointer;
      }

      .hero-button.ghost,
      .modal-actions .ghost {
        background: #dce8ff;
        color: #10223a;
      }

      .mode-buttons {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 10px;
        margin-bottom: 16px;
      }

      .mode-buttons button {
        background: #edf2ff;
        color: #10223a;
      }

      .mode-buttons button.active {
        background: #10223a;
        color: #fff;
      }

      .hero-button:disabled,
      .save-button:disabled,
      .card-header button:disabled,
      .change-button:disabled,
      .ghost-action:disabled,
      .modal-actions button:disabled,
      .mode-buttons button:disabled,
      .temp-controls button:disabled {
        background: #c5cad3;
        color: #677384;
        border: 1px solid #b0b8c5;
        cursor: not-allowed;
        box-shadow: none;
      }

      .temp-controls {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
        background: #f7f9ff;
        border: 1px solid rgba(16, 34, 58, 0.12);
        border-radius: 999px;
        padding: 8px;
      }

      .temp-controls p,
      .stat-card p {
        font-size: 1.5rem;
        font-weight: 700;
        margin: 0;
      }

      .save-button {
        margin-top: 14px;
        min-width: min(100%, 300px);
      }

      .control-help {
        margin: 0;
        font-size: 0.95rem;
      }

      .grid-row {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 16px;
      }

      .card-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
      }

      .events-list {
        list-style: none;
        margin: 0;
        padding: 0;
        display: grid;
        gap: 10px;
      }

      .events-list li {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        border: 1px solid rgba(16, 34, 58, 0.12);
        border-radius: 14px;
        padding: 12px;
      }

      .event-main {
        margin: 0;
        font-weight: 700;
      }

      .inactive-event {
        opacity: 0.6;
      }

      .badge-inactive {
        margin-left: 6px;
        background: #c5cad3;
        color: #10223a;
        border-radius: 999px;
        padding: 2px 8px;
        font-size: 0.8rem;
        font-weight: 700;
      }

      .badge-active {
        margin-left: 6px;
        background: #d9f8e6;
        color: #0f7a43;
        border-radius: 999px;
        padding: 2px 8px;
        font-size: 0.8rem;
        font-weight: 700;
      }

      .next-event-main {
        font-size: 1.1rem;
      }

      .schedule-filters {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        justify-content: center;
        margin-top: 14px;
        margin-bottom: 14px;
        padding: 10px;
        border-radius: 16px;
        background: linear-gradient(180deg, #f6f8ff 0%, #eef3ff 100%);
        border: 1px solid rgba(40, 86, 214, 0.15);
      }

      .schedule-content {
        max-width: 760px;
        margin: 0 auto;
        width: 100%;
      }

      .schedule-header {
        max-width: 760px;
        margin: 0 auto;
        width: 100%;
      }

      .schedule-filters button {
        border: 1px solid rgba(16, 34, 58, 0.15);
        border-radius: 999px;
        padding: 12px 18px;
        min-width: 112px;
        font-size: 1.05rem;
        background: #f7f9ff;
        color: #10223a;
        font-weight: 700;
        cursor: pointer;
        transition: transform 140ms ease, box-shadow 140ms ease, background-color 140ms ease;
      }

      .schedule-filters button:hover {
        transform: translateY(-1px);
        box-shadow: 0 6px 14px rgba(16, 34, 58, 0.12);
      }

      .schedule-filters button.active {
        background: #10223a;
        color: #fff;
        border-color: #10223a;
        box-shadow: 0 8px 18px rgba(16, 34, 58, 0.24);
      }

      .event-actions {
        display: flex;
        gap: 8px;
        align-items: center;
      }

      .events-list li {
        background: #ffffff;
        box-shadow: 0 8px 18px rgba(16, 34, 58, 0.08);
      }

      .ghost-action {
        border: 1px solid rgba(16, 34, 58, 0.2);
        border-radius: 999px;
        padding: 8px 12px;
        background: #edf2ff;
        color: #10223a;
        font-weight: 700;
        cursor: pointer;
      }

      .event-meta {
        margin: 2px 0 0;
      }

      .empty-state {
        text-align: center;
        font-size: 1.1rem;
        margin: 6px 0 2px;
        padding: 24px 16px;
        border: 1px dashed rgba(16, 34, 58, 0.28);
        border-radius: 14px;
        background: #f9fbff;
      }

      .activity-card ul {
        margin: 0;
        padding-left: 18px;
      }

      .toast-stack {
        position: fixed;
        right: 16px;
        bottom: 16px;
        display: grid;
        gap: 10px;
        z-index: 100;
      }

      .toast {
        width: min(360px, calc(100vw - 32px));
        border-radius: 12px;
        padding: 12px 12px 12px 14px;
        box-shadow: 0 14px 30px rgba(16, 34, 58, 0.2);
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 10px;
      }

      .toast p {
        margin: 0;
        font-weight: 600;
      }

      .toast.success {
        background: #e8f8ef;
        border: 1px solid #7bc89a;
        color: #0f7a43;
      }

      .toast.error {
        background: #fdeceb;
        border: 1px solid #f2a8a3;
        color: #b42318;
      }

      .toast-close {
        border: none;
        background: transparent;
        color: inherit;
        font-size: 1rem;
        line-height: 1;
        cursor: pointer;
        padding: 2px;
      }

      .modal-backdrop {
        position: fixed;
        inset: 0;
        background: rgba(12, 22, 38, 0.6);
        display: grid;
        place-items: center;
        padding: 20px;
        z-index: 90;
      }

      .modal-card {
        width: min(520px, 100%);
        border-radius: 20px;
        background: #fff;
        box-shadow: 0 24px 60px rgba(4, 13, 25, 0.3);
        padding: 24px;
      }

      .modal-form {
        display: grid;
        gap: 14px;
      }

      .modal-error {
        margin: 0;
        color: #b42318;
        background: #fdeceb;
        border: 1px solid #f2a8a3;
        border-radius: 10px;
        padding: 8px 10px;
        font-weight: 600;
      }

      label {
        display: grid;
        gap: 8px;
        font-weight: 700;
      }

      input,
      select {
        border: 1px solid rgba(16, 34, 58, 0.24);
        border-radius: 12px;
        padding: 10px 12px;
        font-size: 1rem;
      }

      .checkbox-row {
        align-items: center;
        grid-template-columns: auto 1fr;
      }

      .modal-actions {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
      }

      @media (max-width: 700px) {
        .hero-auth {
          justify-items: start;
        }

        .temp-controls {
          flex-wrap: wrap;
        }

        .events-list li {
          flex-direction: column;
          align-items: flex-start;
        }
      }
    `,
  ],
})
export class DashboardComponent implements OnInit, OnDestroy {
  private readonly formBuilder = inject(FormBuilder);
  private readonly thermostatService = inject(ThermostatService);
  private readonly temperatureLogService = inject(TemperatureLogService);
  private readonly activityLogService = inject(ActivityLogService);
  private readonly scheduleService = inject(ScheduleService);
  private readonly authService = inject(AuthService);
  private readonly thermostatStatusService = inject(ThermostatStatusService);

  readonly allowedModes = [...ALLOWED_THERMOSTAT_MODES];
  readonly minTemperature = MIN_TARGET_TEMPERATURE;
  readonly maxTemperature = MAX_TARGET_TEMPERATURE;

  readonly loginForm = this.formBuilder.nonNullable.group({
    username: ['', Validators.required],
    password: ['', Validators.required],
  });

  readonly eventForm = this.formBuilder.nonNullable.group({
    dayOfWeek: ['sunday', Validators.required],
    eventTime: ['07:00', Validators.required],
    mode: ['off', Validators.required],
    targetTemperature: [72, [Validators.required, Validators.min(MIN_TARGET_TEMPERATURE), Validators.max(MAX_TARGET_TEMPERATURE)]],
    isActive: [true],
  });
  // allowedDays is sourced from the shared VALID_DAYS constant to keep the
  // frontend day list in sync with the backend validation without duplication.
  readonly allowedDays = [...VALID_DAYS];
  // Show only day-of-week filter chips in the Scheduled Events section to keep
  // the class UI focused on weekly scheduling behavior.
  readonly dayFilterOptions: DayFilterOption[] = [
    { label: 'Sunday', value: 'sunday' },
    { label: 'Monday', value: 'monday' },
    { label: 'Tuesday', value: 'tuesday' },
    { label: 'Wednesday', value: 'wednesday' },
    { label: 'Thursday', value: 'thursday' },
    { label: 'Friday', value: 'friday' },
    { label: 'Saturday', value: 'saturday' },
  ];


  currentSettings: ThermostatSetting | null = null;
  selectedMode: string = 'off';
  targetTemperature = 72;
  recentActivity: string[] = ['Recent activity will appear here once the backend returns log records.'];
  scheduleEvents: ScheduleEvent[] = [];
  nextScheduledEvent: ScheduleEvent | null = null;
  selectedScheduleDay = this.getCurrentDayName();
  thermostatConnectionStatus: ThermostatStatus | null = null;
  thermostatConnected = false;
  thermostatStatusMessage = 'Thermostat Disconnected';

  showLoginModal = false;
  showEventModal = false;
  editingEventId: number | null = null;
  loginErrorMessage = '';
  eventErrorMessage = '';

  successMessage = '';
  failureMessage = '';

  private postLoginAction: (() => void) | null = null;
  private toastTimeoutId: ReturnType<typeof setTimeout> | null = null;
  private statusPollIntervalId: ReturnType<typeof setInterval> | null = null;

  ngOnInit(): void {
    this.loadDashboardData();
    this.loadThermostatStatus();
    this.statusPollIntervalId = setInterval(() => {
      this.loadThermostatStatus();
    }, 30000);

    this.authService.loginModalRequest$.subscribe((requestId) => {
      if (requestId > 0 && !this.isLoggedIn()) {
        this.openLoginModal();
      }
    });
  }

  ngOnDestroy(): void {
    this.clearToastTimer();
    if (!this.statusPollIntervalId) {
      return;
    }

    clearInterval(this.statusPollIntervalId);
    this.statusPollIntervalId = null;
  }

  get currentUsername(): string {
    return this.authService.getCurrentUser()?.username ?? 'guest';
  }

  get displayedScheduleEvents(): ScheduleEvent[] {
    // Selected day controls which rows are visible. We filter by day_of_week and
    // then sort HH:MM strings so the day's events are always chronological.
    return this.scheduleEvents
      .filter((event) => event.day_of_week.toLowerCase() === this.selectedScheduleDay)
      .sort((a, b) => a.event_time.localeCompare(b.event_time));
  }

  selectScheduleDay(day: string): void {
    this.selectedScheduleDay = day;
  }

  get nextScheduledEventDisplay(): string {
    if (!this.nextScheduledEvent) {
      return 'No upcoming scheduled events.';
    }
    // Display the next weekly event as "MODE on DAY at HH:MM".
    return `${this.nextScheduledEvent.mode.toUpperCase()} on ${this.nextScheduledEvent.day_of_week} at ${this.nextScheduledEvent.event_time}`;
  }

  isLoggedIn(): boolean {
    return this.authService.isLoggedIn();
  }

  openLoginModal(): void {
    this.loginErrorMessage = '';
    this.showLoginModal = true;
  }

  closeLoginModal(): void {
    this.loginErrorMessage = '';
    this.showLoginModal = false;
    this.postLoginAction = null;
  }

  submitLogin(): void {
    this.loginErrorMessage = '';

    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      this.loginErrorMessage = 'Please enter both a username and password.';
      return;
    }

    const { username, password } = this.loginForm.getRawValue();
    this.authService.login({ username, password }).subscribe({
      next: (result) => {
        if (!result.success) {
          this.loginErrorMessage = result.message;
          return;
        }

        this.clearToast();
        this.showSuccessToast(result.message);
        this.showLoginModal = false;
        this.loginErrorMessage = '';
        this.loginForm.reset({ username: '', password: '' });
        this.loadDashboardData();

        const pendingAction = this.postLoginAction;
        this.postLoginAction = null;
        if (pendingAction) {
          pendingAction();
        }
      },
      error: () => {
        this.loginErrorMessage = 'Unable to log in right now. Please try again.';
      },
    });
  }

  logout(): void {
    this.authService.logout();
    this.showSuccessToast('You have been logged out.');
  }

  selectMode(mode: string): void {
    this.selectedMode = mode;
  }

  raiseTemperature(): void {
    this.targetTemperature = this.thermostatService.clampTargetTemperature(this.targetTemperature + 1);
  }

  lowerTemperature(): void {
    this.targetTemperature = this.thermostatService.clampTargetTemperature(this.targetTemperature - 1);
  }

  saveSettings(): void {
    this.requireLogin(() => {
      this.saveThermostatSettings();
    });
  }

  openAddEventModal(): void {
    this.requireLogin(() => {
      this.eventErrorMessage = '';
      this.editingEventId = null;
      this.eventForm.reset({
        dayOfWeek: 'sunday',
        eventTime: '07:00',
        mode: this.selectedMode,
        targetTemperature: this.targetTemperature,
        isActive: true,
      });
      this.showEventModal = true;
    });
  }

  openEditEventModal(event: ScheduleEvent): void {
    this.requireLogin(() => {
      this.eventErrorMessage = '';
      this.editingEventId = event.event_id;
      this.eventForm.reset({
        dayOfWeek: event.day_of_week,
        eventTime: event.event_time,
        mode: event.mode,
        targetTemperature: event.target_temperature,
        isActive: event.is_active,
      });
      this.showEventModal = true;
    });
  }

  closeEventModal(): void {
    this.eventErrorMessage = '';
    this.showEventModal = false;
    this.editingEventId = null;
  }

  saveEvent(): void {
    this.clearToast();
    this.eventErrorMessage = '';

    if (this.eventForm.invalid) {
      this.eventForm.markAllAsTouched();
      this.eventErrorMessage = 'Please enter a valid event time, mode, and target temperature.';
      return;
    }

    const userId = this.authService.getCurrentUser()?.user_id;
    if (!userId) {
      this.showEventModal = false;
      this.requireLogin(() => this.openAddEventModal());
      return;
    }

    const { dayOfWeek, eventTime, mode, targetTemperature, isActive } = this.eventForm.getRawValue();
    const request: ScheduleEventRequest = {
      user_id: userId,
      day_of_week: dayOfWeek,
      event_time: eventTime,
      mode,
      target_temperature: this.thermostatService.clampTargetTemperature(targetTemperature),
      is_active: isActive,
    };

    if (this.editingEventId !== null) {
      // Schedule edits now persist through the backend so database state stays authoritative.
      this.scheduleService.updateScheduleEvent(this.editingEventId, request).subscribe({
        next: () => {
          this.showSuccessToast('Event updated successfully.');
          this.loadScheduleEvents();
          this.loadNextScheduledEvent();
          this.loadRecentActivity();
          this.closeEventModal();
        },
        error: (error: HttpErrorResponse) => {
          this.eventErrorMessage = this.buildScheduleErrorMessage(error);
          this.showErrorToast(this.eventErrorMessage);
        },
      });
      return;
    }

    this.scheduleService.createScheduleEvent(request).subscribe({
      next: () => {
        this.showSuccessToast('Event added successfully.');
        this.loadScheduleEvents();
        this.loadNextScheduledEvent();
        this.loadRecentActivity();
        this.closeEventModal();
      },
      error: (error: HttpErrorResponse) => {
        this.eventErrorMessage = this.buildScheduleErrorMessage(error);
        this.showErrorToast(this.eventErrorMessage);
      },
    });
  }

  deactivateEvent(): void {
    if (this.editingEventId === null) {
      return;
    }

    this.clearToast();
    this.scheduleService.deactivateScheduleEvent(this.editingEventId).subscribe({
      next: () => {
        this.showSuccessToast('Event deactivated successfully.');
        this.loadScheduleEvents();
        this.loadNextScheduledEvent();
        this.loadRecentActivity();
        this.closeEventModal();
      },
      error: (error: HttpErrorResponse) => {
        this.eventErrorMessage = this.buildScheduleErrorMessage(error);
        this.showErrorToast(this.eventErrorMessage);
      },
    });
  }

  deactivateEventFromList(event: ScheduleEvent): void {
    if (!event.is_active) {
      return;
    }

    this.clearToast();
    this.scheduleService.deactivateScheduleEvent(event.event_id).subscribe({
      next: () => {
        this.showSuccessToast('Event deactivated successfully.');
        this.loadScheduleEvents();
        this.loadNextScheduledEvent();
        this.loadRecentActivity();
      },
      error: (error: HttpErrorResponse) => {
        const message = this.buildScheduleErrorMessage(error);
        this.showErrorToast(message);
      },
    });
  }

  private buildScheduleQueryFilters(): { userId?: number } {
    const userId = this.authService.getCurrentUser()?.user_id;
    if (userId !== undefined) {
      return { userId };
    }
    return {};
  }

  private loadDashboardData(): void {
    const currentUserId = this.authService.getCurrentUser()?.user_id;

    this.thermostatService.getCurrentSettings(currentUserId, currentUserId !== undefined).subscribe({
      next: (settings) => {
        this.currentSettings = settings;

        if (settings) {
          this.selectedMode = settings.current_mode;
          this.targetTemperature = settings.target_temperature;
        }
      },
      error: () => {
        this.currentSettings = null;
      },
    });

    this.loadRecentActivity();

    this.loadScheduleEvents();
    this.loadNextScheduledEvent();
  }

  private loadThermostatStatus(): void {
    this.thermostatStatusService.getThermostatStatus().subscribe({
      next: (status) => {
        this.thermostatConnectionStatus = status;
        this.thermostatConnected = status.connected;
        this.thermostatStatusMessage = status.connected ? 'Thermostat Connected' : 'Thermostat Disconnected';
      },
      error: () => {
        this.thermostatConnectionStatus = null;
        this.thermostatConnected = false;
        this.thermostatStatusMessage = 'Thermostat Disconnected';
      },
    });
  }

  private loadRecentActivity(): void {
    const currentUserId = this.authService.getCurrentUser()?.user_id;
    this.activityLogService.getActivityLogs({ userId: currentUserId, limit: 5 }).subscribe({
      next: (logs) => {
        this.recentActivity = this.buildRecentActivityText(logs);
      },
      error: () => {
        this.recentActivity = ['Recent activity will appear here once the backend returns log records.'];
      },
    });
  }

  private loadScheduleEvents(): void {
    this.scheduleService.getScheduleEvents(this.buildScheduleQueryFilters()).subscribe({
      next: (events) => {
        this.scheduleEvents = events;
      },
      error: () => {
        this.scheduleEvents = [];
      },
    });
  }

  private loadNextScheduledEvent(): void {
    const currentUserId = this.authService.getCurrentUser()?.user_id;
    this.scheduleService.getNextScheduleEvent(currentUserId).subscribe({
      next: (event) => {
        this.nextScheduledEvent = event;
      },
      error: () => {
        this.nextScheduledEvent = null;
      },
    });
  }

  private buildScheduleErrorMessage(error: HttpErrorResponse): string {
    if (typeof error.error?.detail === 'string') {
      return error.error.detail;
    }
    if (typeof error.error?.message === 'string') {
      return error.error.message;
    }
    return 'Unable to save event right now.';
  }

  private saveThermostatSettings(): void {
    this.clearToast();

    const userId = this.authService.getCurrentUser()?.user_id;
    if (!userId) {
      this.showErrorToast('Please log in to save thermostat settings.');
      return;
    }

    if (!this.thermostatService.validateMode(this.selectedMode)) {
      this.showErrorToast('Only off, heat, and cool are allowed thermostat modes.');
      return;
    }

    if (!this.thermostatService.validateTargetTemperature(this.targetTemperature)) {
      this.showErrorToast(`Target temperature must stay between ${MIN_TARGET_TEMPERATURE} and ${MAX_TARGET_TEMPERATURE} degrees.`);
      return;
    }

    this.thermostatService
      .updateSettings({
        user_id: userId,
        current_mode: this.selectedMode,
        target_temperature: this.targetTemperature,
      })
      .subscribe({
        next: (settings) => {
          if (!settings) {
            this.showErrorToast('Unable to save thermostat settings right now.');
            return;
          }

          this.currentSettings = settings;
          this.showSuccessToast('Thermostat settings saved successfully.');
          this.loadRecentActivity();
        },
        error: () => {
          this.showErrorToast('Unable to save thermostat settings right now.');
        },
      });
  }

  private requireLogin(action: () => void): void {
    if (this.authService.isLoggedIn()) {
      action();
      return;
    }

    this.clearToast();
    this.loginErrorMessage = 'Please log in to continue.';
    this.showLoginModal = true;
    this.postLoginAction = action;
  }

  clearToast(): void {
    this.successMessage = '';
    this.failureMessage = '';
    this.clearToastTimer();
  }

  private showSuccessToast(message: string): void {
    this.successMessage = message;
    this.failureMessage = '';
    this.startToastTimer();
  }

  private showErrorToast(message: string): void {
    this.failureMessage = message;
    this.successMessage = '';
    this.startToastTimer();
  }

  private startToastTimer(): void {
    this.clearToastTimer();
    this.toastTimeoutId = setTimeout(() => {
      this.clearToast();
    }, 4500);
  }

  private clearToastTimer(): void {
    if (!this.toastTimeoutId) {
      return;
    }

    clearTimeout(this.toastTimeoutId);
    this.toastTimeoutId = null;
  }

  private buildRecentActivityText(logs: ActivityLog[]): string[] {
    if (logs.length === 0) {
      return ['Recent activity will appear here once the backend returns log records.'];
    }

    return logs.slice(0, 3).map((log) => {
      const date = new Date(log.timestamp);
      const centralTimeString = date.toLocaleString('en-US', { 
        timeZone: 'America/Chicago',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
      return `${log.action} (${centralTimeString})`;
    });
  }

  private getCurrentDayName(): string {
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    return dayNames[new Date().getDay()];
  }
}
