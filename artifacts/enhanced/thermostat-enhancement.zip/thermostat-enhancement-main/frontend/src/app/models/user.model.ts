// File: user.model.ts
// Purpose: Describe the user data returned by the FastAPI backend.
// This matches the Phase 1 users table response shape used by the frontend.

export interface User {
  user_id: number;
  username: string;
  role: 'admin' | 'user' | string;
  created_at: string;
}
