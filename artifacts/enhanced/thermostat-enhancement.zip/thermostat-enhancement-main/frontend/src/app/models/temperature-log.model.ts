// File: temperature-log.model.ts
// Purpose: Describe temperature history records returned by the backend.
// These entries mirror the Phase 1 temperature_logs table fields.

export interface TemperatureLog {
  log_id: number;
  temperature: number;
  mode: 'off' | 'heat' | 'cool' | string;
  target_temperature: number;
  recorded_at: string;
}

export interface TemperatureLogRequest {
  temperature: number;
  mode: 'off' | 'heat' | 'cool' | string;
  target_temperature: number;
  user_id?: number;
}
