// File: thermostat-status.model.ts
// Purpose: Describe thermostat connection status returned by backend.

export interface ThermostatStatus {
  device_id: string;
  connected: boolean;
  status_message: string;
}
