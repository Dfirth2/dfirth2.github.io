// File: activity-log.model.ts
// Purpose: Describe audit log records returned by the backend.
// The structure matches the Phase 1 activity_logs table fields.

export interface ActivityLog {
  activity_id: number;
  user_id: number;
  action: string;
  timestamp: string;
}

export interface ActivityLogRequest {
  user_id: number;
  action: string;
}
