// File: thermostat-setting.model.ts
// Purpose: Describe thermostat setting records returned from the backend.
// The interface mirrors the current thermostat_settings table structure.
// One persisted settings row is maintained per user in this project phase.

export interface ThermostatSetting {
  setting_id: number;
  user_id: number;
  current_mode: 'off' | 'heat' | 'cool' | string;
  target_temperature: number;
  updated_at: string;
}

export interface ThermostatSettingRequest {
  user_id: number;
  current_mode: 'off' | 'heat' | 'cool' | string;
  target_temperature: number;
}
