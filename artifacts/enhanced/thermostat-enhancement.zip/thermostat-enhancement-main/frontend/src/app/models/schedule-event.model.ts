// File: schedule-event.model.ts
// Purpose: Describe recurring weekly thermostat schedule events exchanged with the backend.
// Weekly schedule enhancement: events now use day_of_week and event_time (HH:MM)
// instead of a one-time datetime so schedules repeat every week automatically.

// VALID_DAYS keeps day names consistent between the service and dashboard template.
export const VALID_DAYS = [
  'sunday',
  'monday',
  'tuesday',
  'wednesday',
  'thursday',
  'friday',
  'saturday',
] as const;

export type DayOfWeek = (typeof VALID_DAYS)[number];

export interface ScheduleEvent {
  event_id: number;
  user_id: number;
  // day_of_week holds the recurring day name (sunday–saturday).
  day_of_week: DayOfWeek | string;
  // event_time is stored and transmitted in "HH:MM" 24-hour format.
  event_time: string;
  mode: 'off' | 'heat' | 'cool' | string;
  target_temperature: number;
  is_active: boolean;
}

export interface ScheduleEventRequest {
  user_id: number;
  day_of_week: DayOfWeek | string;
  event_time: string;
  mode: 'off' | 'heat' | 'cool' | string;
  target_temperature: number;
  is_active: boolean;
}
