// File: environment.ts
// Purpose: Provide the local development backend URL for the Angular frontend.
// This environment is used when FastAPI is running locally on the same machine.
// Services should keep using environment.apiBaseUrl so backend targets stay configurable.

export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:8000',
  thermostatDeviceId: 'cs350lab',
};
