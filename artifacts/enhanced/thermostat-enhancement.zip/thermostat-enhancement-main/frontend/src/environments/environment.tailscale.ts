// File: environment.tailscale.ts
// Purpose: Provide backend URL when Angular runs against the Tailscale-hosted FastAPI server.
// Use this environment mode when backend runs on a separate server instead of the local machine.

export const environment = {
  production: false,
  apiBaseUrl: 'http://your-backend-host.ts.net:8000',
  thermostatDeviceId: 'cs350lab',
};
