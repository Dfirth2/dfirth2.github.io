// File: environment.prod.ts
// Purpose: Provide the production backend URL configuration for the Angular build.
// For this class project, production builds can target the Tailscale-hosted backend.
// If deployment strategy changes later, update apiBaseUrl to the final hosted backend URL.

export const environment = {
  production: true,
  apiBaseUrl: 'http://your-backend-host.ts.net:8000',
  thermostatDeviceId: 'cs350lab',
};
